# 125 · The metric k-median approximation threshold and recovery

**Subject:** Theoretical computer science

## The question, intuitively

What is the best efficiently attainable approximation factor for choosing k centers under a sum-of-distances objective?

## Papers in this family

- [Single-exponential recovery and bounded-price strictness for metric k-median](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Single-Exponential-Recovery-and-Bounded-Price-Strictness-for-Metric-k-Median-September-24-2026/paper.pdf) — [note](../../papers/paper-ce86ea9bfcf066c5.md)
- [The approximation threshold for metric k-median](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Approximation-Threshold-for-Metric-k-Median-September-24-2026/main.pdf) — [note](../../papers/paper-814bc4ceffe46642.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
