# 104 · Quasipolynomial algorithms for mean-payoff, stochastic and parity games

**Subject:** Theoretical computer science

## The question, intuitively

Can several infinite-duration graph games be solved substantially faster than general exponential search?

## Papers in this family

- [Turn-Based Stochastic Mean-Payoff Games in Deterministic Quasipolynomial Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Turn-Based-Stochastic-Mean-Payoff-Games-in-Deterministic-Quasipolynomial-Time-October-5-2026/stochastic-mean-payoff-games.pdf) — [note](../../papers/paper-36669faf4e5b9e47.md)
- [Mean-payoff parity games in quasipolynomial time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mean-payoff-parity-games-in-quasipolynomial-time-October-5-2026/mean-payoff-parity.pdf) — [note](../../papers/paper-d1bf6ad8e419434a.md)
- [Deterministic quasipolynomial-time mean-payoff games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-quasipolynomial-time-mean-payoff-games-September-25-2026/paper.pdf) — [note](../../papers/paper-d65a80b5538b0a14.md)
- [Randomized quasipolynomial-time mean-payoff games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Randomized-quasipolynomial-time-mean-payoff-games-September-25-2026/paper.pdf) — [note](../../papers/paper-77ada06590d4f430.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
