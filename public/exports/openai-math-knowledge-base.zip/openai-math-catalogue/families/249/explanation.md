# 249 · A finitely generated Eilenberg–Ganea counterexample

**Subject:** Group theory

## The question, intuitively

Can the algebraic dimension of a group be two while every geometric classifying space requires three dimensions?

## Papers in this family

- [A finitely generated counterexample to the Eilenberg–Ganea conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finitely-generated-counterexample-to-the-Eilenberg-Ganea-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-a5f52ea092052dbd.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
