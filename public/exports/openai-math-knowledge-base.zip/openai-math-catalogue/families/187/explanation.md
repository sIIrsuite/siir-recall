# 187 · Snaky in 21 Maker moves

**Subject:** Combinatorics

## The question, intuitively

How quickly can the first player force the Snaky pattern in the specified placement game?

## Papers in this family

- [Snaky in 21 Maker moves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Snaky-in-21-Maker-moves-September-25-2026/article.pdf) — [note](../../papers/paper-c7480306b38301a6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
