# 167 · Planar distinct distances and unit-distance bounds

**Subject:** Combinatorics

## The question, intuitively

How few distinct distances, and how many equal-distance pairs, can a large planar point set have?

## Papers in this family

- [The weak pinned planar distance theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-pinned-planar-distance-theorem-September-23-2026/paper.pdf) — [note](../../papers/paper-57aa9e22a0d59e9e.md)
- [A power saving for planar unit distances](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-planar-unit-distances-September-23-2026/paper.pdf) — [note](../../papers/paper-a50280244b598c59.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
