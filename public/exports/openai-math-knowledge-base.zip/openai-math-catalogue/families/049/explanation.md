# 049 · A stable-coordinate counterexample in four variables

**Subject:** Algebraic and complex geometry

## The question, intuitively

If a polynomial becomes a coordinate after adding variables, must it already have been a coordinate before stabilization?

## Papers in this family

- [A stable coordinate that is not a coordinate in four variables](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-stable-coordinate-that-is-not-a-coordinate-in-four-variables-October-5-2026/stable-coordinate-four-variables.pdf) — [note](../../papers/paper-3dbb3c9dc50ee15e.md)
- [An explicit noncoordinate polynomial with affine three-space zero fibre](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-noncoordinate-polynomial-with-affine-three-space-zero-fibre-September-24-2026/paper.pdf) — [note](../../papers/paper-0f04a0bdb4d7bf8b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
