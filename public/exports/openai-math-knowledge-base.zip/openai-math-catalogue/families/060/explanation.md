# 060 · The Global Spherical Shell conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Do the relevant compact complex surfaces always contain a large spherical shell accounting for their global structure?

## Papers in this family

- [Global Spherical Shells on Minimal Surfaces of Class VII](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Spherical-Shells-on-Minimal-Surfaces-of-Class-VII-September-24-2026/paper.pdf) — [note](../../papers/paper-7c19d149c9f238c3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
