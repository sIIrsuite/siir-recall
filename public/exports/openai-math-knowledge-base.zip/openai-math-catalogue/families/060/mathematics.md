# 060 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Every connected minimal compact complex surface of class VII with $b_2> 0$ contains a global spherical shell, proving the positive-b_{2} Global Spherical Shell conjecture. Such a shell is a holomorphically embedded neighborhood of the standard three-sphere in $\mathbb C^2\setminus\{0\}$ whose complement is connected.

## Global Spherical Shells on Minimal Surfaces of Class VII

We prove the Global Spherical Shell conjecture: every connected minimal compact complex surface of class VII with positive second Betti number contains a global spherical shell. This is a holomorphically embedded neighborhood of the standard three-sphere in $\mathbb C^2\setminus\{0\}$ whose complement is connected.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Spherical-Shells-on-Minimal-Surfaces-of-Class-VII-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Spherical-Shells-on-Minimal-Surfaces-of-Class-VII-September-24-2026)
