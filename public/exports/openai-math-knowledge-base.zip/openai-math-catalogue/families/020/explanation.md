# 020 · Squarefree quartics and power-free polynomial values

**Subject:** Number theory

## The question, intuitively

How often does a polynomial take values with no repeated prime factors, or no prime factor repeated too many times?

## Papers in this family

- [Squarefree values of quartics and power-free values of polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Squarefree-values-of-quartics-and-power-free-values-of-polynomials-September-24-2026/manuscript.pdf) — [note](../../papers/paper-b048d707c8589e15.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
