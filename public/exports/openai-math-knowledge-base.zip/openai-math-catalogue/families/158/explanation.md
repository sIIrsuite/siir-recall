# 158 · The Euclidean plane cannot be colored with five colors

**Subject:** Combinatorics

## The question, intuitively

How many colors are needed to color every point of the plane so that unit-distance pairs always differ?

## Papers in this family

- [The Euclidean plane is not five-colorable](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Euclidean-plane-is-not-five-colorable-September-23-2026/paper.pdf) — [note](../../papers/paper-df3c630d9c9bd2ae.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
