# 074 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves the Kakeya maximal conjecture in three dimensions and the Hausdorff-dimension conjecture in four. In three dimensions, the radius-δ tube maximal operator maps $L^3(\mathbb R^3)$ to $L^3(S^2)$ with norm $O_\varepsilon(\delta^{-\varepsilon})$ for every ε > 0. In four dimensions, every set containing a unit segment in every direction has Hausdorff dimension four.

## The Kakeya maximal conjecture in three dimensions

We prove the Kakeya maximal conjecture in three dimensions. For every ε > 0, the maximal average over unit tubes of radius δ maps $L^3(\mathbb R^3)$ to $L^3(S^2)$ with norm at most $C_\varepsilon\delta^{-\varepsilon}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kakeya-maximal-conjecture-in-three-dimensions-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kakeya-maximal-conjecture-in-three-dimensions-September-23-2026)

## Every four-dimensional Kakeya set has full Hausdorff dimension

We prove the four-dimensional Hausdorff-dimension Kakeya conjecture: every subset of ℝ^{4} containing a unit line segment in every direction has Hausdorff dimension four. No compactness or regularity assumption is imposed on the set or its witnessing line family.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-four-dimensional-Kakeya-set-has-full-Hausdorff-dimension-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-four-dimensional-Kakeya-set-has-full-Hausdorff-dimension-September-24-2026)
