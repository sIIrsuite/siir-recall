# 074 · Kakeya in three and four dimensions

**Subject:** Real and complex analysis

## The question, intuitively

How small can a set be if it contains a unit line segment pointing in every possible direction?

## Papers in this family

- [The Kakeya maximal conjecture in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kakeya-maximal-conjecture-in-three-dimensions-September-23-2026/paper.pdf) — [note](../../papers/paper-3855f97cbf560e53.md)
- [Every four-dimensional Kakeya set has full Hausdorff dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-four-dimensional-Kakeya-set-has-full-Hausdorff-dimension-September-24-2026/paper.pdf) — [note](../../papers/paper-aeaee36af8d9a258.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
