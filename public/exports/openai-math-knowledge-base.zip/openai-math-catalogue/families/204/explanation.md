# 204 · Tensor saturation for even spin groups

**Subject:** Algebra

## The question, intuitively

If a representation occurs after stretching all highest weights, when must it already occur before stretching?

## Papers in this family

- [Tensor saturation for even spin groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026.pdf) — [note](../../papers/paper-3f8d6dbdc1108af3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
