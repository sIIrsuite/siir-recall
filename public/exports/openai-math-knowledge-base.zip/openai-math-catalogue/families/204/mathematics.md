# 204 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves saturation factor one for $\mathop{\mathrm{Spin}}\nolimits (2n)$, n ≥ 2: for three dominant integral weights whose sum lies in the root lattice, an invariant at any common positive integral dilation already gives an invariant at the original weights. This resolves the type-D part of the simply-laced saturation conjecture.

## Tensor saturation for even spin groups

We prove the saturation conjecture for $\mathop{\mathrm{Spin}}\nolimits (2n)$, n ≥ 2. If three dominant integral weights sum to an element of the root lattice, then the existence of a nonzero tensor invariant after a positive integral dilation implies the existence of one at the original weights.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026)
