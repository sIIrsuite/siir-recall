# 212 · Planar first-passage geometry and the absence of bigeodesics

**Subject:** Probability and statistical mechanics

## The question, intuitively

In a random travel-time landscape, how do optimal routes behave, and can an optimal route extend infinitely in both directions?

## Papers in this family

- [No bigeodesics in planar first-passage percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/No-bigeodesics-in-planar-first-passage-percolation-September-24-2026/main.pdf) — [note](../../papers/paper-851efc97fc7a0a30.md)
- [Strict convexity and differentiability of the planar exponential first-passage limit shape](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strict-convexity-and-differentiability-of-the-planar-exponential-first-passage-limit-shape-September-24-2026/main.pdf) — [note](../../papers/paper-4caff5b90a9e86e5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
