# 233 · The joint critical Ashkin–Teller current limit

**Subject:** Probability and statistical mechanics

## The question, intuitively

What joint continuum random field is produced by critical currents in the coupled Ashkin–Teller model?

## Papers in this family

- [The joint scaling limit of critical Ashkin-Teller currents](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-joint-scaling-limit-of-critical-Ashkin-Teller-currents-October-6-2026/main.pdf) — [note](../../papers/paper-c4b96c96c5f07cf2.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
