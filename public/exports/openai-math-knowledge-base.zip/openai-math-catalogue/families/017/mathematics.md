# 017 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that the irrationality exponent of π is exactly 2: for every ε > 0 and all sufficiently large denominators q, every rational $p/q$ satisfies $|\pi-p/q|\ge q^{-2-\varepsilon}$. This also proves convergence of the Flint–Hills series $\sum_{n\ge1}1/(n^3\sin^2 n)$, with angles in radians. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/017.md))

## The irrationality exponent of pi is 2

We prove the conjecture that the irrationality exponent of π is 2. As a consequence, the classical Flint–Hills series $\sum_{n\ge1}1/(n^3\sin^2 n)$ converges, with angles in radians.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-irrationality-exponent-of-pi-is-2-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-irrationality-exponent-of-pi-is-2-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/017.md). A family link does not certify every claim or every companion paper.
