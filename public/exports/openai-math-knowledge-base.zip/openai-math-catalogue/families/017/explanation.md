# 017 · The irrationality exponent of π is 2

**Subject:** Number theory

## The question, intuitively

How exceptionally well can fractions approximate pi, compared with the generic accuracy scale of denominator squared?

## Papers in this family

- [The irrationality exponent of pi is 2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-irrationality-exponent-of-pi-is-2-September-24-2026/paper.pdf) — [note](../../papers/paper-c070260b781163b5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
