# 103 · Exact derandomization of logarithmic space: $\mathsf L=\mathsf{RL}=\mathsf{BPL}$

**Subject:** Theoretical computer science

## The question, intuitively

Can every randomized computation using logarithmic memory be replaced by a deterministic computation using the same order of memory?

## Papers in this family

- [Exact derandomization of logarithmic space: L = RL = BPL](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Derandomization-of-Logarithmic-Space-L-equals-RL-equals-BPL-September-23-2026/paper.pdf) — [note](../../papers/paper-5e1afd211ac96849.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
