# 099 · The sharp exponential scale of edit-distance distortion

**Subject:** Convex and metric geometry

## The question, intuitively

How much distortion is unavoidable when edit distance is represented in simpler normed spaces?

## Papers in this family

- [Edit Distance in l1: Matching Bounds up to Constants in the Exponent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Edit-Distance-in-l1-Matching-Bounds-up-to-Constants-in-the-Exponent-September-27-2026/paper.pdf) — [note](../../papers/paper-2acb38d51dc8e08b.md)
- [Finite-Circle Obstructions, Binary Codes, and Histogram Embeddings for Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Circle-Obstructions-Binary-Codes-and-Histogram-Embeddings-for-Edit-Distance-September-27-2026/paper.pdf) — [note](../../papers/paper-0e6d73d00d94857d.md)
- [Tree Constructions for the l1 Distortion of Binary Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tree-Constructions-for-the-l1-Distortion-of-Binary-Edit-Distance-September-27-2026/paper.pdf) — [note](../../papers/paper-861294c38061120b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
