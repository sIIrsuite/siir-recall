# 152 · Zero entropy does not guarantee a smooth positive-volume model

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Can every zero-entropy measurable dynamical system be represented by a smooth system preserving positive volume?

## Papers in this family

- [A zero-entropy system without a smooth positive-volume model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-entropy-system-without-a-smooth-positive-volume-model-September-25-2026/paper.pdf) — [note](../../papers/paper-d121740482c70f9a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
