# 201 · A counterexample to Kurosh’s division-ring problem

**Subject:** Algebra

## The question, intuitively

Must a finitely generated algebraic division ring be finite-dimensional over its center?

## Papers in this family

- [A Counterexample to Kurosh’s Division-Ring Problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Kuroshs-Division-Ring-Problem-September-23-2026/paper.pdf) — [note](../../papers/paper-1f62bc13ebf9e745.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
