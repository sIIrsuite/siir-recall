# 080 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves almost-everywhere convergence $e^{it\Delta}f\to f$ as $t\downarrow0$ for every $f\in H^{n/(2(n+1))}(\mathbb R^n)$ and every dimension n ≥ 2. This attains the sharp Sobolev equality case of Carleson's Schrödinger convergence problem, including the planar endpoint H^{1/3}.

## Endpoint convergence for the planar Schrodinger equation

We resolve the planar Sobolev endpoint of Carleson's convergence problem: for initial data in $H^{1/3}(\mathbb R^2)$, the Schrödinger evolution converges almost everywhere to the initial data as $t\downarrow0$. The evolution is defined by taking the Gaussian regularization limit first; on one full-measure spatial set, this limit exists for every $0< t< 1$, and the resulting evolution is continuous at t = 0.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-convergence-for-the-planar-Schrodinger-equation-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-convergence-for-the-planar-Schrodinger-equation-September-24-2026)

## Endpoint pointwise convergence for the Schrodinger equation in higher dimensions

We resolve the Sobolev endpoint of Carleson's pointwise convergence problem in every dimension n ≥ 3. For initial data in $H^{n/(2(n+1))}(\mathbb R^n)$, the free Schrödinger evolution converges almost everywhere to the initial data as $t\downarrow0$. The evolution is defined by removing Gaussian regularization on one full-measure spatial set, uniformly over the interval $0< t< 1$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-pointwise-convergence-for-the-Schrodinger-equation-in-higher-dimensions-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-pointwise-convergence-for-the-Schrodinger-equation-in-higher-dimensions-September-24-2026)
