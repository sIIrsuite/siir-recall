# 080 · The exact Sobolev endpoint for Schrödinger convergence

**Subject:** Real and complex analysis

## The question, intuitively

How smooth must initial quantum-wave data be so that Schrödinger evolution returns to it pointwise as time tends to zero?

## Papers in this family

- [Endpoint convergence for the planar Schrodinger equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-convergence-for-the-planar-Schrodinger-equation-September-24-2026/paper.pdf) — [note](../../papers/paper-aba6f578d8e598ff.md)
- [Endpoint pointwise convergence for the Schrodinger equation in higher dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-pointwise-convergence-for-the-Schrodinger-equation-in-higher-dimensions-September-24-2026/paper.pdf) — [note](../../papers/paper-5cfa80856f1bba48.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
