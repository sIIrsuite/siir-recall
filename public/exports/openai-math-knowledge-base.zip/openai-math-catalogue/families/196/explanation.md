# 196 · A counterexample to Kaplansky’s zero-divisor conjecture

**Subject:** Algebra

## The question, intuitively

Can the group algebra of a torsion-free group contain nonzero elements whose product is zero?

## Papers in this family

- [A Torsion-Free Group Algebra with Zero Divisors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Group-Algebra-with-Zero-Divisors-September-23-2026/paper.pdf) — [note](../../papers/paper-3d6fa1dbaf31b181.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
