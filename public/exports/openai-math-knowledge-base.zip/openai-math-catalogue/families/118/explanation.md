# 118 · Bin packing and unbounded configuration-LP gaps

**Subject:** Theoretical computer science

## The question, intuitively

How far can fractional bin-packing solutions underestimate the true number of bins needed?

## Papers in this family

- [Additive hardness and unbounded configuration gaps in bin packing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Additive-hardness-and-unbounded-configuration-gaps-in-bin-packing-September-24-2026/Additive-hardness-and-unbounded-configuration-gaps-in-bin-packing-September-24-2026.pdf) — [note](../../papers/paper-6bb0a2a62beebd99.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
