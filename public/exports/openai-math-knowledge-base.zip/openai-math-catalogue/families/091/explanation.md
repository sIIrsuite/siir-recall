# 091 · Logarithmic and L_{p} Brunn–Minkowski inequalities and the B-conjecture

**Subject:** Convex and metric geometry

## The question, intuitively

How do convex-body volumes change under geometric interpolation, and are the predicted logarithmic concavity bounds sharp?

## Papers in this family

- [The logarithmic Brunn–Minkowski conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-logarithmic-Brunn-Minkowski-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-1c8ee12e593f5b42.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
