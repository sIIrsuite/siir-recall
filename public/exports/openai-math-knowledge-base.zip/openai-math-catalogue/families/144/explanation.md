# 144 · Banach’s simple Lebesgue-spectrum problem

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Can a deterministic measure-preserving dynamical system have the simplest possible Lebesgue-type frequency spectrum?

## Papers in this family

- [A smooth three-torus diffeomorphism with simple Lebesgue spectrum](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-smooth-three-torus-diffeomorphism-with-simple-Lebesgue-spectrum-September-23-2026/paper.pdf) — [note](../../papers/paper-c5f19387b436895f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
