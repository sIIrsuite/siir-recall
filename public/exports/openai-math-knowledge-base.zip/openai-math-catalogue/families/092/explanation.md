# 092 · The optimal order of convex-body covering density

**Subject:** Convex and metric geometry

## The question, intuitively

How efficiently can translated copies of one convex body cover high-dimensional space?

## Papers in this family

- [A single-lattice covering bound of order n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-single-lattice-covering-bound-of-order-n-log-n-September-23-2026/paper.pdf) — [note](../../papers/paper-e021dd6ed3a78625.md)
- [Translative covering densities of order n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Translative-covering-densities-of-order-n-log-n-September-23-2026/paper.pdf) — [note](../../papers/paper-f24a5e830f7bd50f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
