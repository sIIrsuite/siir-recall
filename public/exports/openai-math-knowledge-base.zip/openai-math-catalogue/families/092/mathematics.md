# 092 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Determines the optimal worst-case covering density as $\Theta(n\log n)$, for both lattice and unrestricted translative coverings. Every convex body in ℝ^{n}, n ≥ 2, admits a lattice covering of density at most $Cn\log n$; centrally symmetric examples in every sufficiently large dimension require at least $cn\log n$ even without the lattice restriction, for absolute $c,C> 0$. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/092.md))

## A single-lattice covering bound of order n log n

Every convex body in ℝ^{n}, n ≥ 2, admits a covering by translates along one full-rank lattice with density at most $Cn\log n$, for an absolute constant C. No symmetry or boundary regularity is assumed.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-single-lattice-covering-bound-of-order-n-log-n-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-single-lattice-covering-bound-of-order-n-log-n-September-23-2026)

## Translative covering densities of order n log n

For every sufficiently large dimension n, we construct a centrally symmetric convex body whose translative covering density exceeds $c n\log n$, where c > 0 is absolute. This disproves the existence of a universal linear upper bound and matches the order of Rogers' upper bound.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Translative-covering-densities-of-order-n-log-n-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Translative-covering-densities-of-order-n-log-n-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/092.md). A family link does not certify every claim or every companion paper.
