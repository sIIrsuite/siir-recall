# 153 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Classifies singular and absolutely continuous unbiased Bernoulli convolutions for every $\lambda\in(0,1)$ by an infinite, one-sided approximation condition using explicit finite sets of algebraic units. It also proves singularity at reciprocals of every quartic Salem number in $(1,2)$, giving examples beyond reciprocal Pisot parameters.

## Arithmetic classification and non-Pisot singularity for Bernoulli convolutions

We give an arithmetic classification of singular and absolutely continuous unbiased Bernoulli convolutions for every parameter $\lambda\in(0,1)$. The criterion is expressed through one-sided approximation by explicitly defined finite sets of algebraic units; it is an infinite approximation condition, not a finite membership algorithm. We also establish singular examples beyond reciprocals of Pisot numbers: singularity holds at the reciprocal of every quartic Salem number in $(1,2)$ and at the reciprocal of a specified non-Pisot root of an explicit degree-31 polynomial.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-classification-and-non-Pisot-singularity-for-Bernoulli-convolutions-October-3-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-classification-and-non-Pisot-singularity-for-Bernoulli-convolutions-October-3-2026)
