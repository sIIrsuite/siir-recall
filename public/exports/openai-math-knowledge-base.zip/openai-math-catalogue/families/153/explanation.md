# 153 · Arithmetic classification and non-Pisot singularity for Bernoulli convolutions

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

When does a random sum of geometrically shrinking signs have a smooth distribution, and when does arithmetic force singularity?

## Papers in this family

- [Arithmetic classification and non-Pisot singularity for Bernoulli convolutions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-classification-and-non-Pisot-singularity-for-Bernoulli-convolutions-October-3-2026/paper.pdf) — [note](../../papers/paper-c180c88bf9e78a1a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
