# 169 · Shareshian–Wachs elementary positivity

**Subject:** Combinatorics

## The question, intuitively

Do certain graph-coloring symmetric functions expand with nonnegative coefficients in the elementary basis?

## Papers in this family

- [Elementary positivity of chromatic quasisymmetric functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elementary-Positivity-of-Chromatic-Quasisymmetric-Functions-September-24-2026/paper.pdf) — [note](../../papers/paper-9d0e411beb714fe4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
