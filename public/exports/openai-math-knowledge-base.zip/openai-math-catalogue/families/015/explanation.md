# 015 · Torus-packet equidistribution in prime, quartic, and sextic degrees

**Subject:** Number theory

## The question, intuitively

As arithmetic objects become more complicated, do their associated torus orbits spread evenly through the surrounding space?

## Papers in this family

- [Equidistribution of Prime-Degree Torus Packets with Arbitrary Local Type](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Prime-Degree-Torus-Packets-with-Arbitrary-Local-Type-September-24-2026/paper.pdf) — [note](../../papers/paper-56f4a0f27af6dc17.md)
- [Equidistribution of primitive quartic torus packets for arbitrary orders](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Primitive-Quartic-Torus-Packets-for-Arbitrary-Orders-October-5-2026/quartic-torus-packets.pdf) — [note](../../papers/paper-1106c030fb2a636d.md)
- [Equidistribution of Primitive Sextic Torus Packets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Primitive-Sextic-Torus-Packets-October-5-2026/primitive-sextic-torus-packets.pdf) — [note](../../papers/paper-d53d47dc14579ef0.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
