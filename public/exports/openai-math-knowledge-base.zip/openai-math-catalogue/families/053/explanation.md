# 053 · A counterexample to Pixton completeness in Chow

**Subject:** Algebraic and complex geometry

## The question, intuitively

Do the known tautological relations account for all relations among algebraic cycles on moduli spaces of curves?

## Papers in this family

- [A high-arity counterexample to Pixton completeness in Chow](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-high-arity-counterexample-to-Pixton-completeness-in-Chow-September-24-2026/paper.pdf) — [note](../../papers/paper-8aec1fdb175ede4b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
