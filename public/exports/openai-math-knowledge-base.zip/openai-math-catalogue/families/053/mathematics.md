# 053 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Constructs a tautological relation on a moduli space of stable pointed curves that vanishes in rational Chow, hence in rational cohomology, but lies outside Pixton's original relation span. This disproves the Chow and rational-cohomological forms of his original completeness conjecture.

## A high-arity counterexample to Pixton completeness in Chow

We disprove the Chow and rational-cohomological forms of Pixton's completeness conjecture for his original relation system. We construct a formal tautological class outside the original Pixton relation span whose image is zero in the Chow ring and in rational cohomology. The example has genus $10^{60}$ and $3\binom{10^{60}}3$ markings.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-high-arity-counterexample-to-Pixton-completeness-in-Chow-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-high-arity-counterexample-to-Pixton-completeness-in-Chow-September-24-2026)
