# 022 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that for every real shift γ and finite-valued $\psi:\mathbb N\to[0,\infty)$, divergence of $\sum_q\phi(q)\psi(q)/q$ implies $\|qx-\gamma\|< \psi(q)$ for infinitely many q, for almost every x. Here ϕ is Euler's totient and the norm is distance to the nearest integer. Numerators are unrestricted; no monotonicity or Diophantine condition on γ is needed.

## The Weak Inhomogeneous Duffin–Schaeffer Conjecture

We prove the weak inhomogeneous Duffin–Schaeffer conjecture. For every fixed γ ∈ ℝ and finite-valued $\psi:\mathbb N\to[0,\infty)$, divergence of $\sum_{q\ge1}\phi(q)\psi(q)/q$ implies $\|qx-\gamma\|< \psi(q)$ for infinitely many q, for almost every x. Here ϕ is Euler's totient and $\|\cdot\|$ is distance to the nearest integer. Numerators need not be reduced, and the shift satisfies no Diophantine restriction.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-inhomogeneous-Duffin-Schaeffer-conjecture-September-25-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-inhomogeneous-Duffin-Schaeffer-conjecture-September-25-2026)
