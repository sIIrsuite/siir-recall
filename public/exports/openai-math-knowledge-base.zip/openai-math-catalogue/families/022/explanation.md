# 022 · The weak inhomogeneous Duffin–Schaeffer conjecture

**Subject:** Number theory

## The question, intuitively

When can infinitely many shifted rational approximations hit a real number at a prescribed accuracy?

## Papers in this family

- [The Weak Inhomogeneous Duffin–Schaeffer Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-inhomogeneous-Duffin-Schaeffer-conjecture-September-25-2026/paper.pdf) — [note](../../papers/paper-0e911d75d561126a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
