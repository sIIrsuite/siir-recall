# 028 · Uniformly bounded components of Gaussian-prime graphs

**Subject:** Number theory

## The question, intuitively

If Gaussian primes are connected whenever they lie nearby, can any connected cluster grow arbitrarily large at a fixed connection range?

## Papers in this family

- [Bounded-Step Walks on Gaussian Primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-Step-Walks-on-Gaussian-Primes-September-26-2026/paper.pdf) — [note](../../papers/paper-d62b7c0bb57a39d9.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
