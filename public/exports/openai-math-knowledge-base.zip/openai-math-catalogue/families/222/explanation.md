# 222 · Perceptron free energies and microscopic jamming exponents

**Subject:** Probability and statistical mechanics

## The question, intuitively

What is the exact thermodynamics of a random perceptron, and how do configurations behave near jamming?

## Papers in this family

- [The free energy of the Ising random perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-energy-of-the-Ising-random-perceptron-September-24-2026/The-free-energy-of-the-Ising-random-perceptron-September-24-2026.pdf) — [note](../../papers/paper-e866f9588a041b7a.md)
- [Microscopic jamming in the negative spherical perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Microscopic-jamming-in-the-negative-spherical-perceptron-September-24-2026/Microscopic-jamming-in-the-negative-spherical-perceptron-September-24-2026.pdf) — [note](../../papers/paper-8b82a915c4c2088c.md)
- [The spherical perceptron with bi-orthogonally invariant disorder](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-spherical-perceptron-with-bi-orthogonally-invariant-disorder-September-24-2026/The-spherical-perceptron-with-bi-orthogonally-invariant-disorder-September-24-2026.pdf) — [note](../../papers/paper-16aec61f81be576e.md)
- [The free energy of the spherical random perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-energy-of-the-spherical-random-perceptron-September-24-2026/The-free-energy-of-the-spherical-random-perceptron-September-24-2026.pdf) — [note](../../papers/paper-09751fc7a74572be.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
