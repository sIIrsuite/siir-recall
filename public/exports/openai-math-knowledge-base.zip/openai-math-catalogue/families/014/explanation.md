# 014 · Restricted geometric Langlands, global Arthur enhancements, and generic Ramanujan

**Subject:** Number theory

## The question, intuitively

Can arithmetic symmetry data and geometric objects be matched in the precise form predicted by the Langlands program?

## Papers in this family

- [Global Arthur Enhancements of Cuspidal Excursion Parameters](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Arthur-Enhancements-of-Cuspidal-Excursion-Parameters-October-5-2026/manuscript.pdf) — [note](../../papers/paper-efdce37425d7a5b8.md)
- [Rationality of the Canonical Unramified Arthur Filtration](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rationality-of-the-Canonical-Unramified-Arthur-Filtration-September-24-2026/paper.pdf) — [note](../../papers/paper-6596fc2a5ebf81e7.md)
- [Ramanujan-Arthur Decompositions of Cuspidal Functions at Full Finite Level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ramanujan-Arthur-Decompositions-of-Cuspidal-Functions-at-Full-Finite-Level-September-24-2026/paper.pdf) — [note](../../papers/paper-af4997bb6c2ccb85.md)
- [Temperedness at ramified places for globally generic exceptional groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Temperedness-at-ramified-places-for-globally-generic-exceptional-groups-October-5-2026/ramified-ramanujan.pdf) — [note](../../papers/paper-47f182aeab1b86c6.md)
- [The Restricted Geometric Langlands Equivalence in Positive Characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Restricted-Geometric-Langlands-Equivalence-in-Positive-Characteristic-September-24-2026/paper.pdf) — [note](../../papers/paper-c0474794729685a4.md)
- [Constructible tame Hecke eigensheaves in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constructible-tame-Hecke-eigensheaves-in-positive-characteristic-October-5-2026/constructible-tame-hecke-eigensheaves-positive-characteristic.pdf) — [note](../../papers/paper-18aa6aa885b48d0d.md)
- [Tame Hecke Eigensheaves with Several Marked Points](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tame-Hecke-Eigensheaves-with-Several-Marked-Points-October-5-2026/Tame-Hecke-Eigensheaves-with-Several-Marked-Points.pdf) — [note](../../papers/paper-df7b9e1a28878eb2.md)
- [Frobenius Structures on Tame Hecke Eigensheaves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Frobenius-Structures-on-Tame-Hecke-Eigensheaves-October-5-2026/tame-hecke-frobenius.pdf) — [note](../../papers/paper-dbe60f3502ee282b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
