# 014 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the restricted geometric Langlands equivalence for connected reductive groups on smooth projective connected curves over $\overline{\mathbb F}_q$ under the four stated Lie-theoretic characteristic hypotheses. Over arbitrary algebraically closed fields of characteristic p > 0, the same conclusion holds assuming additionally that p is very good for the group and $p\nmid |W_G|$. Over global function fields, proves Ramanujan at every place for globally generic cuspidal representations of split adjoint absolutely simple exceptional groups, without characteristic or ramification-depth restrictions, and at every unramified place for cuspidal representations of split adjoint absolutely simple groups with a generic unramified component. Assuming the finite-level Ramanujan–Arthur decomposition, constructs global Arthur enhancements of occurring cuspidal excursion parameters for split connected semisimple groups at full finite level, recovering the given parameters by diagonal specialization on the entire Weil group, including inertia.

## Global Arthur Enhancements of Cuspidal Excursion Parameters

Under the finite-level Ramanujan–Arthur decomposition stated in Theorem 1.1, we construct a global Arthur enhancement for every occurring cuspidal excursion parameter at a specified full finite level for a split connected semisimple group over a global function field. A single algebraic SL_{2} and a commuting Weil centralizer map recover the given parameter by diagonal specialization on the entire Weil group, including inertia. The result does not assert ellipticity, Arthur-packet classification, or a multiplicity formula.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Arthur-Enhancements-of-Cuspidal-Excursion-Parameters-October-5-2026/manuscript.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Arthur-Enhancements-of-Cuspidal-Excursion-Parameters-October-5-2026)

## Rationality of the Canonical Unramified Arthur Filtration

Under the characteristic hypotheses of restricted geometric Langlands theory, we prove that the canonical Arthur filtration on finitely supported unramified automorphic functions is defined over ℚ for split connected semisimple groups. The result includes the noncuspidal part and every closed invariant nilpotent support, establishing the rationality conjecture of Gaitsgory–Lafforgue–Raskin in this setting.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rationality-of-the-Canonical-Unramified-Arthur-Filtration-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rationality-of-the-Canonical-Unramified-Arthur-Filtration-September-24-2026)

## Ramanujan-Arthur Decompositions of Cuspidal Functions at Full Finite Level

We prove rational and $\overline{\mathbb Q}_\ell$ decompositions of cuspidal automorphic functions for split semisimple groups over global function fields into subspaces indexed by nilpotent orbits of the dual group. The decompositions hold at every full finite level, with arbitrary divisor multiplicities. Each summand is governed by the same orbit at every unramified place and every complex embedding. At trivial level this proves Conjectures 3.4.5 and 3.4.6 of Gaitsgory–Lafforgue–Raskin. For split connected adjoint absolutely simple groups, we also prove that a cuspidal automorphic representation with one generic unramified local component is tempered at every unramified place. Thus globally generic cuspidal representations in this scope satisfy the unramified part of the generalized Ramanujan conjecture.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ramanujan-Arthur-Decompositions-of-Cuspidal-Functions-at-Full-Finite-Level-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ramanujan-Arthur-Decompositions-of-Cuspidal-Functions-at-Full-Finite-Level-September-24-2026)

## Temperedness at ramified places for globally generic exceptional groups

We prove the generalized Ramanujan conjecture for globally generic cuspidal automorphic representations of split connected adjoint exceptional groups over global function fields. Every local component is tempered, without restrictions on characteristic or ramification depth. The proof extends the unramified Ramanujan theorem of a companion paper to all ramified places.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Temperedness-at-ramified-places-for-globally-generic-exceptional-groups-October-5-2026/ramified-ramanujan.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Temperedness-at-ramified-places-for-globally-generic-exceptional-groups-October-5-2026)

## The Restricted Geometric Langlands Equivalence in Positive Characteristic

We prove the $\overline{\mathbb Q}_\ell$-linear restricted geometric Langlands equivalence for smooth projective connected curves and connected reductive groups in characteristic p > 0, with ℓ ≠ p, in two regimes. Over $\overline{\mathbb F}_q$, we assume the four characteristic conditions of the restricted theory stated below. Over arbitrary algebraically closed fields, we assume these conditions and additionally that p is very good and does not divide the Weyl-group order. This proves Gaitsgory–Raskin's full-support conjecture [[12, Conjecture 1.3.10]](https://arxiv.org/abs/2508.02237v1) in these regimes.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Restricted-Geometric-Langlands-Equivalence-in-Positive-Characteristic-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Restricted-Geometric-Langlands-Equivalence-in-Positive-Characteristic-September-24-2026)

## Constructible tame Hecke eigensheaves in positive characteristic

We construct nonzero locally constructible perverse Hecke eigensheaves with Borel level at one marked point on a smooth projective curve of genus at least two over an algebraic closure of a finite field. The parameter is a Zariski-dense geometric ℓ-adic local system with tame regular-unipotent monodromy. The group is simple and simply connected and satisfies four explicit Lie-theoretic characteristic hypotheses. The eigensheaves have parabolic nilpotent singular support, and their eigenisomorphisms are compatible with tensor products, permutations, and fusion.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constructible-tame-Hecke-eigensheaves-in-positive-characteristic-October-5-2026/constructible-tame-hecke-eigensheaves-positive-characteristic.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constructible-tame-Hecke-eigensheaves-in-positive-characteristic-October-5-2026)

## Tame Hecke Eigensheaves with Several Marked Points

For SL_{n} in characteristic p > n, we construct nonzero locally constructible perverse Hecke eigensheaves with Borel level at two or more marked points on a smooth projective curve of genus at least two over an algebraic closure of a finite field. The parameter is a Zariski-dense geometric ℓ-adic PGL_{n}-local system with unipotent tame monodromy; its nilpotent logarithms may have any Jordan type, including zero. The eigensheaves have parabolic nilpotent singular support, and their eigenisomorphisms retain the full tensor and fusion structure.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tame-Hecke-Eigensheaves-with-Several-Marked-Points-October-5-2026/Tame-Hecke-Eigensheaves-with-Several-Marked-Points.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tame-Hecke-Eigensheaves-with-Several-Marked-Points-October-5-2026)

## Frobenius Structures on Tame Hecke Eigensheaves

We construct nonzero perverse Weil Hecke eigensheaves for SL_{n} with Borel level at one marked point, after a finite extension of the field of constants. The parameter is a geometrically dense arithmetic PGL_{n}-local system with tame regular-unipotent monodromy on a once-punctured curve of genus at least two over a finite field of characteristic p > n. The full multi-leg eigenstructure is Frobenius compatible with the prescribed arithmetic eigenvalue, and the geometric sheaf has parabolic nilpotent singular support.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Frobenius-Structures-on-Tame-Hecke-Eigensheaves-October-5-2026/tame-hecke-frobenius.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Frobenius-Structures-on-Tame-Hecke-Eigensheaves-October-5-2026)
