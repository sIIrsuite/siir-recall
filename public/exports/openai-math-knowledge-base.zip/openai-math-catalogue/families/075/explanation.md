# 075 · The $L\log L$ Fourier-convergence conjecture

**Subject:** Real and complex analysis

## The question, intuitively

How little integrability is enough to ensure that the Fourier series of a function converges almost everywhere?

## Papers in this family

- [Almost-everywhere Fourier convergence in L log L](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Almost-everywhere-Fourier-convergence-in-L-log-L-September-23-2026/paper.pdf) — [note](../../papers/paper-996ced01dd679b88.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
