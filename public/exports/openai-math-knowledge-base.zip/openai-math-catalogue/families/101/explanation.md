# 101 · The sharp simplex conjecture for isotropic constants

**Subject:** Convex and metric geometry

## The question, intuitively

Among normalized convex bodies, does the simplex maximize the measure of spread called the isotropic constant?

## Papers in this family

- [A sharp entropy bound and the simplex inequality for isotropic constants](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-entropy-bound-and-the-simplex-inequality-for-isotropic-constants-October-5-2026/isotropic-simplex.pdf) — [note](../../papers/paper-1cacde967efb6246.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
