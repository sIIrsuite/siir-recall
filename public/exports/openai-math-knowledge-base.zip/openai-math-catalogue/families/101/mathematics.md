# 101 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that simplices uniquely maximize the isotropic constant among convex bodies in every dimension, resolving the strong isotropic constant conjecture. Also establishes the sharp entropy lower bound for log-concave probability densities, with equality precisely for invertible affine images of products of one-sided exponential laws.

## A sharp entropy bound and the simplex inequality for isotropic constants

We prove the strong isotropic constant conjecture: in each dimension, simplices are the unique maximizers of the isotropic constant among convex bodies. We also prove the sharp entropy bound $h(f)\ge m+\tfrac12\log\det\mathop{\mathrm{Cov}}\nolimits (f)$ for every log-concave probability density on ℝ^{m}, with equality precisely for invertible affine images of products of one-sided exponential laws.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-entropy-bound-and-the-simplex-inequality-for-isotropic-constants-October-5-2026/isotropic-simplex.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-entropy-bound-and-the-simplex-inequality-for-isotropic-constants-October-5-2026)
