# 073 · The Falconer distance conjecture

**Subject:** Real and complex analysis

## The question, intuitively

How large must a fractal set be before its pairwise distances occupy positive length on the real line?

## Papers in this family

- [The Falconer distance conjecture in all dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Falconer-distance-conjecture-in-all-dimensions-September-23-2026/paper.pdf) — [note](../../papers/paper-c4b20b597d07480d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
