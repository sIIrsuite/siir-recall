# 073 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves the Falconer distance conjecture in every dimension d ≥ 2: every compact set $E\subset\mathbb R^d$ with Hausdorff dimension greater than $d/2$ determines a set of Euclidean distances of positive Lebesgue measure. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/073.md))

## The Falconer distance conjecture in all dimensions

We resolve the Falconer distance conjecture in every dimension. For every integer d ≥ 2, a compact subset of ℝ^{d} with Hausdorff dimension greater than $d/2$ determines a set of Euclidean distances of positive Lebesgue measure.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Falconer-distance-conjecture-in-all-dimensions-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Falconer-distance-conjecture-in-all-dimensions-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/073.md). A family link does not certify every claim or every companion paper.
