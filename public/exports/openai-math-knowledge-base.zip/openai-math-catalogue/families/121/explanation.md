# 121 · Almost-linear approximation of edit distance

**Subject:** Theoretical computer science

## The question, intuitively

Can approximate edit distance be computed in nearly linear time with a useful approximation guarantee?

## Papers in this family

- [An Almost-Linear Approximation Scheme for Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Almost-Linear-Approximation-Scheme-for-Edit-Distance-September-24-2026/paper.pdf) — [note](../../papers/paper-160a98fc23945564.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
