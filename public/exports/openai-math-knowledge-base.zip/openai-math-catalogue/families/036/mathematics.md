# 036 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves numerical semiampleness for nef adjoints $K_X+B+M$ with $K_X+B$ pseudo-effective and M nef rational, for projective klt rational pairs over algebraically closed characteristic-zero fields and smooth compact Kähler rational klt simple-normal-crossing pairs, using Bott–Chern cohomology in the latter case. Separately, projective generalized log canonical rational pairs over such fields admit minimal models for pseudo-effective adjoints and Mori fiber spaces otherwise, with nef b-data fixed.

## Numerical semiampleness of nef adjoint classes on compact Kähler manifolds

Let X be a smooth connected compact Kähler manifold, let B be an effective rational simple normal crossing divisor with coefficients less than one, and let M be a nef rational holomorphic line bundle on X. If $K_X+B$ is pseudo-effective and $K_X+B+M$ is nef, we prove that its first Chern class in real Bott–Chern cohomology is represented by a semiample rational line bundle. This numerical statement allows a flat change of line bundle; it does not assert semiampleness of the original adjoint.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-semiampleness-of-nef-adjoint-classes-on-compact-Kahler-manifolds-October-6-2026/numerical-generalized-abundance.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-semiampleness-of-nef-adjoint-classes-on-compact-Kahler-manifolds-October-6-2026)

## Numerical Semiampleness of Nef Adjoint Divisors

We prove the Generalised Abundance Conjecture: if $(X,B)$ is a projective klt ℚ-pair over an algebraically closed field of characteristic zero, $K_X+B$ is pseudo-effective, M is a nef ℚ-Cartier divisor on X, and $K_X+B+M$ is nef, then $K_X+B+M$ is numerically equivalent to a semiample ℚ-Cartier divisor on X.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-Semiampleness-of-Nef-Adjoint-Divisors-October-3-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-Semiampleness-of-Nef-Adjoint-Divisors-October-3-2026)

## Minimal models and Mori fibre spaces for generalized log canonical Q-pairs

We resolve the existence form of the minimal-model conjecture for projective generalized log canonical ℚ-pairs over algebraically closed fields of characteristic zero. Such a pair admits a minimal model when its adjoint divisor is pseudo-effective, and a Mori fibre space otherwise, while keeping the nef ℚ-Cartier b-divisor fixed. Taking the nef part to be zero gives the corresponding result for ordinary log canonical ℚ-pairs.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-and-Mori-fibre-spaces-for-generalized-log-canonical-Q-pairs-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-and-Mori-fibre-spaces-for-generalized-log-canonical-Q-pairs-September-24-2026)

## Minimal models in numerical dimension one

We resolve the numerical-dimension-one case of the minimal-model conjecture for smooth connected complex projective varieties of dimension at least three. If K_{X} is pseudo-effective and $\kappa_\sigma(X,K_X)=1$, with κ_{σ} defined by section growth with a fixed ample twist, then X admits a projective ℚ-factorial terminal minimal model.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-in-numerical-dimension-one-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-in-numerical-dimension-one-September-24-2026)
