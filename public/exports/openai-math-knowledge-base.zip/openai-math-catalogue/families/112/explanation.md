# 112 · Beyond the square-root exponent for depth-three circuits

**Subject:** Theoretical computer science

## The question, intuitively

How large must a shallow arithmetic circuit be to compute explicit difficult polynomials?

## Papers in this family

- [Beyond the Square-Root Exponent for Depth-Three Boolean Circuits](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Beyond-the-Square-Root-Exponent-for-Depth-Three-Boolean-Circuits-September-23-2026/main.pdf) — [note](../../papers/paper-845f094d57cbb49b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
