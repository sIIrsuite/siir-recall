# 221 · The Mézard–Parisi formula for diluted spin glasses

**Subject:** Probability and statistical mechanics

## The question, intuitively

Can the free energy of a sparse spin glass be computed from the predicted hierarchical statistical-mechanical formula?

## Papers in this family

- [The Mézard–Parisi formula for diluted spin glasses](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mezard-Parisi-formula-for-diluted-spin-glasses-September-23-2026/paper.pdf) — [note](../../papers/paper-a551af11ad89fbac.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
