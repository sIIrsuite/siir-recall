# 218 · Conformal universality for weakly interacting and random-bond Ising models

**Subject:** Probability and statistical mechanics

## The question, intuitively

Does the critical Ising scaling limit remain conformally universal when weak interactions or random bonds are added?

## Papers in this family

- [Quenched SLE₃ limits for general weak random-bond Ising models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE3-limits-for-general-weak-random-bond-Ising-models-October-5-2026/general-weak-random-bond-ising.pdf) — [note](../../papers/paper-f6b2768105c15b7b.md)
- [Quenched SLE₃ Universality for the Weak Random-Bond Ising Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE3-Universality-for-the-Weak-Random-Bond-Ising-Model-October-5-2026/quenched-sle3-weak-random-bond-ising.pdf) — [note](../../papers/paper-9b924b24ced69e92.md)
- [Logarithmic Relative Fluctuations in the Weakly Disordered Planar Ising Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Logarithmic-Relative-Fluctuations-in-the-Weakly-Disordered-Planar-Ising-Model-October-5-2026/critical-relative-second-moment-weak-random-bond-ising.pdf) — [note](../../papers/paper-55ccdb521eb4808b.md)
- [Conformal universality of bulk Ising correlations under weak interactions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-universality-of-bulk-Ising-correlations-under-weak-interactions-September-23-2026/paper.pdf) — [note](../../papers/paper-526dfb9118d25ec2.md)
- [SLE3 universality for weak finite-range Ising interactions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/SLE3-universality-for-weak-finite-range-Ising-interactions-September-23-2026/paper.pdf) — [note](../../papers/paper-2b234feb92a2c9ca.md)
- [Buffered comparison and stopping-band resolution in critical Ising](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Buffered-comparison-and-stopping-band-resolution-in-critical-Ising-September-23-2026/paper.pdf) — [note](../../papers/paper-2af5567ba4041e1e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
