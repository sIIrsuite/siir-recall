# 111 · One-sample matroid prophet inequalities against an almighty adversary

**Subject:** Theoretical computer science

## The question, intuitively

Can a single sample of each uncertain reward guide near-optimal selection under matroid constraints against a powerful adversary?

## Papers in this family

- [One Sample Suffices for Matroid Prophet Inequalities against an Almighty Adversary](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/One-Sample-Suffices-for-Matroid-Prophet-Inequalities-against-an-Almighty-Adversary-September-23-2026/final.pdf) — [note](../../papers/paper-d027c9ccbce3784d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
