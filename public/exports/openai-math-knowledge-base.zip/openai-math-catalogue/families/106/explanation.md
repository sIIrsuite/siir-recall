# 106 · Hardness of coloring three-colorable graphs

**Subject:** Theoretical computer science

## The question, intuitively

How many colors are efficiently achievable when a graph is guaranteed to need only three?

## Papers in this family

- [Hardness of finding large independent sets in three-colorable graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hardness-of-finding-large-independent-sets-in-three-colorable-graphs-September-24-2026/Hardness-of-finding-large-independent-sets-in-three-colorable-graphs-September-24-2026.pdf) — [note](../../papers/paper-739714f8b0fb91d6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
