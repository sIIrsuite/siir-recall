# 252 · A torsion-free hyperbolic group that is neither residually finite nor linear over any field

**Subject:** Group theory

## The question, intuitively

Can a torsion-free hyperbolic group fail both finite-quotient detection and every faithful matrix representation?

## Papers in this family

- [A torsion-free hyperbolic group that is not residually finite](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/paper.pdf) — [note](../../papers/paper-01b64f9ea4a8dbca.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
