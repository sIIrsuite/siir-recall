# 141 · Existential–universal real sentences in the counting hierarchy

**Subject:** Theoretical computer science

## The question, intuitively

Where does deciding alternating quantified polynomial inequalities fit among counting-based complexity classes?

## Papers in this family

- [Existential–universal real sentences in the counting hierarchy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Existential-universal-real-sentences-in-the-counting-hierarchy-October-4-2026/etr-counting-hierarchy.pdf) — [note](../../papers/paper-25f9db8c418d6934.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
