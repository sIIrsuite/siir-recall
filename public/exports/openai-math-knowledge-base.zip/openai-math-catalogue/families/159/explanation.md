# 159 · Erdős’s reciprocal-sum conjecture and quasipolynomial Szemerédi bounds

**Subject:** Combinatorics

## The question, intuitively

If reciprocals of a set of integers have divergent sum, must the set contain arbitrarily long arithmetic progressions?

## Papers in this family

- [Quasipolynomial Bounds for Arithmetic Progressions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quasipolynomial-Bounds-for-Arithmetic-Progressions-September-23-2026/paper.pdf) — [note](../../papers/paper-1131ab1d9b9ef7d4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
