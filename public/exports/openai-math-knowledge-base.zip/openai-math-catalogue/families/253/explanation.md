# 253 · An infinite finitely presented simple amenable group

**Subject:** Group theory

## The question, intuitively

Can an infinite simple group be finitely presented while still admitting invariant averaging?

## Papers in this family

- [An infinite finitely presented simple amenable group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Infinite-Finitely-Presented-Simple-Amenable-Group-September-23-2026/paper.pdf) — [note](../../papers/paper-f8decb4ced2a4b24.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
