# 038 · Fujita’s freeness conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

How much positivity must be added to a canonical divisor before its sections have no common zero?

## Papers in this family

- [Fujita's freeness conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fujitas-freeness-conjecture-September-23-2026/Fujitas-freeness-conjecture-September-23-2026.pdf) — [note](../../papers/paper-2cc2bedc293afb0a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
