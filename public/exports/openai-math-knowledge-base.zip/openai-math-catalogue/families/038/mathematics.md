# 038 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Fujita's freeness conjecture at its sharp bound in every dimension: for a smooth projective complex variety X of dimension n and an ample line bundle L, the adjoint $K_X+mL$ is globally generated for every integer $m\ge n+1$.

## Fujita's freeness conjecture

We prove Fujita's freeness conjecture. If X is a smooth complex projective variety of dimension n and L is an ample line bundle, then $K_X+mL$ is globally generated for every integer $m\geq n+1$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fujitas-freeness-conjecture-September-23-2026/Fujitas-freeness-conjecture-September-23-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fujitas-freeness-conjecture-September-23-2026)
