# 157 · Graph coloring, clique minors, and Colin de Verdière invariants

**Subject:** Combinatorics

## The question, intuitively

How closely are graph colorability, complete-graph minors, and spectral graph invariants connected?

## Papers in this family

- [A counterexample to Hadwiger's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Hadwigers-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-0ee12dde73281885.md)
- [A counterexample to the Colin de Verdière chromatic conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-the-Colin-de-Verdiere-chromatic-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-b25cd5f505bf81b5.md)
- [A linear list-coloring bound in terms of the Hadwiger number](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-linear-list-coloring-bound-in-terms-of-the-Hadwiger-number-September-23-2026/paper.pdf) — [note](../../papers/paper-8aaa0e2bce929557.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
