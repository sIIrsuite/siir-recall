# 219 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every fixed degree d ≥ 3, the bulk adjacency-eigenvalue point process of a uniform simple random d-regular graph converges to the Gaussian orthogonal ensemble law, including for cubic graphs. The same fixed-energy universality persists under sufficiently weak fixed iid uniform diagonal disorder, throughout compact bands strictly inside the clean spectral edges.

## Fixed-energy universality for weak Anderson disorder on random regular graphs

For every fixed degree d ≥ 3, we prove fixed-energy GOE universality for the adjacency matrix of a uniformly random simple labelled d-regular graph with independent uniform diagonal disorder. The disorder strength is positive, sufficiently small, and fixed as the graph grows. At each fixed energy in a compact subinterval of the clean spectral band, the full microscopic eigenvalue point process converges to the GOE bulk process after rescaling by the positive density of states of the corresponding infinite-tree operator. The permitted disorder strength depends on the degree and the distance from the clean spectral edges.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fixed-energy-universality-for-weak-Anderson-disorder-on-random-regular-graphs-October-5-2026/fixed-energy-universality-weak-anderson-disorder-random-regular-graphs.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fixed-energy-universality-for-weak-Anderson-disorder-on-random-regular-graphs-October-5-2026)

## GOE bulk universality for fixed-degree random regular graphs

We prove the fixed-degree bulk-universality conjecture for random regular graphs. For every fixed integer d ≥ 3 and every fixed energy in the open Kesten–McKay bulk, the unfolded eigenvalue point process of the adjacency matrix of a uniform simple labelled d-regular graph converges to the GOE bulk process. The convergence holds along all admissible graph sizes, without additional conditioning.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/GOE-bulk-universality-for-fixed-degree-random-regular-graphs-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/GOE-bulk-universality-for-fixed-degree-random-regular-graphs-September-23-2026)
