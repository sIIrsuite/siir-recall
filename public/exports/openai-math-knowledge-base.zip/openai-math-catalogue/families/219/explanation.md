# 219 · GOE bulk universality for regular graphs with weak Anderson disorder

**Subject:** Probability and statistical mechanics

## The question, intuitively

Do disordered regular-graph Hamiltonians have the universal local eigenvalue statistics predicted by random-matrix theory?

## Papers in this family

- [Fixed-energy universality for weak Anderson disorder on random regular graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fixed-energy-universality-for-weak-Anderson-disorder-on-random-regular-graphs-October-5-2026/fixed-energy-universality-weak-anderson-disorder-random-regular-graphs.pdf) — [note](../../papers/paper-0730226000ea3fe5.md)
- [GOE bulk universality for fixed-degree random regular graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/GOE-bulk-universality-for-fixed-degree-random-regular-graphs-September-23-2026/paper.pdf) — [note](../../papers/paper-ed95e96eb1dd9550.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
