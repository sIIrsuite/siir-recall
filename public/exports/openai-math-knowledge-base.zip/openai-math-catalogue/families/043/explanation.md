# 043 · P = W for fixed-determinant SL_{n} moduli spaces

**Subject:** Algebraic and complex geometry

## The question, intuitively

Do two filtrations arising from geometric fibrations and mixed Hodge theory encode exactly the same information?

## Papers in this family

- [P=W in composite rank for fixed determinant](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/P-equals-W-in-composite-rank-for-fixed-determinant-September-24-2026/P-equals-W-in-composite-rank-for-fixed-determinant-September-24-2026.pdf) — [note](../../papers/paper-1cf374a79985cce5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
