# 050 · A counterexample to Griffiths’ positivity conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Must every ample vector bundle admit a Hermitian metric with the stronger curvature positivity Griffiths predicted?

## Papers in this family

- [Ample rank-two bundles on the quadric surface without Griffiths-positive metrics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/ample-rank-two-bundles-on-the-quadric-surface-without-griffiths-positive-metrics-September-24-2026/paper.pdf) — [note](../../papers/paper-480e66aa8b91e7aa.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
