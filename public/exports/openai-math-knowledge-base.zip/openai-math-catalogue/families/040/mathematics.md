# 040 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Bloch's conjecture: for every smooth connected projective complex surface S with $p_g(S)=0$, the Albanese map $\mathrm{CH}_0(S)^0\to\mathrm{Alb}(S)(\mathbb C)$ on integral degree-zero zero-cycles is an isomorphism. This combines the new $p_g=q=0$ theorem with the classical theorem of Bloch, Kas, and Lieberman.

## Bloch’s conjecture for surfaces with p_g=0

We prove Bloch's conjecture for smooth connected projective complex surfaces with $p_g=0$: the Albanese homomorphism on integral degree-zero zero-cycles is an isomorphism.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Blochs-Conjecture-for-Surfaces-with-pg-equals-q-equals-0-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Blochs-Conjecture-for-Surfaces-with-pg-equals-q-equals-0-September-24-2026)
