# 040 · Bloch’s conjecture for complex surfaces

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can a complex surface with little holomorphic two-form information also have the predicted simple algebraic zero-cycle structure?

## Papers in this family

- [Bloch’s conjecture for surfaces with p_g=0](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Blochs-Conjecture-for-Surfaces-with-pg-equals-q-equals-0-September-24-2026/paper.pdf) — [note](../../papers/paper-1ab9b4fafafc4c96.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
