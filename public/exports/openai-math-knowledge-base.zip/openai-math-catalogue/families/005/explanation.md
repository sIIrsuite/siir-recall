# 005 · Irrationality of Catalan’s constant

**Subject:** Number theory

## The question, intuitively

Can the alternating sum of reciprocal odd squares ever equal a ratio of two integers?

## Papers in this family

- [Catalan's constant is irrational](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Catalans-constant-is-irrational-September-24-2026/paper.pdf) — [note](../../papers/paper-fdc68c5049b55490.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
