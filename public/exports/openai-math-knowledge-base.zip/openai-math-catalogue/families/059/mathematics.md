# 059 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Disproves Zariski's multiplicity conjecture by constructing reduced holomorphic hypersurface germs that are ambiently homeomorphic but have different multiplicities. The examples include hypersurfaces in ℂ^{4} with isolated critical points and multiplicities four and five.

## Ambiently homeomorphic isolated hypersurfaces of multiplicities two and three

We give a negative answer to the embedded Zariski multiplicity conjecture. We construct two reduced hypersurface germs that are ambiently homeomorphic but have multiplicities two and three. Both have isolated singularities and lie in a common complex affine space of dimension divisible by eight. Their defining function germs are also topologically right equivalent, and the same examples answer Arnold's corank problem negatively for ambient topological equivalence.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurfaces-of-multiplicities-two-and-three-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurfaces-of-multiplicities-two-and-three-September-24-2026)

## Ambiently homeomorphic isolated hypersurface germs in ℂ⁴ with multiplicities four and five

We give a negative answer to Zariski's multiplicity question in four complex variables. We construct two reduced convergent holomorphic function germs with isolated critical points and multiplicities four and five whose zero-set germs are ambiently homeomorphic.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurface-germs-in-C4-with-multiplicities-four-and-five-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurface-germs-in-C4-with-multiplicities-four-and-five-September-27-2026)
