# 059 · Counterexamples to Zariski’s multiplicity conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can two topologically equivalent complex singularities have different algebraic multiplicities?

## Papers in this family

- [Ambiently homeomorphic isolated hypersurfaces of multiplicities two and three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurfaces-of-multiplicities-two-and-three-September-24-2026/paper.pdf) — [note](../../papers/paper-b37600a212e7ade9.md)
- [Ambiently homeomorphic isolated hypersurface germs in ℂ⁴ with multiplicities four and five](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurface-germs-in-C4-with-multiplicities-four-and-five-September-27-2026/paper.pdf) — [note](../../papers/paper-023c99253d0c28f5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
