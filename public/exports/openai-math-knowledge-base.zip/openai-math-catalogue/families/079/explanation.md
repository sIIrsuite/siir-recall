# 079 · Local smoothing in three dimensions

**Subject:** Real and complex analysis

## The question, intuitively

Does averaging a moving wave over time improve its spatial regularity by the predicted amount?

## Papers in this family

- [Critical local smoothing for the three-dimensional wave equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-local-smoothing-for-the-three-dimensional-wave-equation-September-24-2026/paper.pdf) — [note](../../papers/paper-eb51b4d542e20f27.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
