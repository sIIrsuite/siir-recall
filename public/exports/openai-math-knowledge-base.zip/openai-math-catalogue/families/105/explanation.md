# 105 · Perfect completeness for 2-to-1 games

**Subject:** Theoretical computer science

## The question, intuitively

Can a constraint game be hard to approximate even when all constraints in the favorable case are exactly satisfiable?

## Papers in this family

- [Perfect completeness for 2-to-1 games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Perfect-completeness-for-2-to-1-games-September-23-2026/paper.pdf) — [note](../../papers/paper-c4e4969e26d43b50.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
