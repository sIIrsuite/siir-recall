# 203 · Donovan's conjecture over fields and complete mixed-characteristic DVRs

**Subject:** Algebra

## The question, intuitively

For a fixed defect group, are there only finitely many essential types of modular representation blocks?

## Papers in this family

- [Donovan's Conjecture over Algebraically Closed Fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Donovans-Conjecture-over-Algebraic-Closures-of-Prime-Fields-September-24-2026/main.pdf) — [note](../../papers/paper-f3253c6ba2a6d7d5.md)
- [Integral Donovan Finiteness over Witt Vectors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-Donovan-Finiteness-over-Witt-Vectors-September-25-2026/main.pdf) — [note](../../papers/paper-6dd4e927f0310535.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
