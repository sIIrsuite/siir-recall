# 203 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Donovan's conjecture: over each fixed algebraically closed field of characteristic p, blocks of finite groups with bounded defect-group order have only finitely many Morita-equivalence classes, for every prime p. Also proves the integral form over each fixed complete mixed-characteristic discrete valuation ring with algebraically closed residue field.

## Donovan's Conjecture over Algebraically Closed Fields

We prove Donovan's conjecture over every algebraically closed field K of characteristic p > 0. For each fixed K and bound on defect-group order, blocks of finite groups represent only finitely many K-linear Morita equivalence classes. The defect groups need not be abelian, and the result includes p = 2.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Donovans-Conjecture-over-Algebraic-Closures-of-Prime-Fields-September-24-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Donovans-Conjecture-over-Algebraic-Closures-of-Prime-Fields-September-24-2026)

## Integral Donovan Finiteness over Witt Vectors

We prove integral Donovan finiteness: for every prime p and positive integer M, the blocks of all finite groups with defect groups of order at most M have only finitely many Morita equivalence classes over $W(\overline{\mathbb F}_p)$. The defect groups need not be abelian, and the result includes p = 2. The same bounded-defect finiteness holds over each fixed complete discrete valuation ring of characteristic zero with algebraically closed residue field of characteristic p, including ramified rings.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-Donovan-Finiteness-over-Witt-Vectors-September-25-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-Donovan-Finiteness-over-Witt-Vectors-September-25-2026)
