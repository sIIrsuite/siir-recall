# 247 · An infinite finitely presented residually finite 2-group and a finitely presented nil algebra

**Subject:** Group theory

## The question, intuitively

Can an infinite group with only power-of-two torsion be finitely presented and still distinguished by finite quotients?

## Papers in this family

- [An infinite finitely presented residually finite 2-group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-infinite-finitely-presented-residually-finite-2-group-October-5-2026/residually-finite-torsion.pdf) — [note](../../papers/paper-4e295cb76423504c.md)
- [An infinite finitely presented periodic group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-infinite-finitely-presented-periodic-group-September-23-2026/paper.pdf) — [note](../../papers/paper-f109d87e3a42937d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
