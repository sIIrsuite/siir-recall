# 085 · Endpoint Sobolev regularity of centered disk averages

**Subject:** Real and complex analysis

## The question, intuitively

How much differentiability can survive taking the largest centered average over disks?

## Papers in this family

- [An Endpoint Gradient Bound for the Centered Disk Maximal Operator](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Endpoint-Gradient-Bound-for-the-Centered-Disk-Maximal-Operator-September-26-2026/article.pdf) — [note](../../papers/paper-3eee048d7739e517.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
