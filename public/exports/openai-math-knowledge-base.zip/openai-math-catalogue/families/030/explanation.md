# 030 · Modularity of elliptic curves over imaginary quadratic fields

**Subject:** Number theory

## The question, intuitively

Do elliptic curves over imaginary quadratic fields correspond to the predicted modular objects?

## Papers in this family

- [Modularity of elliptic curves over imaginary quadratic fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Modularity-of-elliptic-curves-over-imaginary-quadratic-fields-October-4-2026/paper.pdf) — [note](../../papers/paper-d5bba57c7bc17855.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
