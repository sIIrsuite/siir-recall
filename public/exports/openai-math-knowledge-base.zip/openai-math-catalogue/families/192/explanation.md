# 192 · Boolean functions violate the square-root degree bound by arbitrary factors

**Subject:** Combinatorics

## The question, intuitively

How far can Boolean-function sensitivity exceed a bound suggested by the square root of polynomial degree?

## Papers in this family

- [Unbounded Violations of the Square-Root Degree Bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unbounded-Violations-of-the-Square-Root-Degree-Bound-September-26-2026/Unbounded-Violations-of-the-Square-Root-Degree-Bound-September-26-2026.pdf) — [note](../../papers/paper-2d51b23708e7ed92.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
