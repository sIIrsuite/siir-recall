# 194 · Lech’s multiplicity conjecture

**Subject:** Algebra

## The question, intuitively

How does the multiplicity of a local algebra change under a flat extension?

## Papers in this family

- [Lech's multiplicity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lechs-multiplicity-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-18bb880a24f980dc.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
