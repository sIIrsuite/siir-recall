# 064 · Topological triviality of μ-constant surface singularities

**Subject:** Algebraic and complex geometry

## The question, intuitively

If a family of surface singularities keeps its Milnor number fixed, must its local topology remain unchanged?

## Papers in this family

- [Topological triviality of mu-constant families of surface singularities](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Topological-triviality-of-mu-constant-families-of-surface-singularities-September-24-2026/main.pdf) — [note](../../papers/paper-fbba4579fd09c2ed.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
