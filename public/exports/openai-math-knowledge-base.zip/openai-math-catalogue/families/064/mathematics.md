# 064 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves topological right-triviality for every holomorphic one-parameter family of isolated hypersurface singularities in ℂ^{3} with constant Milnor number, resolving the surface case of the μ-constant problem. After shrinking the parameter disk and representatives, ambient homeomorphisms vary jointly continuously, fix the origin section and preserve the defining functions.

## Topological triviality of mu-constant families of surface singularities

We prove that every holomorphic one-parameter family of isolated hypersurface singularities in ℂ^{3} with constant Milnor number is topologically right-trivial. This gives a positive answer to the surface case of the μ-constant problem. The trivialization fixes the parameter and the origin section, and preserves the defining functions.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Topological-triviality-of-mu-constant-families-of-surface-singularities-September-24-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Topological-triviality-of-mu-constant-families-of-surface-singularities-September-24-2026)
