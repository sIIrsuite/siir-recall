# 142 · Deterministic polynomial factorization over prime fields

**Subject:** Theoretical computer science

## The question, intuitively

Can a deterministic efficient algorithm factor polynomials over every prime field?

## Papers in this family

- [Deterministic Polynomial Factorization over Prime Fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-Polynomial-Factorization-over-Prime-Fields-October-4-2026/Deterministic-Polynomial-Factorization-over-Prime-Fields.pdf) — [note](../../papers/paper-783e6a92fa7af25a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
