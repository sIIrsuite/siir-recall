# 093 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves a dimension-free logarithmic Sobolev inequality for centered log-concave densities with uniformly subgaussian linear marginals, with constant bounded by a universal multiple of the squared linear subgaussian parameter.

## A dimension-free logarithmic Sobolev inequality for subgaussian log-concave measures

We prove that every centered log-concave probability measure with a Lebesgue density on ℝ^{n} and linear subgaussian parameter a satisfies $\mathop{\mathrm{Ent}}\nolimits _\mu(f^2)\le Ca^2\int|Df|^2\,d\mu$ for compactly supported smooth f, with one universal constant C. This resolves positively the dimension-free logarithmic Sobolev conjecture for subgaussian log-concave measures.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026)
