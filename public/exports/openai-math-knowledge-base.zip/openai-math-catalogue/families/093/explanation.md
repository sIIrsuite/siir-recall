# 093 · Dimension-free logarithmic Sobolev inequality for subgaussian log-concave measures

**Subject:** Convex and metric geometry

## The question, intuitively

Can concentration and entropy control for sufficiently regular log-concave distributions be independent of dimension?

## Papers in this family

- [A dimension-free logarithmic Sobolev inequality for subgaussian log-concave measures](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026/paper.pdf) — [note](../../papers/paper-c082d973442fd637.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
