# 195 · A counterexample to the small Cohen–Macaulay module conjecture

**Subject:** Algebra

## The question, intuitively

Must every suitable local ring admit a small module with the strongest expected depth properties?

## Papers in this family

- [A Complete Local Domain without a Small Cohen–Macaulay Module](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Complete-Local-Domain-Without-a-Small-Cohen-Macaulay-Module-September-23-2026/paper.pdf) — [note](../../papers/paper-72b09de8e10f8ce3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
