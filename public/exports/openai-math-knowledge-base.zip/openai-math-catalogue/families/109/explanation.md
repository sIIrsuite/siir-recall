# 109 · Integer multiplication below $n\log n$

**Subject:** Theoretical computer science

## The question, intuitively

Can multiplying two n-bit integers asymptotically beat the n-log-n running-time scale?

## Papers in this family

- [Integer multiplication below n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integer-multiplication-below-n-log-n-September-23-2026/paper.pdf) — [note](../../papers/paper-0a12f9cb68425145.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
