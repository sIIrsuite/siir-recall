# 029 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the infinitude assertion in Artin's primitive root conjecture for every integer a that is neither −1 nor a square. For each such base, at least $c_a x/(\log x)^2$ primes in every sufficiently large interval $(x,2x)$ have primitive root a, with $c_a> 0$.

## Primitive roots for every admissible integer base

We prove the infinitude assertion in Artin's primitive root conjecture: for every integer a that is neither −1 nor a square, there are at least $c_a x/(\log x)^2$ primes in $(x,2x)$ with primitive root a, for some $c_a> 0$ and every sufficiently large x.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026/primitive-roots-all-integer-bases.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026)

## Simultaneous primitive roots: a conditional lower bound for prime bases

For every fixed finite set of distinct positive primes, we prove that at least $cx/(\log x)^2$ primes in $(x,2x)$ have every member of the set as a primitive root, for some c > 0 and all sufficiently large x. The result assumes four explicitly stated analytic and sieve inputs from the companion paper on primitive roots for admissible integer bases.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simultaneous-primitive-roots-a-conditional-lower-bound-for-prime-bases-October-4-2026/simultaneous-primitive-roots-conditional-lower-bound-prime-bases.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simultaneous-primitive-roots-a-conditional-lower-bound-for-prime-bases-October-4-2026)
