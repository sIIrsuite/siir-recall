# 029 · Primitive roots for every admissible integer base

**Subject:** Number theory

## The question, intuitively

For a fixed admissible integer, are there enough primes for which its powers generate every nonzero residue?

## Papers in this family

- [Primitive roots for every admissible integer base](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026/primitive-roots-all-integer-bases.pdf) — [note](../../papers/paper-76cde1fd28d1b97b.md)
- [Simultaneous primitive roots: a conditional lower bound for prime bases](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simultaneous-primitive-roots-a-conditional-lower-bound-for-prime-bases-October-4-2026/simultaneous-primitive-roots-conditional-lower-bound-prime-bases.pdf) — [note](../../papers/paper-b3df55700f873490.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
