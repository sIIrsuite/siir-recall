# 013 · Ostmann’s inverse Goldbach conjecture

**Subject:** Number theory

## The question, intuitively

Can the prime numbers eventually be decomposed as the sum of two genuinely smaller infinite sets?

## Papers in this family

- [The additive indecomposability of the primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/the-additive-indecomposability-of-the-primes-September-24-2026/paper.pdf) — [note](../../papers/paper-43fb111777b443f4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
