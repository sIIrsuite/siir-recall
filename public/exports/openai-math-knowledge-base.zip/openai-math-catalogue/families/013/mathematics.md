# 013 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that no finite modification of the primes can be written as $A+B$ with $A,B\subseteq\mathbb Z_{\ge0}$ each containing at least two elements. This resolves Ostmann's inverse Goldbach conjecture on additive indecomposability. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/013.md))

## The additive indecomposability of the primes

We prove Ostmann's inverse Goldbach conjecture: no set differing from the primes by finitely many elements can be written as $A+B$, where A and B are sets of nonnegative integers with at least two elements each.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/the-additive-indecomposability-of-the-primes-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/the-additive-indecomposability-of-the-primes-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/013.md). A family link does not certify every claim or every companion paper.
