# 056 · Termination of projective and Kähler fourfold minimal model programs

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can repeated canonical simplification steps in a four-dimensional geometric space continue forever?

## Papers in this family

- [Termination of generalized log canonical flips on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-of-generalized-log-canonical-flips-on-compact-Kahler-fourfolds-October-7-2026/termination-generalized-lc-kahler-fourfolds.pdf) — [note](../../papers/paper-4f3458b40983a327.md)
- [Termination of generalized-canonical flips on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-of-generalized-canonical-flips-on-compact-Kahler-fourfolds-October-6-2026/termination-generalized-terminal-flips-compact-kahler-fourfolds.pdf) — [note](../../papers/paper-ce38a1375ede8564.md)
- [Termination for projective log canonical fourfolds with rational boundary](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-for-projective-log-canonical-fourfolds-with-rational-boundary-September-24-2026/paper.pdf) — [note](../../papers/paper-07726b1ad079bcd5.md)
- [Finite ordinary minimal model programs on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-ordinary-minimal-model-programs-on-compact-Kahler-fourfolds-October-6-2026/paper.pdf) — [note](../../papers/paper-d03c3408afe701c9.md)
- [Finite ordinary minimal model programs on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-ordinary-minimal-model-programs-on-compact-Kahler-fourfolds-September-24-2026/paper.pdf) — [note](../../papers/paper-9cd0efd421231a3b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
