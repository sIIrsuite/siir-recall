# 097 · The Euclidean Steinitz–Bergström bound

**Subject:** Convex and metric geometry

## The question, intuitively

How tightly can vectors summing to zero be ordered so that every partial sum stays small?

## Papers in this family

- [The Euclidean Steinitz–Bergström theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Euclidean-Steinitz-Bergstrom-theorem-September-24-2026/The-Euclidean-Steinitz-Bergstrom-theorem-September-24-2026.pdf) — [note](../../papers/paper-53028b12bb04f949.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
