# 095 · Hyperbolicity cones without semidefinite lifts

**Subject:** Convex and metric geometry

## The question, intuitively

Can every convex cone defined by a hyperbolic polynomial be represented through a larger semidefinite constraint?

## Papers in this family

- [Hyperbolicity Cones Without Semidefinite Lifts](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hyperbolicity-Cones-Without-Semidefinite-Lifts-October-5-2026/nonliftable-hyperbolicity.pdf) — [note](../../papers/paper-d2a2e35ed58f7add.md)
- [A nonspectrahedral hyperbolicity cone](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Nonspectrahedral-Hyperbolicity-Cone-September-24-2026/nonspectrahedral-hyperbolicity-cone.pdf) — [note](../../papers/paper-784dd751a0bb3112.md)
- [An Exact Semidefinite Lift of a Nonspectrahedral Hyperbolicity Cone](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Exact-Semidefinite-Lift-of-a-Nonspectrahedral-Hyperbolicity-Cone-October-5-2026/Exact-Semidefinite-Lift-of-a-Nonspectrahedral-Hyperbolicity-Cone.pdf) — [note](../../papers/paper-adcffb5675009b3b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
