# 037 · The ordinary-double-point volume gap

**Subject:** Algebraic and complex geometry

## The question, intuitively

Is the simplest quadratic singularity separated from all other singularities by a sharp volume gap?

## Papers in this family

- [The ordinary-double-point gap in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-ordinary-double-point-gap-in-every-dimension-September-24-2026/paper.pdf) — [note](../../papers/paper-a37e1240d4559d92.md)
- [The normalized-volume gap in dimension four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-normalized-volume-gap-in-dimension-four-September-24-2026/paper.pdf) — [note](../../papers/paper-6d0756f02d665ccc.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
