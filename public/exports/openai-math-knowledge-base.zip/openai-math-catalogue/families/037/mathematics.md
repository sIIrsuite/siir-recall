# 037 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the ordinary-double-point volume-gap conjecture: every singular complex algebraic klt germ of dimension n ≥ 2, with zero boundary, has normalized volume at most $2(n-1)^n$. Equality holds precisely for an analytic ordinary double point.

## The ordinary-double-point gap in every dimension

We prove the ordinary-double-point gap conjecture for boundary-zero complex algebraic klt germs in every dimension: a singular n-dimensional germ has normalized volume at most $2(n-1)^n$, with equality precisely at an analytic ordinary double point.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-ordinary-double-point-gap-in-every-dimension-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-ordinary-double-point-gap-in-every-dimension-September-24-2026)

## The normalized-volume gap in dimension four

We prove that every singular complex algebraic klt fourfold germ with zero boundary has normalized volume at most 162, with equality precisely for an analytic ordinary double point. This resolves the ordinary-double-point volume-gap conjecture in dimension four.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-normalized-volume-gap-in-dimension-four-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-normalized-volume-gap-in-dimension-four-September-24-2026)
