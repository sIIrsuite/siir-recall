# 139 · Subpolynomial query complexity for log-concave sampling

**Subject:** Theoretical computer science

## The question, intuitively

How many oracle queries are fundamentally needed to sample from a log-concave distribution?

## Papers in this family

- [Subpolynomial query complexity for well-conditioned log-concave sampling](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-query-complexity-for-well-conditioned-log-concave-sampling-September-26-2026/article.pdf) — [note](../../papers/paper-e54200c0718980f7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
