# 051 · Kobayashi’s canonical-ampleness conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Does a projective space with no entire complex curves have a positive canonical bundle?

## Papers in this family

- [Canonical ampleness of compact hyperbolic Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Canonical-ampleness-of-compact-hyperbolic-Kahler-manifolds-September-23-2026/canonical-ampleness.pdf) — [note](../../papers/paper-26bad5fbc8b3e71d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
