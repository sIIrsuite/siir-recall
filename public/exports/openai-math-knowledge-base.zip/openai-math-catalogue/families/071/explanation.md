# 071 · Koebe’s circle-domain conjecture

**Subject:** Real and complex analysis

## The question, intuitively

Can every planar domain be conformally reshaped so that each boundary component is a circle or a point?

## Papers in this family

- [Removable Boundaries and Rigidity of Circle Domains](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Removable-Boundaries-and-Rigidity-of-Circle-Domains-September-23-2026/paper.pdf) — [note](../../papers/paper-eae0bfcc638e4874.md)
- [Koebe's Circle-Domain Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Koebes-Circle-Domain-Conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-635c35e8df0005bf.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
