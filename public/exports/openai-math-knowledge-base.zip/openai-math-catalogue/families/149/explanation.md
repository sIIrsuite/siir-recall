# 149 · Classwise permanence for weakly reversible mass-action systems

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Can concentrations in a weakly reversible chemical reaction system stay uniformly away from extinction and infinity within each reaction class?

## Papers in this family

- [Uniform Permanence in Weakly Reversible Mass-Action Systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/permanence.pdf) — [note](../../papers/paper-7b0760997a117bea.md)
- [Boundedness and persistence of weakly reversible mass-action systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Boundedness-and-persistence-of-weakly-reversible-mass-action-systems-September-25-2026/paper.pdf) — [note](../../papers/paper-cdb5a46fab141971.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
