# 002 · The full BSD formula from low Selmer corank

**Subject:** Number theory

## The question, intuitively

Can counting solutions modulo primes predict both the number of independent rational points on an elliptic curve and the exact arithmetic factors in that prediction?

## Papers in this family

- [Exact Birch–Swinnerton-Dyer Formula from Low Selmer Corank](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Birch-Swinnerton-Dyer-Formula-from-Low-Selmer-Corank-October-7-2026/exact-bsd-low-selmer-corank.pdf) — [note](../../papers/paper-aee3a541adf87fc6.md)
- [The Selmer converse for elliptic curves at every prime](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Selmer-converse-for-elliptic-curves-at-every-prime-October-7-2026/main.pdf) — [note](../../papers/paper-c2730d2162c4ba85.md)
- [The two-primary Birch–Swinnerton-Dyer formula in Selmer corank at most one](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-two-primary-Birch-Swinnerton-Dyer-formula-in-Selmer-corank-at-most-one-October-6-2026/paper.pdf) — [note](../../papers/paper-ea57f249dfa58a57.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
