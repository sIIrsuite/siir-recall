# 004 · Hilbert’s tenth problem over ℚ

**Subject:** Number theory

## The question, intuitively

Could a universal algorithm decide whether any polynomial equation has a solution made entirely of fractions?

## Papers in this family

- [Hilbert’s tenth problem over the rational numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hilberts-tenth-problem-over-the-rational-numbers-October-6-2026/main.pdf) — [note](../../papers/paper-348091debfddac2f.md)
- [A pointwise 2-converse for elliptic curves with rational two-torsion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-pointwise-2-converse-for-elliptic-curves-with-rational-two-torsion-October-7-2026/paper.pdf) — [note](../../papers/paper-a41c29e7a091e9ca.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
