# 240 · Shelah's eventual categoricity and the prescribed-threshold obstruction

**Subject:** Mathematical logic

## The question, intuitively

When does having a unique model at one large cardinality force uniqueness at every sufficiently large cardinality?

## Papers in this family

- [A CH obstruction to a prescribed categoricity threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-CH-Obstruction-to-a-Prescribed-Categoricity-Threshold-September-24-2026/paper.pdf) — [note](../../papers/paper-84beafdd9fce9805.md)
- [Eventual categoricity for abstract elementary classes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Eventual-Categoricity-for-Abstract-Elementary-Classes-September-24-2026/paper.pdf) — [note](../../papers/paper-5ca05aedac5e06f3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
