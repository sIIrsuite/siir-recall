# 193 · Serre’s intersection-multiplicity conjecture

**Subject:** Algebra

## The question, intuitively

Are local intersection multiplicities positive whenever two algebraic objects meet in complementary dimensions?

## Papers in this family

- [Positivity of Serre's Intersection Multiplicity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positivity-of-Serres-Intersection-Multiplicity-September-23-2026/paper.pdf) — [note](../../papers/paper-46e74710c1076053.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
