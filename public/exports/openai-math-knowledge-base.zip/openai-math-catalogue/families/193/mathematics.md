# 193 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves strict positivity of Serre's intersection multiplicity $\chi^R(M,N)$ for nonzero finitely generated modules over any regular local ring, provided $M\otimes_R N$ has finite length and $\dim M+\dim N=\dim R$. This resolves the positivity conjecture, including ramified mixed characteristic.

## Positivity of Serre's Intersection Multiplicity

We prove Serre's positivity conjecture, including ramified mixed characteristic. If two nonzero finitely generated modules over a regular local ring have tensor product of finite length and complementary dimensions, then their intersection multiplicity is strictly positive.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positivity-of-Serres-Intersection-Multiplicity-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positivity-of-Serres-Intersection-Multiplicity-September-23-2026)
