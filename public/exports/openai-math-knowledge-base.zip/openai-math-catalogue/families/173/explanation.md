# 173 · Seymour’s second-neighborhood conjecture

**Subject:** Combinatorics

## The question, intuitively

Must every oriented graph contain a vertex with at least as many second neighbors as first neighbors?

## Papers in this family

- [A proof of Seymour’s second-neighborhood conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-proof-of-Seymours-second-neighborhood-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-dc2fb20975a083ca.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
