# 230 · Exact Hausdorff gauges for SLE

**Subject:** Probability and statistical mechanics

## The question, intuitively

What is the exact small-scale measure needed to assign finite nonzero size to an SLE random curve?

## Papers in this family

- [An exact Hausdorff gauge for SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exact-Hausdorff-gauge-for-SLE-September-25-2026/An-exact-Hausdorff-gauge-for-SLE-September-25-2026.pdf) — [note](../../papers/paper-595b167a5f0195a9.md)
- [An explicit exact Hausdorff gauge for SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-exact-Hausdorff-gauge-for-SLE-September-26-2026/An-explicit-exact-Hausdorff-gauge-for-SLE-September-26-2026.pdf) — [note](../../papers/paper-74027cb9996b8ae9.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
