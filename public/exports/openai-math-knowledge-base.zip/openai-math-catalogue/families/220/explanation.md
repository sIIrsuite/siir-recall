# 220 · Directional zero–one laws beyond iid environments and iid ballisticity

**Subject:** Probability and statistical mechanics

## The question, intuitively

Must a random walk in a random environment eventually choose a direction, and when does it acquire positive speed?

## Papers in this family

- [A directional zero–one law for finite-range-dependent random environments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-directional-zero-one-law-for-finite-range-dependent-random-environments-October-5-2026/directional-zero-one-finite-range.pdf) — [note](../../papers/paper-7f151483b202acc9.md)
- [A directional zero–one law under strict ellipticity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-directional-zero-one-law-under-strict-ellipticity-September-23-2026/paper.pdf) — [note](../../papers/paper-b641f210bbf49e8d.md)
- [Directional transience implies ballisticity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Directional-transience-implies-ballisticity-September-23-2026/paper.pdf) — [note](../../papers/paper-e372ffc986a23c4a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
