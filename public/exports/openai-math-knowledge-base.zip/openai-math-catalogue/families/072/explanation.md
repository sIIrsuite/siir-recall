# 072 · Brennan's conjecture and the integral-means spectrum

**Subject:** Real and complex analysis

## The question, intuitively

How concentrated can the derivative of a conformal map become near the boundary, while still remaining integrable?

## Papers in this family

- [Brennan's conjecture and sharp inverse-square integral means](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brennans-conjecture-and-sharp-inverse-square-integral-means-September-24-2026/paper.pdf) — [note](../../papers/paper-ca3c127f5aba8ab3.md)
- [A strict inverse-first-power bound for univalent functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-inverse-first-power-bound-for-univalent-functions-September-24-2026/paper.pdf) — [note](../../papers/paper-8e29cc8f4983e207.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
