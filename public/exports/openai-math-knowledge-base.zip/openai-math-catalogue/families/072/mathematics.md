# 072 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Brennan's conjecture: for every conformal bijection ϕ from a simply connected plane domain onto the disk, $|\phi'|^s$ is area-integrable for $4/3< s< 4$. The sharp universal integral-means identity is $B_{\mathcal S}(t)=|t|-1$ for t ≤ −2. A strict bound $B_b(-1)< 1/4$ for bounded univalent functions disproves Kraetzer's prediction at that parameter. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/072.md))

## Brennan's conjecture and sharp inverse-square integral means

We prove Brennan's conjecture: if a simply connected plane domain admits a conformal bijection φ onto the unit disk, then $|\varphi'|^s$ is area-integrable for every $4/3< s< 4$. We also prove the sharp inverse-square integral-means exponent $B_{\mathcal S}(-2)=1$ for the normalized schlicht class $\mathcal S$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brennans-conjecture-and-sharp-inverse-square-integral-means-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brennans-conjecture-and-sharp-inverse-square-integral-means-September-24-2026)

## A strict inverse-first-power bound for univalent functions

We prove a uniform upper bound for inverse-first-power integral means of normalized univalent disk maps with exponent strictly below 1/4. Consequently, the bounded universal integral-means spectrum satisfies $B_b(-1)< 1/4$, disproving Kraetzer's conjectured spectrum at p = −1.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-inverse-first-power-bound-for-univalent-functions-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-inverse-first-power-bound-for-univalent-functions-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/072.md). A family link does not certify every claim or every companion paper.
