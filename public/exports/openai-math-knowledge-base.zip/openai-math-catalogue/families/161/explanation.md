# 161 · Counterexamples to Sidorenko’s conjecture and the forcing conjecture

**Subject:** Combinatorics

## The question, intuitively

Must a graph always appear at least as frequently as in a random graph of the same edge density?

## Papers in this family

- [A counterexample to Sidorenko's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Sidorenkos-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-5e6ce4ba6e75683f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
