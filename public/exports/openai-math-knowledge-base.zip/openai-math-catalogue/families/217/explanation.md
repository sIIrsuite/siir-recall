# 217 · The low-temperature Sherrington–Kirkpatrick fluctuation law

**Subject:** Probability and statistical mechanics

## The question, intuitively

What is the limiting distribution of free-energy fluctuations in a low-temperature mean-field spin glass?

## Papers in this family

- [The low-temperature Sherrington–Kirkpatrick free-energy limiting law](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-low-temperature-Sherrington-Kirkpatrick-free-energy-limiting-law-September-24-2026/The-low-temperature-Sherrington-Kirkpatrick-free-energy-limiting-law-September-24-2026.pdf) — [note](../../papers/paper-5f785902249adfa9.md)
- [The low-temperature Sherrington–Kirkpatrick fluctuation scale](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-low-temperature-Sherrington-Kirkpatrick-fluctuation-scale-September-24-2026/The-low-temperature-Sherrington-Kirkpatrick-fluctuation-scale-September-24-2026.pdf) — [note](../../papers/paper-d80587de7e1d2ca7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
