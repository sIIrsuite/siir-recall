# 009 · Function-field reconstruction from Milnor K-theory and Galois data

**Subject:** Number theory

## The question, intuitively

How much of a field can you reconstruct from information about multiplication and the symmetries of its algebraic extensions?

## Papers in this family

- [Reconstruction of Function Fields from Mod-ℓ Milnor K-Theory](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Reconstruction-of-Function-Fields-from-Mod-ell-Milnor-K-Theory-October-5-2026/mod-ell-bogomolov-pop.pdf) — [note](../../papers/paper-45e07fd3de5cedac.md)
- [Reconstruction from Milnor K-theory modulo the characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Reconstruction-from-Milnor-K-theory-modulo-the-characteristic-October-5-2026/paper.pdf) — [note](../../papers/paper-accc0683da8d3452.md)
- [The Bogomolov-Pop reconstruction theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Bogomolov-Pop-reconstruction-theorem-September-23-2026/paper.pdf) — [note](../../papers/paper-be169f950b63e3af.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
