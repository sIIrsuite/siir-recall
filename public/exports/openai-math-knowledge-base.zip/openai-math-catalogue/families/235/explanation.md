# 235 · Limiting random SAT thresholds, sharp variance and computability

**Subject:** Probability and statistical mechanics

## The question, intuitively

At what density do random logical clauses cease to be satisfiable, and how sharply and computably does this threshold emerge?

## Papers in this family

- [A Limiting Satisfiability Threshold for Every Fixed Clause Size](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Limiting-Satisfiability-Threshold-for-Every-Fixed-Clause-Size-September-25-2026/article.pdf) — [note](../../papers/paper-0c2d60b5ad8399b2.md)
- [Linear Variance of the Random 3-SAT Hitting Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Linear-Variance-of-the-Random-3-SAT-Hitting-Time-October-5-2026/linear-variance-of-the-random-3-sat-hitting-time.pdf) — [note](../../papers/paper-54be7a75dcfeebdb.md)
- [Variance of the Random k-SAT Hitting Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Variance-of-the-Random-k-SAT-Hitting-Time-September-27-2026/article.pdf) — [note](../../papers/paper-85813da1afdaac6b.md)
- [Computing the Random 3-SAT Threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Computing-the-Random-3-SAT-Threshold-September-27-2026/article.pdf) — [note](../../papers/paper-558249bc91fec857.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
