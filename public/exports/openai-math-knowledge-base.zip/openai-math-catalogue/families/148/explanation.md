# 148 · The entropy-rate dimension formula for self-similar measures

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

How does symbolic randomness translate into geometric dimension when self-similar pieces can overlap?

## Papers in this family

- [The entropy-rate dimension formula for self-similar measures on the line](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-entropy-rate-dimension-formula-for-self-similar-measures-on-the-line-September-24-2026/main.pdf) — [note](../../papers/paper-65096e5482344316.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
