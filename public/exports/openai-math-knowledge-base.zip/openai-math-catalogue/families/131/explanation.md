# 131 · Rapid mixing of graph switches for every degree sequence

**Subject:** Theoretical computer science

## The question, intuitively

Do local edge-switch moves efficiently randomize graphs with any fixed feasible degree sequence?

## Papers in this family

- [Polynomial mixing of the switch chain for every graphical degree sequence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026/main.pdf) — [note](../../papers/paper-5c889f87b7686754.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
