# 078 · The three-dimensional Bochner–Riesz conjecture

**Subject:** Real and complex analysis

## The question, intuitively

At what exponents do smoothed spherical Fourier cutoffs define bounded operators in three dimensions?

## Papers in this family

- [Bochner–Riesz multipliers in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bochner-Riesz-Multipliers-in-Three-Dimensions-September-24-2026/Bochner-Riesz-Multipliers-in-Three-Dimensions-September-24-2026.pdf) — [note](../../papers/paper-55986c5ee747efe3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
