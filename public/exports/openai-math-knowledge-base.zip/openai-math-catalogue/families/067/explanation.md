# 067 · The Campana–Peternell conjecture in dimension six

**Subject:** Algebraic and complex geometry

## The question, intuitively

If a Fano manifold's tangent bundle is numerically positive, must it be homogeneous in the stated six-dimensional case?

## Papers in this family

- [The Campana–Peternell conjecture in dimension six](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Campana-Peternell-conjecture-in-dimension-six-September-25-2026/main.pdf) — [note](../../papers/paper-a9206135c76f2805.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
