# 067 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the Campana–Peternell conjecture in complex dimension six: every smooth connected complex projective Fano sixfold with nef tangent bundle is rational homogeneous.

## The Campana–Peternell conjecture in dimension six

We prove that every smooth connected complex projective Fano sixfold with nef tangent bundle is rational homogeneous, resolving the Campana–Peternell conjecture in complex dimension six. As a consequence, a connected compact Kähler manifold X with nef holomorphic tangent bundle and $\dim_{\mathbb C}X-\widetilde q(X)\leq6$ has ordinary universal cover $F\times\mathbb C^{\widetilde q(X)}$, where F is a rational homogeneous manifold and $\widetilde q(X)$ is the maximal irregularity of a connected finite étale cover.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Campana-Peternell-conjecture-in-dimension-six-September-25-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Campana-Peternell-conjecture-in-dimension-six-September-25-2026)
