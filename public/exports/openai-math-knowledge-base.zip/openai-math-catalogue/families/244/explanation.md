# 244 · The Partition Principle does not imply Choice

**Subject:** Mathematical logic

## The question, intuitively

Does a weak principle comparing partitions already imply the full axiom of choice?

## Papers in this family

- [The Partition Principle does not imply Choice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Partition-Principle-does-not-imply-Choice-September-24-2026/partition-principle-without-choice.pdf) — [note](../../papers/paper-f47c7d5f8539f9a7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
