# 011 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that the normalized ordered logarithms of the prime factors of $p-1$, counted with multiplicity, converge jointly to the Poisson–Dirichlet law $\mathrm{PD}(1)$ as p ranges uniformly over primes up to x and $x\to\infty$. This resolves the Ford–Konyagin–Luca conjecture. It also proves that infinitely many integers n have more than $n^{1-\varepsilon}$ totient preimages, for every ε > 0.

## Weighted dilation graphs, smooth shifted primes and totient fibers

We prove Erdős's conjecture on the largest fibers of Euler's totient function: for every ε > 0, infinitely many positive integers n have more than $n^{1-\varepsilon }$ preimages. We also show that, for every fixed δ > 0, there are at least $x^{1-o(1)}$ primes p in $2x< p\le5x$ whose predecessors have no prime factor exceeding x^{δ}.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weighted-Dilation-Graphs-Smooth-Shifted-Primes-and-Totient-Fibers-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weighted-Dilation-Graphs-Smooth-Shifted-Primes-and-Totient-Fibers-September-24-2026)

## The Poisson-Dirichlet law for prime predecessors

For a prime p chosen uniformly from $3\le p\le x$, list the prime factors of $p-1$ in decreasing order, with multiplicity. As $x\to\infty$, their logarithms, divided by $\log(p-1)$, converge in every finite joint distribution to the Poisson–Dirichlet distribution with parameter one. This proves the conjecture of Ford, Konyagin and Luca.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Poisson-Dirichlet-Law-for-Prime-Predecessors-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Poisson-Dirichlet-Law-for-Prime-Predecessors-September-24-2026)

## Prime Predecessors with an Even Number of Prime Factors

We prove that there are infinitely many primes p for which $p-1$ is squarefree and has an even number of prime factors. Equivalently, there are infinitely many primes p with $\mu(p-1)=1$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prime-Predecessors-with-an-Even-Number-of-Prime-Factors-September-17-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prime-Predecessors-with-an-Even-Number-of-Prime-Factors-September-17-2026)
