# 011 · Prime-factor statistics of $p-1$

**Subject:** Number theory

## The question, intuitively

Choose a large prime and subtract one: how are the sizes of the resulting prime factors distributed?

## Papers in this family

- [Weighted dilation graphs, smooth shifted primes and totient fibers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weighted-Dilation-Graphs-Smooth-Shifted-Primes-and-Totient-Fibers-September-24-2026/paper.pdf) — [note](../../papers/paper-4d25fbf130460dc0.md)
- [The Poisson-Dirichlet law for prime predecessors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Poisson-Dirichlet-Law-for-Prime-Predecessors-September-24-2026/paper.pdf) — [note](../../papers/paper-db1fcdc1a94ede93.md)
- [Prime Predecessors with an Even Number of Prime Factors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prime-Predecessors-with-an-Even-Number-of-Prime-Factors-September-17-2026/paper.pdf) — [note](../../papers/paper-c769fbe8f003c74e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
