# 150 · Weak mixing of triangular billiards with an irrational angle

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Do triangular billiards with an irrational angle necessarily exhibit weak mixing?

## Papers in this family

- [Weak mixing of triangular billiards with an irrational angle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-mixing-of-triangular-billiards-with-an-irrational-angle-October-5-2026/weak-mixing-triangular-billiards.pdf) — [note](../../papers/paper-9aadd9baa57acfe6.md)
- [Ergodicity of triangular billiards with an irrational angle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ergodicity-of-triangular-billiards-with-an-irrational-angle-September-25-2026/Ergodicity-of-triangular-billiards-with-an-irrational-angle-September-25-2026.pdf) — [note](../../papers/paper-e1d8affed60ec064.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
