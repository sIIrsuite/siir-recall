# 065 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the full ordinary unreduced descendant Virasoro conjecture for smooth complete intersections in complex projective space, in every genus and curve class with arbitrary cohomology insertions. The constraints also pass from any smooth projective complex base satisfying them to the projectivization of every algebraic vector bundle of rank at least two, and hence to projective-bundle towers.

## Virasoro Constraints under Projectivization

We prove that full ordinary descendant Virasoro constraints pass from a smooth projective complex base to the projectivization of any algebraic vector bundle of rank at least two. The bundle need not split and satisfies no positivity requirement. Assuming the full constraints on the base, the conclusion includes every genus, each individual integral curve class, and all cohomology insertions, including primitive and odd classes. The result also applies successively to towers of projective bundles.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-under-Projectivization-October-5-2026/virasoro-constraints-under-projectivization.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-under-Projectivization-October-5-2026)

## Virasoro Constraints for Projective Complete Intersections

We prove the Virasoro conjecture for the ordinary descendant Gromov–Witten theory of smooth complete intersections in projective space, in every genus and curve class and with arbitrary cohomology insertions. This includes primitive and odd cohomology classes, with no semisimplicity assumption.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-for-Projective-Complete-Intersections-September-24-2026/article.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-for-Projective-Complete-Intersections-September-24-2026)
