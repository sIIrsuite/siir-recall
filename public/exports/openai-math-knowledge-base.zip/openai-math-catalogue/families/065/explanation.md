# 065 · Virasoro constraints for complete intersections and projective-bundle towers

**Subject:** Algebraic and complex geometry

## The question, intuitively

Do curve-counting generating functions obey the infinite system of symmetry equations called Virasoro constraints?

## Papers in this family

- [Virasoro Constraints under Projectivization](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-under-Projectivization-October-5-2026/virasoro-constraints-under-projectivization.pdf) — [note](../../papers/paper-36f5c2bcb9ef4a4d.md)
- [Virasoro Constraints for Projective Complete Intersections](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-for-Projective-Complete-Intersections-September-24-2026/article.pdf) — [note](../../papers/paper-eb2b1271759b1c52.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
