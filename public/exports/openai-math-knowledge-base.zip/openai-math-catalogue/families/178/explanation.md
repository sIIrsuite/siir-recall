# 178 · Deterministic nonbipartite Ramanujan graphs in every fixed degree

**Subject:** Combinatorics

## The question, intuitively

Can optimal spectral expander graphs be explicitly constructed in every fixed degree without restricting to bipartite graphs?

## Papers in this family

- [Deterministic nonbipartite Ramanujan graphs in every fixed degree](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-nonbipartite-Ramanujan-graphs-in-every-fixed-degree-September-23-2026/paper.pdf) — [note](../../papers/paper-c2e0035f6d20bb0c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
