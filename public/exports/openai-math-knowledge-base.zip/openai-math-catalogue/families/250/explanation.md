# 250 · Boone–Higman embeddings with higher finiteness

**Subject:** Group theory

## The question, intuitively

Can every group with a solvable word problem embed into a finitely presented simple group with stronger finiteness properties?

## Papers in this family

- [Finite algebraic envelopes and the Boone–Higman conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-algebraic-envelopes-and-the-Boone-Higman-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-e09f76f13ae23ca4.md)
- [Simple F∞ overgroups of groups with decidable word problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simple-F-infinity-overgroups-of-groups-with-decidable-word-problem-September-23-2026/paper.pdf) — [note](../../papers/paper-68b55ce6c8e1e715.md)
- [A universal group of type F∞](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-universal-group-of-type-F-infinity-September-23-2026/paper.pdf) — [note](../../papers/paper-842b94f8578e9472.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
