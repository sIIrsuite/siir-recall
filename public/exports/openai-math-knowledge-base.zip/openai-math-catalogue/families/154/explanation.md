# 154 · Pointwise multiple ergodic averages for mixing transformations

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Do averages following several related time scales converge pointwise for mixing systems?

## Papers in this family

- [Pointwise Multiple Ergodic Averages for Mixing Transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-Multiple-Ergodic-Averages-for-Mixing-Transformations-October-4-2026/multiple-ergodic-averages.pdf) — [note](../../papers/paper-a1092fb3827f9565.md)
- [Pointwise convergence of fourfold ergodic averages for mixing transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-convergence-of-fourfold-ergodic-averages-for-mixing-transformations-October-4-2026/fourfold-ergodic-averages.pdf) — [note](../../papers/paper-ce51fc685631db38.md)
- [Triple ergodic averages with distinct integer slopes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Triple-ergodic-averages-with-distinct-integer-slopes-October-4-2026/triple-ergodic-distinct-slopes.pdf) — [note](../../papers/paper-1acea3e69861c084.md)
- [Pointwise convergence of triple ergodic averages for mixing transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-convergence-of-triple-ergodic-averages-for-mixing-transformations-October-4-2026/pointwise-triple-ergodic-averages-mixing-transformations.pdf) — [note](../../papers/paper-bb1dbf44dcfa27de.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
