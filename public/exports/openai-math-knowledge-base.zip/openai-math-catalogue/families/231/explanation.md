# 231 · The free uniform spanning forest is a factor of IID

**Subject:** Probability and statistical mechanics

## The question, intuitively

Can a random spanning forest be generated from independent random labels by a symmetry-respecting local rule?

## Papers in this family

- [The free uniform spanning forest is a factor of IID](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-uniform-spanning-forest-is-a-factor-of-IID-September-25-2026/The-free-uniform-spanning-forest-is-a-factor-of-IID-September-25-2026.pdf) — [note](../../papers/paper-d7fb1e01136d8684.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
