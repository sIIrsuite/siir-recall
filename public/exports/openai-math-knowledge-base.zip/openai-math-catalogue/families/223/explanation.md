# 223 · Random-cluster interfaces: critical, disordered, thermal, and natural-time scaling

**Subject:** Probability and statistical mechanics

## The question, intuitively

How do cluster boundaries converge to continuum random curves under criticality, disorder, and temperature perturbations?

## Papers in this family

- [Square-lattice FK interfaces and nested loops for 1 <= q < 4](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Square-lattice-FK-interfaces-and-nested-loops-for-1-leq-q-lt-4-September-23-2026/paper.pdf) — [note](../../papers/paper-686250730b568ad0.md)
- [Self-dual random-cluster interfaces below one](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Self-dual-random-cluster-interfaces-below-one-September-23-2026/paper.pdf) — [note](../../papers/paper-79dbe4d2f6e63e7f.md)
- [Quenched SLE Universality for Weakly Disordered FK–Ising Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE-Universality-for-Weakly-Disordered-FK-Ising-Interfaces-October-5-2026/quenched-fk-ising.pdf) — [note](../../papers/paper-9b38b1f771e99826.md)
- [Thermal FK–Ising interfaces and massive SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thermal-FK-Ising-interfaces-and-massive-SLE-October-5-2026/paper.pdf) — [note](../../papers/paper-37e973b9fd918be1.md)
- [Natural Occupation Measures for Critical Square-Lattice FK Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Natural-Occupation-Measures-for-Critical-Square-Lattice-FK-Interfaces-October-5-2026/natural-occupation-measures-critical-square-lattice-fk-interfaces.pdf) — [note](../../papers/paper-4a539d16cc366897.md)
- [Conformal Limits of Critical Square-Lattice Random-Cluster Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-Limits-of-Critical-Square-Lattice-Random-Cluster-Interfaces-October-5-2026/paper.pdf) — [note](../../papers/paper-e14c444fd0ddcbd8.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
