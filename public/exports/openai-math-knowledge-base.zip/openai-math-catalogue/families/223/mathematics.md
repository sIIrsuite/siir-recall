# 223 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves chordal SLE_{κ} limits for critical square-lattice random-cluster interfaces for $0< q\le4$, with $\kappa=4\pi/\arccos(-\sqrt q/2)$: bounded Jordan domains are allowed for q ≥ 1, and smooth Jordan domains for q < 1, under the stated marked-boundary approximations. For $1\le q\le4$, complete nested plane loops converge to CLE_{κ}.

## Square-lattice FK interfaces and nested loops for 1 <= q < 4

For every fixed $1\le q< 4$, critical square-lattice random-cluster Dobrushin interfaces converge as ordered curves to chordal $\mathop{\mathrm{SLE}}\nolimits _{\kappa(q)}$, where $\kappa(q)=4\pi/\arccos(-\sqrt q/2)$, confirming the Rohde–Schramm prediction in this parameter range. This holds in every bounded Jordan domain under uniform marked boundary approximation. The complete nested plane loop collections converge to whole-plane $\mathop{\mathrm{CLE}}\nolimits _{\kappa(q)}$ in a spherical matching topology retaining multiplicities and traversals. At q = 1 we obtain Cardy's formula for square-lattice bond percolation with free boundary edges.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Square-lattice-FK-interfaces-and-nested-loops-for-1-leq-q-lt-4-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Square-lattice-FK-interfaces-and-nested-loops-for-1-leq-q-lt-4-September-23-2026)

## Self-dual random-cluster interfaces below one

For every fixed $0< q< 1$, we prove that the Dobrushin interface of the square-lattice random-cluster model at its self-dual parameter converges to chordal SLE_{κ}, where $\kappa=4\pi/\arccos(-\sqrt q/2)\in(6,8)$. The approximating domains are simple closed nearest-neighbor lattice polygons with distinct marked vertices, whose marked boundary parametrizations converge uniformly to those of a bounded smooth Jordan domain. Convergence holds along the full mesh sequence in the uniform metric on oriented curves modulo increasing reparametrization. The proof combines finite connection comparisons below one, localization in irregular tiled disks, and a boundary observable that determines the limiting Loewner driver.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Self-dual-random-cluster-interfaces-below-one-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Self-dual-random-cluster-interfaces-below-one-September-23-2026)

## Quenched SLE Universality for Weakly Disordered FK–Ising Interfaces

We prove that critical FK–Ising interfaces with sufficiently weak, symmetric, independent two-valued bond disorder converge to chordal SLE_{16/3}. The disorder strength is fixed as the mesh tends to zero, and convergence of the conditional curve laws holds in probability over the environment.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE-Universality-for-Weakly-Disordered-FK-Ising-Interfaces-October-5-2026/quenched-fk-ising.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE-Universality-for-Weakly-Disordered-FK-Ising-Interfaces-October-5-2026)

## Thermal FK–Ising interfaces and massive SLE

We prove convergence of thermal FK–Ising interfaces, for every fixed nonzero mass of either sign, on uniformly angle-bounded isoradial lattices in bounded simply connected domains. The limit is independent of the lattice and the admissible domain approximation. For positive mass it is the unique massive SLE$_{16/3}$ law with locally finite-energy drift prescribed by a massive boundary value problem; negative mass follows by duality and reversal. The theorem also allows Carathéodory approximations whose diameters diverge.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thermal-FK-Ising-interfaces-and-massive-SLE-October-5-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thermal-FK-Ising-interfaces-and-massive-SLE-October-5-2026)

## Natural Occupation Measures for Critical Square-Lattice FK Interfaces

We prove that the rescaled counting measure of a critical square-lattice Fortuin–Kasteleyn Dobrushin interface in the unit square converges to the Minkowski-content measure of its Schramm–Loewner limit, for every fixed cluster weight $1\le q< 4$. A single deterministic constant times the predicted power of the mesh gives the normalization. Convergence is joint with the ordered curve and includes the total mass, giving the scaling limit of the interface's total number of steps.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Natural-Occupation-Measures-for-Critical-Square-Lattice-FK-Interfaces-October-5-2026/natural-occupation-measures-critical-square-lattice-fk-interfaces.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Natural-Occupation-Measures-for-Critical-Square-Lattice-FK-Interfaces-October-5-2026)

## Conformal Limits of Critical Square-Lattice Random-Cluster Interfaces

For every fixed $1\le q\le4$, critical square-lattice random-cluster Dobrushin interfaces converge to chordal $\mathop{\mathrm{SLE}}\nolimits _{\kappa(q)}$, where $\kappa(q)=4\pi/\arccos(-\sqrt q/2)$, and the complete nested plane loop collections converge to whole-plane $\mathop{\mathrm{CLE}}\nolimits _{\kappa(q)}$. The results hold under uniform marked Jordan boundary approximation and retain loop multiplicities and traversals. At q = 1 we obtain Cardy's formula for square-lattice bond percolation with free boundary edges.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-Limits-of-Critical-Square-Lattice-Random-Cluster-Interfaces-October-5-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-Limits-of-Critical-Square-Lattice-Random-Cluster-Interfaces-October-5-2026)
