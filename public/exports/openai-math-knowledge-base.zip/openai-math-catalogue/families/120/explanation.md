# 120 · Almost-linear-time exact matching and prescribed-degree factors in general graphs

**Subject:** Theoretical computer science

## The question, intuitively

Can exact matchings and more general prescribed-degree subgraphs be found in nearly linear time?

## Papers in this family

- [Almost-Linear-Time Maximum-Cardinality Matching in General Graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Almost-Linear-Time-Maximum-Cardinality-Matching-in-Sparse-General-Graphs-September-24-2026/main.pdf) — [note](../../papers/paper-669239fdc7f9d479.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
