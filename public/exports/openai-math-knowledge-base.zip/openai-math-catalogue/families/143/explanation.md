# 143 · Hilbert's sixteenth problem: uniform bounds for limit cycles

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Can polynomial planar vector fields of a fixed degree have arbitrarily many isolated periodic trajectories?

## Papers in this family

- [Uniform bounds for planar polynomial limit cycles](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/uniform-bounds-for-planar-polynomial-limit-cycles-September-24-2026/uniform-bounds-for-planar-polynomial-limit-cycles-September-24-2026.pdf) — [note](../../papers/paper-ce34d06d03483055.md)
- [Two limit cycles for quintic Liénard systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/two-limit-cycles-for-quintic-lienard-systems-September-24-2026/two-limit-cycles-for-quintic-lienard-systems-September-24-2026.pdf) — [note](../../papers/paper-f2d96ea542ffa399.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
