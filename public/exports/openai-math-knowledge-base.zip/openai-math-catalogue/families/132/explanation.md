# 132 · A superquadratic separation of sensitivity and block sensitivity

**Subject:** Theoretical computer science

## The question, intuitively

How far apart can the number of sensitive single bits and sensitive blocks of bits be?

## Papers in this family

- [A superquadratic separation between sensitivity and block sensitivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-superquadratic-separation-between-sensitivity-and-block-sensitivity-September-25-2026/paper.pdf) — [note](../../papers/paper-a61daa8a7cad31d4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
