# 128 · A factor-two approximation for shortest common superstring

**Subject:** Theoretical computer science

## The question, intuitively

Can we efficiently find a string containing every input string whose length is at most twice optimal?

## Papers in this family

- [A Polynomial-Time 2-Approximation for Shortest Common Superstring](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Polynomial-Time-2-Approximation-for-Shortest-Common-Superstring-September-24-2026/paper.pdf) — [note](../../papers/paper-2d2585ddd6f73380.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
