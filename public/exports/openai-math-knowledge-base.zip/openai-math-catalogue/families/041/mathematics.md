# 041 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the strong hyperkähler SYZ conjecture: every holomorphic line bundle with nonzero nef isotropic first Chern class on a compact irreducible holomorphic symplectic Kähler manifold is semiample. It also proves that every projective Lagrangian fibration with normal projective base has projective space as its base, in every dimension and deformation type.

## Projective-space bases of Lagrangian fibrations

We prove that the normal projective base of a projective Lagrangian fibration from a compact irreducible holomorphic symplectic Kähler manifold is projective space. This resolves the projective-space base conjecture for such fibrations in every dimension and deformation type.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projective-Space-Bases-of-Lagrangian-Fibrations-September-23-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projective-Space-Bases-of-Lagrangian-Fibrations-September-23-2026)

## The strong hyperkähler SYZ conjecture

We prove the strong hyperkähler SYZ conjecture: every holomorphic line bundle with nonzero nef isotropic first Chern class on a compact irreducible holomorphic symplectic Kähler manifold is semiample.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Strong-Hyperkahler-SYZ-Conjecture-September-23-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Strong-Hyperkahler-SYZ-Conjecture-September-23-2026)
