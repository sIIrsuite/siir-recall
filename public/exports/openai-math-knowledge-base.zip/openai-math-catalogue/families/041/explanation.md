# 041 · Hyperkähler SYZ and projective-space bases

**Subject:** Algebraic and complex geometry

## The question, intuitively

Must certain special higher-dimensional geometric spaces fiber into tori, and what can their bases look like?

## Papers in this family

- [Projective-space bases of Lagrangian fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projective-Space-Bases-of-Lagrangian-Fibrations-September-23-2026/main.pdf) — [note](../../papers/paper-932a41dd33fe316e.md)
- [The strong hyperkähler SYZ conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Strong-Hyperkahler-SYZ-Conjecture-September-23-2026/main.pdf) — [note](../../papers/paper-69159e76a9b2cf00.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
