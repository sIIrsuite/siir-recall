# 234 · All-temperature pressure of orthogonally invariant Ising spin glasses

**Subject:** Probability and statistical mechanics

## The question, intuitively

Can the limiting free energy of an orthogonally invariant spin glass be determined at every temperature?

## Papers in this family

- [All-temperature pressure for orthogonally invariant Ising spin glasses](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/All-temperature-pressure-for-orthogonally-invariant-Ising-spin-glasses-September-25-2026/paper.pdf) — [note](../../papers/paper-77ee128d02a349f1.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
