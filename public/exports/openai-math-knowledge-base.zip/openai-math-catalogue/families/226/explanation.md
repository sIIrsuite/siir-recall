# 226 · The double-dimer loop ensemble converges to CLE_{4}

**Subject:** Probability and statistical mechanics

## The question, intuitively

Do loops formed by superposing two random dimer coverings converge to the conformal loop ensemble CLE4?

## Papers in this family

- [The curve scaling limit of half-plane double dimers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-curve-scaling-limit-of-half-plane-double-dimers-September-23-2026/paper.pdf) — [note](../../papers/paper-1c505cc4d7be22bd.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
