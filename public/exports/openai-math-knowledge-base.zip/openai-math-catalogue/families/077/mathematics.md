# 077 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the diagonal Fourier extension conjecture for positively curved surfaces in three dimensions. For every compact smooth positively curved surface $\Sigma\subset\mathbb R^3$, including surfaces with boundary, the extension operator is bounded from $L^p(\Sigma)$ to $L^p(\mathbb R^3)$ for every p > 3.

## Elliptic capacity propagation and Fourier restriction to the sphere

We prove the bounded-data Fourier restriction conjecture for the sphere in three dimensions: the Fourier extension operator maps $L^\infty(S^2)$ boundedly into $L^p(\mathbb R^3)$ for every p > 3. This is the full conjectured open range, and the threshold p = 3 is sharp.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026)

## Diagonal Fourier extension for positively curved surfaces in three dimensions

We prove the diagonal Fourier extension conjecture for compact smooth positively curved surfaces $\Sigma\subset\mathbb R^3$, including surfaces with smooth boundary. For every $3< p< \infty$, the extension operator maps $L^p(\Sigma)$ boundedly into $L^p(\mathbb R^3)$. The compact paraboloid case also yields free Schrödinger local smoothing in two spatial dimensions for every $3< p< \infty$ and Sobolev order $s> 2-6/p$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026)
