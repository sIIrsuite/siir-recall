# 077 · Fourier restriction for positively curved surfaces

**Subject:** Real and complex analysis

## The question, intuitively

How much Fourier information can be restricted to a curved hypersurface without losing norm control?

## Papers in this family

- [Elliptic capacity propagation and Fourier restriction to the sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026.pdf) — [note](../../papers/paper-e2a3a74983521b50.md)
- [Diagonal Fourier extension for positively curved surfaces in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026.pdf) — [note](../../papers/paper-e8cc764c1b5cd604.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
