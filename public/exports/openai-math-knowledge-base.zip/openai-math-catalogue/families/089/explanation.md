# 089 · Bounded-distortion L_{1} embeddings of planar and bounded-treewidth graphs

**Subject:** Convex and metric geometry

## The question, intuitively

Can graph distances be represented as distances between vectors measured by total coordinatewise displacement with uniformly bounded distortion?

## Papers in this family

- [Planar Graph Metrics Embed into L1 with Constant Distortion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Planar-Graph-Metrics-Embed-into-L1-with-Constant-Distortion-September-23-2026/paper.pdf) — [note](../../papers/paper-1ca672e303a58aff.md)
- [L1 Embeddings of Graphs of Bounded Treewidth](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/L1-Embeddings-of-Graphs-of-Bounded-Treewidth-September-23-2026/paper.pdf) — [note](../../papers/paper-a732d1138d040d4c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
