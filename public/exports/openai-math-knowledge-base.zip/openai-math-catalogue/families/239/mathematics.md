# 239 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Determines the sharp exponential singularity rate of symmetric random sign matrices with independent entries on and above the diagonal. Uniform signs give $\Pr(\det A_n=0)=(1/2+o(1))^n$; for fixed bias $p\in(0,1)\setminus\{1/2\}$, the rate is $(p^2+(1-p)^2+o(1))^n$. In the biased case, agreeing rows attain this rate.

## The sharp exponential rate of singularity for symmetric Bernoulli matrices

Let A_{n} be a symmetric $n\times n$ matrix whose entries on and above the diagonal are independent uniform signs. We prove

$\displaystyle \Pr(\det A_n=0)=\left(\frac12+o(1)\right)^n.$

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-exponential-rate-of-singularity-for-symmetric-Bernoulli-matrices-October-3-2026/symmetric-bernoulli-singularity.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-exponential-rate-of-singularity-for-symmetric-Bernoulli-matrices-October-3-2026)

## The sharp singularity rate for biased symmetric sign matrices

Let A_{n} be a symmetric random matrix whose entries on and above the diagonal are independent signs, equal to 1 with fixed probability $p\in(0,1)\setminus\{1/2\}$. We prove that $\mathbb P(\det A_n=0)=(p^2+(1-p)^2+o(1))^n$. The rate is attained by the event that two rows agree.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-singularity-rate-for-biased-symmetric-sign-matrices-October-4-2026/biased-symmetric-sign-singularity.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-singularity-rate-for-biased-symmetric-sign-matrices-October-4-2026)
