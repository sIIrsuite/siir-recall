# 239 · Sharp singularity rates for symmetric random sign matrices

**Subject:** Probability and statistical mechanics

## The question, intuitively

How quickly does the probability that a symmetric random plus/minus-one matrix is singular decay with matrix size?

## Papers in this family

- [The sharp exponential rate of singularity for symmetric Bernoulli matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-exponential-rate-of-singularity-for-symmetric-Bernoulli-matrices-October-3-2026/symmetric-bernoulli-singularity.pdf) — [note](../../papers/paper-a12e95803a6ff0ff.md)
- [The sharp singularity rate for biased symmetric sign matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-singularity-rate-for-biased-symmetric-sign-matrices-October-4-2026/biased-symmetric-sign-singularity.pdf) — [note](../../papers/paper-88bbfa0056a7bec9.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
