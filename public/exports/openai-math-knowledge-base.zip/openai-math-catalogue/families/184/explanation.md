# 184 · Correspondence coloring with a fixed forbidden subgraph

**Subject:** Combinatorics

## The question, intuitively

How does forbidding one subgraph improve graph colorability when colors at neighboring vertices are linked by arbitrary correspondences?

## Papers in this family

- [Correspondence coloring graphs with a forbidden clique](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Correspondence-Coloring-Graphs-with-a-Forbidden-Clique-October-5-2026/correspondence-coloring-forbidden-clique.pdf) — [note](../../papers/paper-39a104c4bd137a9a.md)
- [A logarithmic independence bound for clique-free graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Logarithmic-Independence-Bound-for-Clique-Free-Graphs-September-25-2026/paper.pdf) — [note](../../papers/paper-54f59aabd3bdaeb3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
