# 010 · Unrestricted pro-modularity at the prime two

**Subject:** Number theory

## The question, intuitively

Do all suitably odd two-dimensional arithmetic representations at the prime two arise from modular-form machinery?

## Papers in this family

- [Unrestricted pro-modularity at the prime two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unrestricted-pro-modularity-at-the-prime-two-October-6-2026/two-adic-promodularity.pdf) — [note](../../papers/paper-83ba9e49036ec83b.md)
- [The Dimension of the Two-Adic Hecke Algebra at Odd Level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Dimension-of-the-Two-Adic-Hecke-Algebra-at-Odd-Level-October-5-2026/two-adic-hecke.pdf) — [note](../../papers/paper-7a1e02a1fbc099c6.md)
- [Fontaine–Mazur modularity at the prime 2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fontaine-Mazur-modularity-at-the-prime-2-October-6-2026/paper.pdf) — [note](../../papers/paper-f63d29ba34ebbfd1.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
