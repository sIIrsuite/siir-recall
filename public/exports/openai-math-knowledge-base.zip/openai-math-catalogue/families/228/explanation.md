# 228 · Continuum phase transitions for radial pair potentials

**Subject:** Probability and statistical mechanics

## The question, intuitively

Which radial particle interactions produce genuine continuum phase transitions?

## Papers in this family

- [A continuum temperature singularity for a radial pair potential](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-continuum-temperature-singularity-for-a-radial-pair-potential-September-24-2026/paper.pdf) — [note](../../papers/paper-51c7ee2f0a2eb0e6.md)
- [A radial continuum phase transition with algebraic decay](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-radial-continuum-phase-transition-with-algebraic-decay-September-24-2026/paper.pdf) — [note](../../papers/paper-602393349a821743.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
