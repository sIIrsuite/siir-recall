# 225 · Gaussian free field limits throughout the balanced six-vertex regime

**Subject:** Probability and statistical mechanics

## The question, intuitively

When does the large-scale height field of a six-vertex lattice model become a Gaussian free field?

## Papers in this family

- [The Gaussian free field limit of the balanced six-vertex model with variance multiplier 1/arcsin(c/2)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026.pdf) — [note](../../papers/paper-d4093b0a57d654c1.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
