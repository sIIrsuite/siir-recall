# 225 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

The balanced square-lattice six-vertex height field with $a=b=1$ and $0< c\le2$ converges to a Gaussian free field, including at the endpoint c = 2. The plane state is defined by balanced-torus limits. For unit height increments and Green kernel $-(2\pi)^{-1}\log|x-y|$, the exact variance multiplier is $1/\arcsin(c/2)$.

## The Gaussian free field limit of the balanced six-vertex model with variance multiplier 1/arcsin(c/2)

We prove that the height function of the square-lattice six-vertex model with weights $a=b=1$ and $0< c\le2$, in the plane state obtained from balanced tori, converges to a multiple of the Gaussian free field. For unit height jumps and Green kernel $-(2\pi)^{-1}\log|x-y|$, the squared multiplier is $1/\arcsin(c/2)$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026)
