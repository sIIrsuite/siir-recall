# 137 · One-tape time simulation in two-fifths-power space

**Subject:** Theoretical computer science

## The question, intuitively

How much working memory is needed to simulate a time-bounded one-tape computation?

## Papers in this family

- [Simulating One-Tape Time in Two-Fifths-Power Space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simulating-One-Tape-Time-in-Two-Fifths-Power-Space-September-25-2026/article.pdf) — [note](../../papers/paper-b293c9fc34d7ffce.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
