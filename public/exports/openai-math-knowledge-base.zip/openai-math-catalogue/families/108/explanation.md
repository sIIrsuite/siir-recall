# 108 · A cubic permanent–determinant lower bound

**Subject:** Theoretical computer science

## The question, intuitively

How much larger must a determinant representation be to reproduce the permanent polynomial?

## Papers in this family

- [A cubic lower bound for border determinantal complexity of the permanent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026.pdf) — [note](../../papers/paper-b4bb67ab3de819c9.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
