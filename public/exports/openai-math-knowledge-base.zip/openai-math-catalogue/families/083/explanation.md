# 083 · Hilbert transforms along Lipschitz directions

**Subject:** Real and complex analysis

## The question, intuitively

Is singular integration along a direction field still bounded when the direction changes only in a Lipschitz manner?

## Papers in this family

- [A uniform Hilbert transform estimate for Lipschitz directions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-uniform-Hilbert-transform-estimate-for-Lipschitz-directions-September-25-2026/main.pdf) — [note](../../papers/paper-355dcc1d5f0d69a2.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
