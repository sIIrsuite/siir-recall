# 130 · Exact Fourier transforms below $n\log n$

**Subject:** Theoretical computer science

## The question, intuitively

Can the exact discrete Fourier transform be computed using fewer than order n-log-n operations in the specified arithmetic model?

## Papers in this family

- [An explicit power saving for the exact discrete Fourier transform](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/main.pdf) — [note](../../papers/paper-e0dd6b6852eaffa8.md)
- [Finite tensor savings and exact Fourier circuits](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-tensor-savings-and-exact-Fourier-circuits-September-25-2026/main.pdf) — [note](../../papers/paper-141aacc64c4adada.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
