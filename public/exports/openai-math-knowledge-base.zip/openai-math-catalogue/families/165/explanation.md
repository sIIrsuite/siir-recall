# 165 · The Harary–Hill and Zarankiewicz crossing-number formulas

**Subject:** Combinatorics

## The question, intuitively

What is the minimum number of edge crossings needed to draw complete or complete bipartite graphs?

## Papers in this family

- [The crossing number of complete graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-crossing-number-of-complete-graphs-September-23-2026/paper.pdf) — [note](../../papers/paper-077a49128e698aa5.md)
- [The crossing number of complete bipartite graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-crossing-number-of-complete-bipartite-graphs-September-23-2026/paper.pdf) — [note](../../papers/paper-b3a0451f0907bb67.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
