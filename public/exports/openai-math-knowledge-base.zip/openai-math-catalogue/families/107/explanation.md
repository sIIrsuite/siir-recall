# 107 · Matrix multiplication with exponent at most 9/4

**Subject:** Theoretical computer science

## The question, intuitively

Can two large matrices be multiplied using substantially fewer arithmetic operations than the familiar cubic algorithm?

## Papers in this family

- [An Upper Bound of 9/4 for the Matrix Multiplication Exponent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf) — [note](../../papers/paper-90872dcda176342a.md)
- [Complex Matrix Multiplication Below 2.258 and Rectangular Bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Complex-Matrix-Multiplication-Below-2.258-and-Rectangular-Bounds-September-24-2026/Complex-Matrix-Multiplication-Below-2.258-and-Rectangular-Bounds-September-24-2026.pdf) — [note](../../papers/paper-ffeccf46b092aede.md)
- [Staggered extraction for exact matrix multiplication over every field](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026.pdf) — [note](../../papers/paper-e6b0ff629223aea4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
