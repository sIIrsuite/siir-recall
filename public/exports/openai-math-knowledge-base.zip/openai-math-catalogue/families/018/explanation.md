# 018 · The Margulis–Platonov conjecture over global fields

**Subject:** Number theory

## The question, intuitively

Are normal subgroups of certain arithmetic matrix groups exactly the ones predicted by their local algebraic structure?

## Papers in this family

- [The Margulis–Platonov conjecture over global function fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Margulis-Platonov-conjecture-over-global-function-fields-October-5-2026/margulis-platonov-global-function-fields.pdf) — [note](../../papers/paper-51f6a9c2d26f3489.md)
- [The Margulis–Platonov conjecture over number fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Margulis-Platonov-conjecture-over-number-fields-September-23-2026/paper.pdf) — [note](../../papers/paper-251b5946efe85365.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
