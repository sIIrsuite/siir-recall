# 146 · Positive metric entropy for the standard map

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Can the familiar area-preserving standard map be proved to have a positive amount of chaotic behavior?

## Papers in this family

- [Positive Metric Entropy for the Standard Map at Large Parameters](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-Metric-Entropy-for-the-Standard-Map-at-Large-Parameters-September-23-2026/paper.pdf) — [note](../../papers/paper-23dfbfdae1c08863.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
