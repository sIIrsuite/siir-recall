# 213 · Critical percolation on every quasi-transitive graph

**Subject:** Probability and statistical mechanics

## The question, intuitively

What happens exactly at the percolation threshold on every graph with finitely many vertex types?

## Papers in this family

- [Critical bond and site percolation on the cubic lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-bond-and-site-percolation-on-the-cubic-lattice-September-24-2026/paper.pdf) — [note](../../papers/paper-e39276f15ac5f938.md)
- [No percolation at criticality on quasi-transitive graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/No-percolation-at-criticality-on-quasi-transitive-graphs-September-24-2026/paper.pdf) — [note](../../papers/paper-f82b2664889e4ea4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
