# 246 · Cannon's conjecture

**Subject:** Group theory

## The question, intuitively

Must a hyperbolic group whose boundary is a two-sphere act geometrically on hyperbolic three-space?

## Papers in this family

- [A Modulus Proof of Cannon’s Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Modulus-Proof-of-Cannons-Conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-4d998a62655613b4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
