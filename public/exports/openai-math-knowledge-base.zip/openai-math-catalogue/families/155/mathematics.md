# 155 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Constructs a finite translational tile in ℤ^{3} that tiles space but admits no fully periodic tiling, disproving the periodic tiling conjecture in the smallest possible lattice dimension. Its unit-cube thickening gives the same counterexample in ℝ^{3}, even with arbitrary real translation vectors. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/155.md))

## A translational tile with no fully periodic tiling in dimension three

We construct a finite translational tile in ℤ^{3} that admits tilings but no fully periodic tiling. Its unit-cube thickening has the same property in ℝ^{3}, even when arbitrary real translations are allowed. This gives a negative resolution of the periodic tiling conjecture in dimension three.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-translational-tile-with-no-fully-periodic-tiling-in-dimension-three-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-translational-tile-with-no-fully-periodic-tiling-in-dimension-three-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/155.md). A family link does not certify every claim or every companion paper.
