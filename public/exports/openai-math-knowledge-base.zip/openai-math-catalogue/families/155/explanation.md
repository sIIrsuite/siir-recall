# 155 · A counterexample to periodic tiling in dimension three

**Subject:** Combinatorics

## The question, intuitively

Can a single tile cover three-dimensional space while forbidding every periodic tiling?

## Papers in this family

- [A translational tile with no fully periodic tiling in dimension three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-translational-tile-with-no-fully-periodic-tiling-in-dimension-three-September-23-2026/paper.pdf) — [note](../../papers/paper-34c30a7d57dacb63.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
