# 129 · Exponential state costs for two-way automata

**Subject:** Theoretical computer science

## The question, intuitively

How many extra states are required when changing the directionality or determinism of finite automata?

## Papers in this family

- [An exponential state lower bound for two-way nondeterministic complementation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exponential-state-lower-bound-for-two-way-nondeterministic-complementation-September-25-2026/paper.pdf) — [note](../../papers/paper-82afb926eadc0625.md)
- [An exponential two-way deterministic state lower bound for one-way liveness](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exponential-two-way-deterministic-state-lower-bound-for-one-way-liveness-September-25-2026/main.pdf) — [note](../../papers/paper-de8d403ec8d082ea.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
