# 202 · The blockwise Alperin weight conjecture

**Subject:** Algebra

## The question, intuitively

Can irreducible representations in modular blocks be counted through the appropriate local weight data?

## Papers in this family

- [The Blockwise Alperin Weight Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Blockwise-Alperin-Weight-Conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-838b0669ed0f6a89.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
