# 202 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the numerical blockwise Alperin weight conjecture for every prime and every finite group: the number of irreducible Brauer characters in a block equals the number of conjugacy classes of its weights.

## The Blockwise Alperin Weight Conjecture

We prove the numerical blockwise Alperin weight conjecture for every finite group and every prime p. For each p-block B, the number of irreducible Brauer characters in B equals the number of conjugacy classes of B-weights.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Blockwise-Alperin-Weight-Conjecture-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Blockwise-Alperin-Weight-Conjecture-September-23-2026)
