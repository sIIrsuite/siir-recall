# 126 · Exponential semidefinite complexity of perfect matching

**Subject:** Theoretical computer science

## The question, intuitively

Must exact semidefinite descriptions of the perfect-matching polytope have exponential size?

## Papers in this family

- [Exponential PSD rank of positively shifted matching matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-PSD-rank-of-positively-shifted-matching-matrices-October-5-2026/shifted-matching-psd.pdf) — [note](../../papers/paper-62ba08d788e1d793.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
