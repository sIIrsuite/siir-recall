# 031 · Uchida’s conjecture for open homomorphisms of Galois groups

**Subject:** Number theory

## The question, intuitively

Does a sufficiently rich map between absolute Galois groups necessarily come from a map between the underlying fields?

## Papers in this family

- [Open Homomorphisms of Global Solvably Closed Galois Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Open-Homomorphisms-of-Global-Solvably-Closed-Galois-Groups-October-5-2026/open-homomorphisms-solvably-closed-galois-groups.pdf) — [note](../../papers/paper-384881aa9dbf1324.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
