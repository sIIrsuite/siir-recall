# 176 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the second Kahn–Kalai conjecture: for every finite simple graph H with h ≥ 1 edges and at most n vertices, its appearance threshold in $G(n,p)$ is at most $C p_{\mathrm E}(n,H)(1+\log_2 h)$, with universal C. Here $p_{\mathrm E}$ is the least density at which every subgraph of H has expected copy count at least 1/2. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/176.md))

## The second Kahn–Kalai conjecture

We prove the second Kahn–Kalai conjecture. For every finite simple graph H with h ≥ 1 edges and at most n vertices, the threshold for $G(n,p)$ to contain an ordinary copy of H is at most $C p_{\mathrm E}(n,H)(1+\log_2 h)$, where C is universal. Here $p_{\mathrm E}(n,H)$ is the least density at which every subgraph of H has expected copy count at least one half.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-second-Kahn-Kalai-conjecture-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-second-Kahn-Kalai-conjecture-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/176.md). A family link does not certify every claim or every companion paper.
