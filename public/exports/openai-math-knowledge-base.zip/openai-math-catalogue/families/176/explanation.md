# 176 · The second Kahn–Kalai conjecture with an edge-count bound

**Subject:** Combinatorics

## The question, intuitively

How close is a monotone graph property's expectation threshold to its actual random-graph threshold?

## Papers in this family

- [The second Kahn–Kalai conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-second-Kahn-Kalai-conjecture-September-24-2026/paper.pdf) — [note](../../papers/paper-1baa84ed127f140c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
