# 216 · Critical and near-critical XY scaling and BKT universality

**Subject:** Probability and statistical mechanics

## The question, intuitively

Do XY-type spin systems share the same critical and near-critical scaling laws across the BKT transition?

## Papers in this family

- [The critical logarithmic correction for the planar XY model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-logarithmic-correction-for-the-planar-XY-model-October-5-2026/paper.pdf) — [note](../../papers/paper-318a07a53719b3a5.md)
- [Critical Center Magnetization in the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-Center-Magnetization-in-the-Planar-XY-Model-October-5-2026/paper.pdf) — [note](../../papers/paper-6b00b1a0e376ebcf.md)
- [The Critical Spin Field of the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Critical-Spin-Field-of-the-Planar-XY-Model-October-5-2026/paper.pdf) — [note](../../papers/paper-483a06ae4d3057dc.md)
- [Essential Singularity of the Correlation Length in the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Essential-Singularity-of-the-Correlation-Length-in-the-Planar-XY-Model-October-5-2026/paper.pdf) — [note](../../papers/paper-962f604458daf1ec.md)
- [The critical correlation exponent of the planar XY model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-correlation-exponent-of-the-planar-XY-model-September-24-2026/paper.pdf) — [note](../../papers/paper-a34c8660383ba2f6.md)
- [BKT universality for height and planar spin fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/BKT-universality-for-height-and-planar-spin-fields-September-24-2026/paper.pdf) — [note](../../papers/paper-2bb16506fb56b312.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
