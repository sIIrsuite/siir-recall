# 180 · Barnette’s Hamiltonian-cycle conjecture

**Subject:** Combinatorics

## The question, intuitively

Does every three-connected cubic bipartite planar graph have a cycle through every vertex?

## Papers in this family

- [Paired states and Hamiltonian cycles in cubic bipartite planar graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Paired-states-and-Hamiltonian-cycles-in-cubic-bipartite-planar-graphs-September-24-2026/paper.pdf) — [note](../../papers/paper-ea3e29b3b62f3884.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
