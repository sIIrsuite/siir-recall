# 241 · Rigidity of the Turing degrees

**Subject:** Mathematical logic

## The question, intuitively

Can the partial order of Turing degrees have any nontrivial symmetry?

## Papers in this family

- [Rigidity of the Turing degrees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rigidity-of-the-Turing-degrees-September-24-2026/paper.pdf) — [note](../../papers/paper-8500f0916b3b9d79.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
