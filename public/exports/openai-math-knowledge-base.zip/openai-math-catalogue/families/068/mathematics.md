# 068 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

If X is a smooth connected complex projective variety and $-K_X$ admits a smooth Hermitian metric with nonnegative curvature, then $H^0(X,-mK_X)\ne0$ for some m > 0. Thus smooth semipositivity forces a nonzero section of a positive tensor power of the anticanonical bundle in every dimension.

## Anticanonical nonvanishing from smooth semipositivity

Every smooth connected projective complex variety with smoothly semipositive anticanonical bundle has a nonzero section of some positive anticanonical power.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Anticanonical-nonvanishing-from-smooth-semipositivity-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Anticanonical-nonvanishing-from-smooth-semipositivity-September-26-2026)

## Invariant anticanonical indices and conversion of twisted differentials

For a holomorphic action of a compact torus on a compact complex manifold, we prove that the invariant Euler characteristic of naturally linearized anticanonical powers is polynomial on a divisible progression, with its actual value at exponent zero. Independently, on a smooth projective variety with smoothly semipositive anticanonical bundle, we remove a fixed pseudoeffective error from an unbounded sequence of effective twists. These results convert invariant cohomology into twisted differential forms and prove anticanonical nonvanishing on smooth projective varieties with smoothly semipositive anticanonical bundle, by descending the forms before conversion.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Invariant-anticanonical-indices-and-conversion-of-twisted-differentials-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Invariant-anticanonical-indices-and-conversion-of-twisted-differentials-September-26-2026)

## Bounded anticanonical metrics on klt pairs and torus quotients

Let $(W,D)$ be a projective ℚ-factorial klt pair with effective rational boundary. We prove that a positive Cartier multiple of $-(K_W+D)$ has a nonzero section if this divisor is nef, its pullback to a resolution admits a semipositive metric with locally bounded weights, and the resolution has nonzero structure-sheaf Euler characteristic. Consequently a smooth rationally connected projective variety with smoothly semipositive anticanonical bundle has a nonzero naturally invariant anticanonical plurisection for every algebraic torus action.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-anticanonical-metrics-on-klt-pairs-and-torus-quotients-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-anticanonical-metrics-on-klt-pairs-and-torus-quotients-September-26-2026)

## Cohomological transfer and equivariant anticanonical sections

Let X be a smooth projective complex variety with smoothly semipositive anticanonical bundle. For any torus linearization of that bundle, we show that invariant sections in unbounded degrees with one fixed negative pseudoeffective error yield an invariant section in a positive untwisted degree. Combining the natural invariant index with compact-monodromy structure, we deduce that every such X has a nonzero section of some positive anticanonical power.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cohomological-transfer-and-equivariant-anticanonical-sections-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cohomological-transfer-and-equivariant-anticanonical-sections-September-26-2026)

## Metric descent and rank-preserving contractions

From a smooth semipositive anticanonical metric on a smooth projective complex variety, we construct an unweighted integrable semipositive metric on a corrected anticanonical line of a smooth base, using a normal equidimensional toroidal model and full generic adjoint rank one at exponent zero. The explicit rational boundary correction pulls back to an exceptional divisor. On varieties without positive-degree holomorphic forms, two-metric transfer gives sections with prescribed boundary poles from a finite-volume log-anticanonical metric and a target line with bounded semipositive weights. In particular, a smooth projective complex variety with a smoothly semipositive anticanonical bundle and no such forms has a nonzero invariant section of a positive anticanonical multiple for every torus action with its natural linearization. On this class of varieties, generic section and adjoint-rank hypotheses give contractions of invariant fibrations that preserve both conditions unless an invariant global section already exists.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-descent-and-rank-preserving-contractions-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-descent-and-rank-preserving-contractions-September-26-2026)

## Integrable metrics and effectivity with controlled boundary

Let Y be smooth projective and let C be an effective integral divisor. If $-K_Y+C$ admits a metric with a global strict curvature lower bound for which the canonical section of C is locally square integrable, every pseudoeffective rational divisor becomes rationally effective after an effective correction supported on C. For a smooth projective X with smoothly semipositive $L=-K_X$, sections of $m_jL-P$ at unbounded positive exponents, with any fixed pseudoeffective Cartier error P, yield a section of a positive multiple of L.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integrable-metrics-and-effectivity-with-controlled-boundary-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integrable-metrics-and-effectivity-with-controlled-boundary-September-26-2026)

## Exact orders and invariant anticanonical linear systems

On a smooth connected projective complex variety with smoothly semipositive anticanonical bundle, we prove that asymptotically zero valuation on the curvature-null face is attained by an effective rational anticanonical divisor. The fixed auxiliary line bundle is arbitrary.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-orders-and-invariant-anticanonical-linear-systems-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-orders-and-invariant-anticanonical-linear-systems-September-26-2026)
