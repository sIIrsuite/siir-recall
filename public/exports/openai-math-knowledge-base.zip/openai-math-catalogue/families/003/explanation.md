# 003 · The quasi-Riemann hypothesis

**Subject:** Number theory

## The question, intuitively

Can we guarantee that zeta and related functions have no zeros in a fixed strip near the right edge of their critical region?

## Papers in this family

- [The Quasi-Riemann Hypothesis: A Zero-Free Half-Plane $\Re s> 7/8$](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf) — [note](../../papers/paper-8210fff0730119ab.md)
- [The Quasi-Riemann Hypothesis (alternate 11/12 proof)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-October-5-2026/paper2.pdf) — [note](../../papers/paper-c75e76b6eca657a3.md)
- [Uniform exclusion of Landau–Siegel zeros](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-exclusion-of-Landau-Siegel-zeros-October-1-2026/paper.pdf) — [note](../../papers/paper-7bad5a85ecaf0460.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
