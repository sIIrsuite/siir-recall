# 003 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that every Dirichlet L-function, including $\zeta(s)$, is zero-free in $\Re s> 7/8$, resolving the quasi-Riemann hypothesis. The same half-plane is zero-free for every finite-order Hecke L-function over $\mathbb Q(\sqrt{-3})$. A companion gives a different proof of the zero-free half-plane $\Re s> 11/12$. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/003.md))

## The Quasi-Riemann Hypothesis: A Zero-Free Half-Plane $\Re s> 7/8$

We prove that all finite-order Hecke L-functions over $\mathbb Q(\sqrt{-3})$ and all Dirichlet L-functions are zero-free in the half-plane $\Re s> 7/8$, with the principal pole at s = 1 allowed. In particular, the Riemann zeta function is zero-free in this half-plane, proving the quasi-Riemann hypothesis.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026)

## The Quasi-Riemann Hypothesis (alternate 11/12 proof)

We establish the quasi-Riemann hypothesis by proving that every Dirichlet L-function, including Riemann's zeta function, has no zeros in the half-plane $\mathop{\mathrm{Re}}\nolimits s> 11/12$. More generally, we prove the same zero-free half-plane for every finite-order Hecke L-function over $K=\mathbb Q(\sqrt{-3})$. In particular, this rules out the existence of Landau–Siegel zeros.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-October-5-2026/paper2.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-October-5-2026)

## Uniform exclusion of Landau–Siegel zeros

We prove the uniform exclusion of Landau–Siegel zeros. There is an absolute constant c > 0 such that every real zero $\beta\in(0,1)$ of every primitive nonprincipal real Dirichlet L-function of conductor q ≥ 3 satisfies $(1-\beta)\log q\ge c$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-exclusion-of-Landau-Siegel-zeros-October-1-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-exclusion-of-Landau-Siegel-zeros-October-1-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/003.md). A family link does not certify every claim or every companion paper.
