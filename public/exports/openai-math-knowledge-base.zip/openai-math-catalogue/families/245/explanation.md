# 245 · Weak normalization implies strong normalization in pure type systems

**Subject:** Mathematical logic

## The question, intuitively

If a typed expression has some terminating reduction path, must every reduction path terminate?

## Papers in this family

- [Weak and strong normalization in pure type systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-and-strong-normalization-in-pure-type-systems-September-25-2026/paper.pdf) — [note](../../papers/paper-2bf179f044c6efa0.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
