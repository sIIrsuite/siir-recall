# 114 · Approximate counting of common integer polymatroid bases

**Subject:** Theoretical computer science

## The question, intuitively

Can we efficiently count integer vectors that satisfy two polymatroid-base constraints simultaneously?

## Papers in this family

- [An FPRAS for Common Integer Polymatroid Bases with Binary Capacities](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-FPRAS-for-Common-Integer-Polymatroid-Bases-with-Binary-Capacities-October-5-2026/polymatroid-fpras.pdf) — [note](../../papers/paper-a46100c82af7f163.md)
- [Approximate counting of common bases of two matroids](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Approximate-counting-of-common-bases-of-two-matroids-September-23-2026/main.pdf) — [note](../../papers/paper-37d510a7d91dc2f7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
