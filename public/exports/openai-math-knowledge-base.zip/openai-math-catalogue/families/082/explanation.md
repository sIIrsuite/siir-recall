# 082 · Annular variation and dyadic absolute bounds for the triangular Hilbert transform

**Subject:** Real and complex analysis

## The question, intuitively

How much cancellation survives in a singular integral coupling three directions, including variation across scales?

## Papers in this family

- [Annular variation of the triangular Hilbert transform at the symmetric point](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Annular-variation-of-the-triangular-Hilbert-transform-at-the-symmetric-point-October-5-2026/annular-variation.pdf) — [note](../../papers/paper-91a1fc251311c9e3.md)
- [An L³ bound for the dyadic triangular Hilbert form](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L3-bound-for-the-dyadic-triangular-Hilbert-form-October-5-2026/dyadic-triangular-hilbert.pdf) — [note](../../papers/paper-d49bbfc14def2c7b.md)
- [The maximal triangular Hilbert transform at the symmetric point](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-maximal-triangular-Hilbert-transform-at-the-symmetric-point-September-24-2026/paper.pdf) — [note](../../papers/paper-e5c7201525f4a19f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
