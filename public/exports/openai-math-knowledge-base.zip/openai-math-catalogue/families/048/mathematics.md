# 048 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Constructs a singular normal affine complex surface with free rank-two tangent sheaf, disproving the characteristic-zero Lipman–Zariski conjecture.

## A singular normal affine surface with free tangent sheaf

We construct a singular normal affine complex surface whose tangent sheaf is free of rank two. This disproves the Lipman–Zariski conjecture in characteristic zero.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-singular-normal-affine-surface-with-free-tangent-sheaf-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-singular-normal-affine-surface-with-free-tangent-sheaf-September-23-2026)
