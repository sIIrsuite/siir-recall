# 048 · A characteristic-zero counterexample to Lipman–Zariski

**Subject:** Algebraic and complex geometry

## The question, intuitively

If tangent directions behave like a free module, must an algebraic space be nonsingular?

## Papers in this family

- [A singular normal affine surface with free tangent sheaf](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-singular-normal-affine-surface-with-free-tangent-sheaf-September-23-2026/paper.pdf) — [note](../../papers/paper-6343e7b14aa1020f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
