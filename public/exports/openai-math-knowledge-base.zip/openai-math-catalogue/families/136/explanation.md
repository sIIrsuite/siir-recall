# 136 · A quasilinear PCP theorem for PPAD

**Subject:** Theoretical computer science

## The question, intuitively

Can equilibrium-search problems be verified through very short probabilistically checkable constructions?

## Papers in this family

- [The PCP-for-PPAD conjecture: a quasilinear reduction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-PCP-for-PPAD-conjecture-a-quasilinear-reduction-September-25-2026/paper.pdf) — [note](../../papers/paper-709441a1e8cc1934.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
