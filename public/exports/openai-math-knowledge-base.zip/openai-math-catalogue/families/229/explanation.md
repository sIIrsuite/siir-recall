# 229 · Exact three- and four-state reconstruction thresholds and four-state tree capacity

**Subject:** Probability and statistical mechanics

## The question, intuitively

When can information sent down a noisy branching tree still be reconstructed at the root?

## Papers in this family

- [The Reconstruction Threshold for the Ferromagnetic Four-State Potts Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/four-state-potts.pdf) — [note](../../papers/paper-6f02d37a7ba80c5f.md)
- [A Capacity Criterion for Four-State Potts Reconstruction on Trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Capacity-Criterion-for-Four-State-Potts-Reconstruction-on-Trees-October-5-2026/four-state-capacity.pdf) — [note](../../papers/paper-487751468997efee.md)
- [The exact reconstruction threshold for the three-state symmetric channel](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-exact-reconstruction-threshold-for-the-three-state-symmetric-channel-September-25-2026/paper.pdf) — [note](../../papers/paper-678d3715cd69b71c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
