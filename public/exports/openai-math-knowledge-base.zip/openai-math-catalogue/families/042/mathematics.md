# 042 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that every complex K3 surface is Oka, including nonprojective surfaces. More generally, every connected minimal compact complex surface of Kodaira dimension zero is Oka; a connected minimal compact complex surface of class VII is Oka exactly when it is a Hopf or Enoki surface.

## Every complex K3 surface is Oka

We prove that every complex K3 surface X is Oka, resolving the K3 Oka conjecture. Equivalently, for every m ≥ 1, every holomorphic map to X from a neighborhood of a compact convex set in ℂ^{m} can be approximated uniformly on that set by entire maps $\mathbb C^m\to X$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-complex-K3-surface-is-Oka-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-complex-K3-surface-is-Oka-September-23-2026)
