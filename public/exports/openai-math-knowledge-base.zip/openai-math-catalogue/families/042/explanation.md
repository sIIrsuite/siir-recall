# 042 · Oka classification for minimal compact complex surfaces: Kodaira dimension zero and class VII

**Subject:** Algebraic and complex geometry

## The question, intuitively

Which compact complex surfaces allow flexible holomorphic maps in the sense of Oka theory?

## Papers in this family

- [Every complex K3 surface is Oka](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-complex-K3-surface-is-Oka-September-23-2026/paper.pdf) — [note](../../papers/paper-c482e720561f2932.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
