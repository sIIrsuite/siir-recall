# 001 · Milne’s rationality conjecture and algebraic specialization

**Subject:** Number theory

## The question, intuitively

When a complex algebraic shape is reduced modulo a prime, do its special geometric classes retain rational, compatible numerical measurements?

## Papers in this family

- [Milne's rationality conjecture for abelian varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Milnes-rationality-conjecture-for-abelian-varieties-October-7-2026/paper.pdf) — [note](../../papers/paper-41244e5999885425.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
