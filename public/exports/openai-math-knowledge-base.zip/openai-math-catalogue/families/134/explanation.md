# 134 · Generalized star height at most three

**Subject:** Theoretical computer science

## The question, intuitively

How deeply must star operations nest in expressions describing regular languages when complement is available?

## Papers in this family

- [Finite Monoid Computations and a Uniform Generalized Star-Height Bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Monoid-Computations-and-a-Uniform-Generalized-Star-Height-Bound-September-25-2026/Finite-Monoid-Computations-and-a-Uniform-Generalized-Star-Height-Bound-September-25-2026.pdf) — [note](../../papers/paper-2404f147f0b49202.md)
- [Generalized Star Height at Most Four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-Star-Height-at-Most-Four-September-25-2026/Generalized-Star-Height-at-Most-Four-September-25-2026.pdf) — [note](../../papers/paper-2e19fd6a8570160d.md)
- [Generalized Star Height at Most Three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-Star-Height-at-Most-Three-September-25-2026/article.pdf) — [note](../../papers/paper-2a7d1782ad7195cf.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
