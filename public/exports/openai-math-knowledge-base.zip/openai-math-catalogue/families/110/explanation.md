# 110 · Optimal-order randomized k-server on arbitrary metrics

**Subject:** Theoretical computer science

## The question, intuitively

How well can an online algorithm move k servers to answer unknown future requests in an arbitrary metric space?

## Papers in this family

- [Squared-logarithmic randomized k-server on arbitrary metrics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Squared-logarithmic-randomized-k-server-on-arbitrary-metrics-September-24-2026/Squared-logarithmic-randomized-k-server-on-arbitrary-metrics-September-24-2026.pdf) — [note](../../papers/paper-af80f27a0db66f71.md)
- [Uniform computation of the squared-logarithmic k-server bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-computation-of-the-squared-logarithmic-k-server-bound-September-24-2026/Uniform-computation-of-the-squared-logarithmic-k-server-bound-September-24-2026.pdf) — [note](../../papers/paper-30f6d4bbce1030c6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
