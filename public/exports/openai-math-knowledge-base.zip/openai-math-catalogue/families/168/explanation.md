# 168 · Combinatorial invariance of Kazhdan–Lusztig polynomials

**Subject:** Combinatorics

## The question, intuitively

Are Kazhdan–Lusztig polynomials determined entirely by the combinatorics of their underlying order intervals?

## Papers in this family

- [Combinatorial invariance of Kazhdan–Lusztig polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Combinatorial-Invariance-of-Kazhdan-Lusztig-Polynomials-September-24-2026/paper.pdf) — [note](../../papers/paper-ff5b532b42178242.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
