# 145 · Rokhlin’s multiple-mixing problem

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

If a system loses pairwise correlation, must all higher-order correlations also disappear?

## Papers in this family

- [Rokhlin's multiple-mixing problem for one transformation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rokhlins-multiple-mixing-problem-for-one-transformation-September-23-2026/paper.pdf) — [note](../../papers/paper-209ef89b9c877b67.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
