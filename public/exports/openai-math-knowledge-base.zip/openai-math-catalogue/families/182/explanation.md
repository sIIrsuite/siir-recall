# 182 · Power savings for intersective polynomial differences and prime arguments

**Subject:** Combinatorics

## The question, intuitively

How strongly does avoiding differences given by polynomial values or primes limit the density of an integer set?

## Papers in this family

- [A power saving for intersective polynomial differences with an exponent depending only on the degree](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-intersective-polynomial-differences-with-an-exponent-depending-only-on-the-degree-October-5-2026/power-saving-intersective-polynomial-differences.pdf) — [note](../../papers/paper-68fa5487b279ffb0.md)
- [A Power Saving for Polynomial Differences at Prime Arguments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Power-Saving-for-Polynomial-Differences-at-Prime-Arguments-October-5-2026/prime-argument-polynomial-differences.pdf) — [note](../../papers/paper-587f6de1195133cc.md)
- [A power saving for square-difference-free sets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-square-difference-free-sets-September-24-2026/paper.pdf) — [note](../../papers/paper-9c985fd7ca410900.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
