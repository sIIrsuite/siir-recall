# 236 · The exact factor-of-IID threshold for free Ising spins on trees

**Subject:** Probability and statistical mechanics

## The question, intuitively

When can free-boundary Ising spins on a tree be generated as a factor of independent randomness?

## Papers in this family

- [The sharp factor-of-IID threshold for the free Ising model on regular trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-factor-of-IID-threshold-for-the-free-Ising-model-on-regular-trees-September-26-2026/article.pdf) — [note](../../papers/paper-d211d21be87dafc6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
