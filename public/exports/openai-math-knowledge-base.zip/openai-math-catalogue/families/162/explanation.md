# 162 · Counterexamples to Ryser’s covering conjecture

**Subject:** Combinatorics

## The question, intuitively

How many vertices are needed to meet every edge of an intersecting multipartite hypergraph?

## Papers in this family

- [Balanced counterexamples to Ryser's conjecture at prime orders](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Balanced-Counterexamples-to-Rysers-Conjecture-at-Prime-Orders-September-27-2026/paper.pdf) — [note](../../papers/paper-1ac5642c24738b48.md)
- [A counterexample to Ryser's covering conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Rysers-Covering-Conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-dd14cd8c6a099634.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
