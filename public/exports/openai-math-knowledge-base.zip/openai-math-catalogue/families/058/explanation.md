# 058 · Semialgebraic universal covers and bounded domains

**Subject:** Algebraic and complex geometry

## The question, intuitively

If a universal cover has a description by finitely many real polynomial inequalities, how rigid must its complex geometry be?

## Papers in this family

- [Semialgebraic universal covers of normal projective varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Semialgebraic-universal-covers-of-normal-projective-varieties-September-24-2026/paper.pdf) — [note](../../papers/paper-c3639a0ea6ca2516.md)
- [Symmetry of semialgebraic bounded domains with compact quotient](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symmetry-of-semialgebraic-bounded-domains-with-compact-quotient-September-24-2026/paper.pdf) — [note](../../papers/paper-797062f12750f925.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
