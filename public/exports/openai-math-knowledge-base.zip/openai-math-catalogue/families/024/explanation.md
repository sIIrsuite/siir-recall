# 024 · An asymptotic formula for the number of totients

**Subject:** Number theory

## The question, intuitively

How many distinct integers up to a given size occur as values of Euler's totient function?

## Papers in this family

- [An asymptotic formula for the number of totients](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-asymptotic-formula-for-the-number-of-totients-September-25-2026/An-asymptotic-formula-for-the-number-of-totients-September-25-2026.pdf) — [note](../../papers/paper-1ad730bf23413812.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
