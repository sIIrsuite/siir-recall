# 066 · Bounded klt complements for Fano contractions

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can singular Fano-type geometry be controlled by complements of uniformly bounded complexity?

## Papers in this family

- [Bounded klt complements for Fano contractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-klt-complements-for-Fano-contractions-September-25-2026/Bounded-klt-complements-for-Fano-contractions-September-25-2026.pdf) — [note](../../papers/paper-47d9a104e6236787.md)
- [Uniform Cartier sections for Fano type contractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Cartier-sections-for-Fano-type-contractions-September-25-2026/Uniform-Cartier-sections-for-Fano-type-contractions-September-25-2026.pdf) — [note](../../papers/paper-9966e5bd525585d5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
