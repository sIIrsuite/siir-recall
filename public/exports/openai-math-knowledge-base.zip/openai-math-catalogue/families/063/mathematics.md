# 063 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the generalized Mukai conjecture: every positive-dimensional smooth complex projective Fano manifold of dimension n, Picard number ρ and pseudoindex ι satisfies $\rho(\iota-1)\le n$, with equality exactly for $(\mathbb P^{\iota-1})^\rho$. Here the pseudoindex is the least anticanonical degree of a rational curve.

## The generalized Mukai conjecture

We prove the generalized Mukai conjecture: every positive-dimensional smooth complex Fano manifold of dimension n, Picard number ρ, and pseudoindex ι satisfies $\rho(\iota-1)\le n$. Equality holds precisely for the product of ρ copies of $\mathbb P^{\iota-1}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Generalized-Mukai-Conjecture-September-24-2026/article.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Generalized-Mukai-Conjecture-September-24-2026)
