# 063 · The generalized Mukai conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

How strongly does positive anticanonical curvature restrict a variety's dimension, Picard rank, and minimal rational-curve degree?

## Papers in this family

- [The generalized Mukai conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Generalized-Mukai-Conjecture-September-24-2026/article.pdf) — [note](../../papers/paper-aef37bb679fb562b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
