# 098 · Compact counterexamples to bi-Lipschitz dimension reduction

**Subject:** Convex and metric geometry

## The question, intuitively

Can some compact metric spaces resist every finite-dimensional distance-preserving representation with bounded distortion?

## Papers in this family

- [A doubling Hilbert subset with no finite-dimensional bi-Lipschitz embedding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-doubling-Hilbert-subset-with-no-finite-dimensional-bi-Lipschitz-embedding-September-25-2026/main.pdf) — [note](../../papers/paper-25541d8e8df4a0b0.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
