# 210 · Foulkes' conjecture for sixth powers and quadratic stabilization

**Subject:** Algebra

## The question, intuitively

Which way do multiplicities compare when two symmetric-power operations are applied in opposite orders?

## Papers in this family

- [Foulkes' conjecture for the sixth symmetric power](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Foulkes-Conjecture-for-the-Sixth-Symmetric-Power-September-25-2026/main.pdf) — [note](../../papers/paper-9f896285de4d3e8c.md)
- [Quadratic stabilization of the canonical Foulkes--Howe map](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quadratic-Stabilization-of-the-Canonical-Foulkes-Howe-Map-September-25-2026/paper.pdf) — [note](../../papers/paper-9116fddf103144d4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
