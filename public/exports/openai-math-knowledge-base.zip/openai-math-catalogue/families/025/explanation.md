# 025 · Short Egyptian fractions

**Subject:** Number theory

## The question, intuitively

How efficiently can a fraction be written as a short sum of reciprocals of integers?

## Papers in this family

- [Short Egyptian fractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Short-Egyptian-fractions-September-25-2026/Short-Egyptian-fractions-September-25-2026.pdf) — [note](../../papers/paper-784dcaafbf16bcd8.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
