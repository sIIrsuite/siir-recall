# 215 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Constructs the canonical continuum limit of the two-dimensional nearest-neighbor $O(3)$ model: a non-Gaussian local relativistic theory with a unique vacuum and a positive mass gap. For the square-lattice $O(4)$ model, determines the exact leading asymptotic of the full transfer gap, $m_{\mathrm{lat}}(\beta)\sim32e^{\pi/4-1/2}\sqrt\beta\,e^{-\pi\beta}$. The family also proves exponential spin-correlation decay for two-dimensional nearest-neighbor $O(n)$ models with n ≥ 3 at every positive temperature. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/215.md))

## The canonical massive continuum limit of the two-dimensional O(3) model

We construct a canonical interacting massive continuum limit of the two-dimensional nearest-neighbor $O(3)$ model with unit-length spins, no external field, and no topological term. Normalized by susceptibility and second-moment correlation length, the limit exists as the bare coupling tends to infinity through all positive real values, without selecting subsequences. The limiting fields satisfy the Osterwalder–Schrader axioms and have a nonzero connected four-point correlation on separated time supports. Their reconstructed theory has a unique vacuum, a nonzero vacuum complement, and a positive Hamiltonian gap on that entire complement.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-canonical-massive-continuum-limit-of-the-two-dimensional-O3-model-October-4-2026/massive-continuum-o3.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-canonical-massive-continuum-limit-of-the-two-dimensional-O3-model-October-4-2026)

## An Isolated Particle Pole for the Two-Dimensional O(3) Spin Field

We consider the continuum spin field constructed from the nearest-neighbor two-dimensional $O(3)$ model by the fixed prescription of the companion paper. We prove that its vector two-point spectral measure has a positive atom corresponding to the lowest mass, separated by a positive gap from all remaining mass support.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Isolated-Particle-Pole-for-the-Two-Dimensional-O3-Spin-Field-October-4-2026/o3-particle-pole.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Isolated-Particle-Pole-for-the-Two-Dimensional-O3-Spin-Field-October-4-2026)

## Exact mass asymptotics for the two-dimensional O(4) lattice model

For the nearest-neighbor $O(4)$ model on the square lattice at inverse temperature β, we prove the exact low-temperature asymptotic

$\displaystyle m_{\mathrm{lat}}(\beta)\sim 32\exp(\pi/4-1/2)\sqrt\beta\,\exp(-\pi\beta) \qquad (\beta\to\infty).$

Here the mass is the gap of the full Osterwalder–Schrader transfer operator, including rotation-invariant local-observable sectors, in units of one original lattice time step.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-mass-asymptotics-for-the-two-dimensional-O4-lattice-model-October-5-2026/exact-mass-o4.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-mass-asymptotics-for-the-two-dimensional-O4-lattice-model-October-5-2026)

## Sharp mass bounds for the two-dimensional O(4) model

We prove sharp mass bounds for the two-dimensional nearest-neighbor $O(4)$ model. For all sufficiently large inverse couplings β, the full transfer gap, including rotation-invariant local-observable sectors, is bounded above and below by positive multiples of $\sqrt\beta e^{-\pi\beta}$. We also prove that the model has a unique periodic local limit and a positive full gap at every finite β > 0, resolving the all-temperature lattice mass-generation conjecture for this periodic state. Under the stated cutoff scaling, the mass bounds are uniform in independently fixed physical units. A continuum spectral interpretation requires separate convergence hypotheses for the transfer semigroup and the block observables.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-mass-bounds-for-the-two-dimensional-O4-model-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-mass-bounds-for-the-two-dimensional-O4-model-September-23-2026)

## Exponential decay in two-dimensional classical O(n) models

We prove exponential decay of two-point correlations for the classical nearest-neighbor $O(n)$ model on the square lattice, for every n ≥ 3 and every finite positive inverse temperature. The estimate is uniform over finite free-boundary subgraphs and bounded nonnegative edge strengths. This resolves positively the all-temperature exponential spin-decay conjecture for these models.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-decay-in-two-dimensional-classical-On-models-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-decay-in-two-dimensional-classical-On-models-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/215.md). A family link does not certify every claim or every companion paper.
