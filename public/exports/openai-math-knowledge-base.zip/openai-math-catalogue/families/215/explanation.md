# 215 · Canonical $O(3)$ continuum limit and exact $O(4)$ mass asymptotics

**Subject:** Probability and statistical mechanics

## The question, intuitively

How do lattice spin models with rotational symmetry approach a continuum field theory, and how precisely does their mass scale behave?

## Papers in this family

- [The canonical massive continuum limit of the two-dimensional O(3) model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-canonical-massive-continuum-limit-of-the-two-dimensional-O3-model-October-4-2026/massive-continuum-o3.pdf) — [note](../../papers/paper-0d60466ce4e43fdf.md)
- [An Isolated Particle Pole for the Two-Dimensional O(3) Spin Field](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Isolated-Particle-Pole-for-the-Two-Dimensional-O3-Spin-Field-October-4-2026/o3-particle-pole.pdf) — [note](../../papers/paper-e46fa1bf299d3419.md)
- [Exact mass asymptotics for the two-dimensional O(4) lattice model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-mass-asymptotics-for-the-two-dimensional-O4-lattice-model-October-5-2026/exact-mass-o4.pdf) — [note](../../papers/paper-609796b35407dd28.md)
- [Sharp mass bounds for the two-dimensional O(4) model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-mass-bounds-for-the-two-dimensional-O4-model-September-23-2026/paper.pdf) — [note](../../papers/paper-f43e04e25b034592.md)
- [Exponential decay in two-dimensional classical O(n) models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-decay-in-two-dimensional-classical-On-models-September-23-2026/paper.pdf) — [note](../../papers/paper-97174ff47fee09c3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
