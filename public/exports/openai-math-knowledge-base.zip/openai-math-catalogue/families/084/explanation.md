# 084 · The geometric case of the Erdős similarity conjecture

**Subject:** Real and complex analysis

## The question, intuitively

Can a measurable set of positive size avoid every scaled and translated copy of a specified geometric sequence?

## Papers in this family

- [The geometric case of the Erdős similarity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-geometric-case-of-the-Erdos-similarity-conjecture-October-5-2026/geometric-erdos-similarity.pdf) — [note](../../papers/paper-a1c3c3a97abe4442.md)
- [The dyadic case of the Erdős similarity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-dyadic-case-of-the-Erdos-similarity-conjecture-September-25-2026/paper.pdf) — [note](../../papers/paper-06a721889eac6514.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
