# 115 · Sampling and counting contingency tables with arbitrary margins

**Subject:** Theoretical computer science

## The question, intuitively

Can tables with fixed row and column totals be sampled and counted efficiently even for arbitrary margins?

## Papers in this family

- [Exact Uniform Sampling of Contingency Tables with Arbitrary Margins](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Uniform-Sampling-of-Contingency-Tables-with-Arbitrary-Margins-September-24-2026/main.pdf) — [note](../../papers/paper-4e6e42294d0e904c.md)
- [An FPRAS for Cell-Bounded Contingency Tables](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-FPRAS-for-Cell-Bounded-Contingency-Tables-September-24-2026/main.pdf) — [note](../../papers/paper-e4abe4c4ee7776cb.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
