# 102 · The Unique Games Conjecture and optimal approximation thresholds

**Subject:** Theoretical computer science

## The question, intuitively

Can nearly satisfiable constraint systems still be computationally hard enough to determine sharp approximation barriers?

## Papers in this family

- [The Unique Games Theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Unique-Games-Theorem-September-23-2026/paper.pdf) — [note](../../papers/paper-0122896e49cb8b79.md)
- [A Direct Proof of Optimal Max-Cut Hardness](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Direct-Proof-of-Optimal-Max-Cut-Hardness-September-23-2026/paper.pdf) — [note](../../papers/paper-e79e9ce01cf713cf.md)
- [The Factor-Two Hardness Threshold for Vertex Cover](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Factor-Two-Hardness-Threshold-for-Vertex-Cover-September-23-2026/paper.pdf) — [note](../../papers/paper-9d567de1c3765ee3.md)
- [Constant-factor hardness of Min-UnCut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-Min-UnCut-September-23-2026/paper.pdf) — [note](../../papers/paper-c5d4813f293dba75.md)
- [Constant-factor hardness of directed feedback vertex set](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-directed-feedback-vertex-set-September-23-2026/paper.pdf) — [note](../../papers/paper-aa17b35bdadfd457.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
