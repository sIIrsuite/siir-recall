# 186 · Uniform influence and sharp thresholds for graph and hypergraph properties

**Subject:** Combinatorics

## The question, intuitively

How strongly must at least one coordinate influence a symmetric graph property, and how narrow is its threshold window?

## Papers in this family

- [A uniform influence bound for hypergraph properties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-uniform-influence-bound-for-hypergraph-properties-October-5-2026/hypergraph-influences.pdf) — [note](../../papers/paper-cb5d8113ca07381e.md)
- [A Sharp Threshold Bound for Monotone Graph Properties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Sharp-Threshold-Bound-for-Monotone-Graph-Properties-September-25-2026/paper.pdf) — [note](../../papers/paper-f7e2f0a385b06707.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
