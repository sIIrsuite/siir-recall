# 052 · Tangent splittings and product decompositions

**Subject:** Algebraic and complex geometry

## The question, intuitively

If the tangent bundle splits, must the geometric space itself split as a product after passing to a suitable cover?

## Papers in this family

- [Universal-cover splitting for compact Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-cover-splitting-for-compact-Kahler-manifolds-September-23-2026/paper.pdf) — [note](../../papers/paper-8f2e32e697966189.md)
- [Integrability of split tangent bundles on rationally connected manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integrability-of-split-tangent-bundles-on-rationally-connected-manifolds-September-23-2026/main.pdf) — [note](../../papers/paper-d9b0c2c323f8dc37.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
