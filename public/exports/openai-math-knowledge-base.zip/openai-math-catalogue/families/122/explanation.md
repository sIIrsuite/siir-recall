# 122 · Quantitative trace-reconstruction bounds with a uniform decoder

**Subject:** Theoretical computer science

## The question, intuitively

How many randomly deleted copies of a string are needed to reconstruct the original uniformly over inputs?

## Papers in this family

- [Uniform quasipolynomial-time trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-quasipolynomial-time-trace-reconstruction-October-5-2026/uniform-trace-reconstruction.pdf) — [note](../../papers/paper-9a709de733cd50f5.md)
- [A latest-anchor induction with spectrally compact masks for worst-case trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-latest-anchor-induction-with-spectrally-compact-masks-for-worst-case-trace-reconstruction-October-5-2026/paper.pdf) — [note](../../papers/paper-02d4394a97f986d3.md)
- [Quantitative lower bounds for trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/quantitative-lower-bounds-for-trace-reconstruction-September-24-2026/paper.pdf) — [note](../../papers/paper-b81b5d62aea3024c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
