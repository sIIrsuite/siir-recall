# 181 · The Erdős–Gallai cycle-decomposition conjecture

**Subject:** Combinatorics

## The question, intuitively

Can the edges of every graph be decomposed into only linearly many cycles and single edges?

## Papers in this family

- [A linear cycle-and-edge decomposition of every graph](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-linear-cycle-and-edge-decomposition-of-every-graph-September-24-2026/main.pdf) — [note](../../papers/paper-aa4a9f7b64d5fc71.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
