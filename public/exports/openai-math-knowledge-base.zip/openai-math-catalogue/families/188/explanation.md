# 188 · The sharp terminal leave in random triangle removal

**Subject:** Combinatorics

## The question, intuitively

When triangles are repeatedly deleted at random, how many edges remain when no triangle survives?

## Papers in this family

- [The sharp terminal leave in random triangle removal](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Sharp-Terminal-Leave-in-Random-Triangle-Removal-September-25-2026/The-Sharp-Terminal-Leave-in-Random-Triangle-Removal-September-25-2026.pdf) — [note](../../papers/paper-3d59f13f48c769b7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
