# 124 · Polynomial-time scheduling on three identical machines

**Subject:** Theoretical computer science

## The question, intuitively

Can precedence-constrained jobs on three identical machines be scheduled optimally in polynomial time in the stated model?

## Papers in this family

- [A Polynomial-Time Algorithm for Three-Machine Unit-Job Scheduling](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-polynomial-time-algorithm-for-three-machine-unit-job-scheduling-September-24-2026/paper.pdf) — [note](../../papers/paper-40a7d8e28e7ad4f5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
