# 183 · Power savings for planar halving lines and k-sets

**Subject:** Combinatorics

## The question, intuitively

How many lines can nearly bisect a planar point set, or isolate exactly k points on one side?

## Papers in this family

- [A power saving for planar halving lines](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-planar-halving-lines-September-25-2026/main.pdf) — [note](../../papers/paper-b336bf8ad16e5436.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
