# 243 · Separating choiceless counting from polynomial time and witnessed choice

**Subject:** Mathematical logic

## The question, intuitively

Can polynomial-time computation be captured by a logic that counts but cannot arbitrarily choose individual elements?

## Papers in this family

- [Choiceless polynomial time with counting does not capture polynomial time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/paper.pdf) — [note](../../papers/paper-e6e04202257f8911.md)
- [Witnessed symmetric choice is strictly stronger than choiceless polynomial time with counting](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Witnessed-symmetric-choice-is-strictly-stronger-than-choiceless-polynomial-time-with-counting-September-24-2026/paper.pdf) — [note](../../papers/paper-3f60c73829f39973.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
