# 174 · Deterministic construction of strong thin spanning trees

**Subject:** Combinatorics

## The question, intuitively

Can we efficiently construct a spanning tree that crosses every cut only a small fraction of the time?

## Papers in this family

- [The strong thin tree conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-strong-thin-tree-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-402de1fcb7f04b26.md)
- [A polynomial-time construction of strong thin trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-polynomial-time-construction-of-strong-thin-trees-September-23-2026/paper.pdf) — [note](../../papers/paper-df23ae02b1b76555.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
