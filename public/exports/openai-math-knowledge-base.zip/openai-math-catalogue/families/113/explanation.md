# 113 · Approximate counting and entropy of perfect matchings

**Subject:** Theoretical computer science

## The question, intuitively

Can we efficiently estimate how many perfect matchings a graph has and the associated uncertainty?

## Papers in this family

- [A Fully Polynomial Randomized Approximation Scheme for Perfect Matchings in General Graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/main.pdf) — [note](../../papers/paper-a6b76a57e739fca3.md)
- [Entropy and Face Dimension of the Perfect-Matching Polytope](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Entropy-and-Face-Dimension-of-the-Perfect-Matching-Polytope-September-23-2026/main.pdf) — [note](../../papers/paper-9c9bb2a021e014c6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
