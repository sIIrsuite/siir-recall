# 032 · The rational Hodge conjecture for CM abelian varieties

**Subject:** Algebraic and complex geometry

## The question, intuitively

For abelian varieties with complex multiplication, do the rational cohomological classes singled out by Hodge theory come from actual algebraic subvarieties?

## Papers in this family

- [The rational Hodge conjecture for CM abelian varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-October-6-2026/paper.pdf) — [note](../../papers/paper-d5946623a117b69b.md)
- [Algebraic Kuga–Satake correspondences and Hodge conjectures on a K3 quadratic locus](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/paper.pdf) — [note](../../papers/paper-edce813b623423a0.md)
- [Weil classes and Hodge classes on abelian powers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weil-classes-and-Hodge-classes-on-abelian-powers-October-6-2026/paper.pdf) — [note](../../papers/paper-fd7a8ca65c7df300.md)
- [Abelian covers, Gale correspondences, and the Hodge conjecture for powers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abelian-covers-Gale-correspondences-and-the-Hodge-conjecture-for-powers-October-6-2026/paper.pdf) — [note](../../papers/paper-58a4e5f68e87d4ff.md)
- [A Conditional Reduction for Algebraic Kuga–Satake Correspondences](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Conditional-Reduction-for-Algebraic-Kuga-Satake-Correspondences-September-10-2026/paper.pdf) — [note](../../papers/paper-b16ed7ffedd101a3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.

## Historical withdrawals in this family

- **Withdrawn:** [The rational Hodge conjecture for products of K3 surfaces](../../papers/paper-aceab999d1936bdd.md)
- **Withdrawn:** [Algebraicity of Kuga–Satake Correspondences for K3 Surfaces](../../papers/paper-66f698e2546cb119.md)
- **Withdrawn:** [Algebraicity of Weil classes on split abelian eightfolds](../../papers/paper-3a543f5fd0dc50a2.md)
