# 100 · Cylinder coverings below the half-area bound

**Subject:** Convex and metric geometry

## The question, intuitively

How much total cross-sectional area is required for cylinders covering a convex body?

## Papers in this family

- [Finite angular cylinder covers below the half-area bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-angular-cylinder-covers-below-the-half-area-bound-September-27-2026/main.pdf) — [note](../../papers/paper-263300816e2dff4c.md)
- [Finite cylinder approximation of ruled sets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-cylinder-approximation-of-ruled-sets-September-27-2026/main.pdf) — [note](../../papers/paper-7c02dfe822dd7473.md)
- [Slope-field perturbations of the two-cylinder covering](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Slope-field-perturbations-of-the-two-cylinder-covering-September-27-2026/main.pdf) — [note](../../papers/paper-1f99e8e106327336.md)
- [Finite triangular approximation of radial sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-triangular-approximation-of-radial-sweeps-September-27-2026/main.pdf) — [note](../../papers/paper-5d1bd9d0543ed713.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
