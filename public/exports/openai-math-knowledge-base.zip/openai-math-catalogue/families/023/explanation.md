# 023 · Patterson's first moment for cubic Gauss sums

**Subject:** Number theory

## The question, intuitively

How much cancellation occurs when cubic exponential sums are averaged over arithmetic inputs?

## Papers in this family

- [An unconditional first moment for cubic Gauss sums](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-unconditional-first-moment-for-cubic-Gauss-sums-September-25-2026/paper.pdf) — [note](../../papers/paper-73ec63fe954d377b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
