# 175 · Talagrand’s expectation thresholds, discrete convexity, and graph decompositions

**Subject:** Combinatorics

## The question, intuitively

Can local witness expectations predict global appearance thresholds and support strong decomposition results?

## Papers in this family

- [Graph Decompositions at the Integral Expectation Threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Graph-Decompositions-at-the-Integral-Expectation-Threshold-October-5-2026/graph-threshold-decompositions.pdf) — [note](../../papers/paper-75ab7f2d7d717948.md)
- [Integral and fractional expectation thresholds are equivalent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-and-fractional-expectation-thresholds-are-equivalent-September-23-2026/paper.pdf) — [note](../../papers/paper-0a3cd65e30e2efc7.md)
- [Talagrand’s discrete-convexity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Talagrands-discrete-convexity-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-97a18fbfcc9edc17.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
