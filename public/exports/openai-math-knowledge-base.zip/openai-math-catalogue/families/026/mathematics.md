# 026 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every fixed C > 0, a positive proportion of consecutive prime gaps exceed $C\log p_n$, throughout every sufficiently large initial segment of the primes. The proportion may depend on C. Consequently, the indices where $p_n/n$ increases have positive lower density, answering Erdős and Prachar. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/026.md))

## Positive lower density of large prime gaps

For every fixed C > 0, we prove that a positive proportion of consecutive prime gaps exceed $C\log p$, where p is the smaller prime. The proportion is bounded below for every sufficiently large initial segment of the prime sequence, with a constant depending on C. It follows that the indices at which $p_n/n$ increases have positive lower asymptotic density, answering a question of Erdős and Prachar.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-lower-density-of-large-prime-gaps-September-25-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-lower-density-of-large-prime-gaps-September-25-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/026.md). A family link does not certify every claim or every companion paper.
