# 026 · Positive lower density of large prime gaps

**Subject:** Number theory

## The question, intuitively

Do unusually large gaps between consecutive primes occur with a positive frequency at the relevant normalized scale?

## Papers in this family

- [Positive lower density of large prime gaps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-lower-density-of-large-prime-gaps-September-25-2026/main.pdf) — [note](../../papers/paper-6c8b0cfe563af4c2.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
