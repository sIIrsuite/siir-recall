# 151 · A C^{1} counterexample to the entropy conjecture

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

Must the topology-driven lower bound on entropy hold for every continuously differentiable dynamical system?

## Papers in this family

- [A C^1 Counterexample to the Entropy Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-C1-Counterexample-to-the-Entropy-Conjecture-September-25-2026/article.pdf) — [note](../../papers/paper-688df3a87fafba92.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
