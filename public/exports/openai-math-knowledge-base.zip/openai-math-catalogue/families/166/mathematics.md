# 166 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every fixed d ≥ 3, any n ≥ 2 distinct points in ℝ^{d} determine at least $c_dn^{2/d}$ distinct distances, with $c_d> 0$ depending only on dimension. This matches the integer-grid order and resolves the higher-dimensional Erdős distinct-distances conjecture with a constant-factor bound.

## The higher-dimensional Erdős distinct-distances conjecture

For every fixed integer d ≥ 3, we prove that every set of n ≥ 2 distinct points in ℝ^{d} determines at least $c_d n^{2/d}$ distinct distances, where $c_d> 0$ depends only on d. This resolves the higher-dimensional Erdős distinct-distances conjecture positively.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-higher-dimensional-Erdos-distinct-distances-conjecture-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-higher-dimensional-Erdos-distinct-distances-conjecture-September-23-2026)
