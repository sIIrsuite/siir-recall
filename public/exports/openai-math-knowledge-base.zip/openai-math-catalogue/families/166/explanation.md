# 166 · The higher-dimensional Erdős distinct-distances conjecture

**Subject:** Combinatorics

## The question, intuitively

How few distinct pairwise distances can n points determine in a fixed higher-dimensional Euclidean space?

## Papers in this family

- [The higher-dimensional Erdős distinct-distances conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-higher-dimensional-Erdos-distinct-distances-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-b016c6c67a7c9aa5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
