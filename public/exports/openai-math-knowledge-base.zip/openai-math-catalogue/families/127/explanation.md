# 127 · Average sensitivity of polynomial threshold functions

**Subject:** Theoretical computer science

## The question, intuitively

How frequently can flipping one input bit change the sign of a low-degree polynomial on the Boolean cube?

## Papers in this family

- [Average sensitivity of polynomial threshold functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Average-Sensitivity-of-Polynomial-Threshold-Functions-September-25-2026/main.pdf) — [note](../../papers/paper-8abf50c0b66d23a7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
