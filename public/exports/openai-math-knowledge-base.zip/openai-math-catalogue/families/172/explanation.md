# 172 · Classification of finite Euclidean Ramsey configurations

**Subject:** Combinatorics

## The question, intuitively

Which finite point patterns inevitably occur monochromatically in sufficiently high-dimensional Euclidean space?

## Papers in this family

- [A classification of finite Euclidean Ramsey configurations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-classification-of-finite-Euclidean-Ramsey-configurations-September-23-2026/paper.pdf) — [note](../../papers/paper-55844238ba801f2e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
