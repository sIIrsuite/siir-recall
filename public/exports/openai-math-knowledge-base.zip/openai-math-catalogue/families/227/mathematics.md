# 227 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For zero-field Gaussian SK heat-bath dynamics with rate-one updates per spin, proves worst-start cutoff on the $\log n$ scale for fixed $0\le\beta< 1$, mixing time $n^{2/3+o(1)}$ at β = 1, and stretched-exponential mixing from a Gibbs-sampled fixed starting configuration for β > 1, in probability over disorder. At criticality, rescaled stationary and quench autocorrelation processes have universal random limits for Gaussian and Rademacher disorder; the quench limit relaxes to the stationary limit. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/227.md))

## Universality of critical quench autocorrelations in the Sherrington–Kirkpatrick model

We prove joint functional convergence of the stationary and quench autocorrelations of zero-field Sherrington–Kirkpatrick heat-bath dynamics at inverse temperature β = 1, with the same random limit for Gaussian and Rademacher couplings. Each site has a rate-one clock, mean spin autocorrelations are multiplied by n^{1/3}, and waiting times and lags are measured in units n^{2/3}. The quench starts from independent fair spins, and convergence is uniform on compact sets of positive waiting times and lags. The quench limit is selected by these initial states and relaxes to the stationary limiting autocorrelation as the waiting time tends to infinity.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universality-of-critical-quench-autocorrelations-in-the-Sherrington-Kirkpatrick-model-October-5-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universality-of-critical-quench-autocorrelations-in-the-Sherrington-Kirkpatrick-model-October-5-2026)

## Functional universality of critical SK autocorrelations

We prove that the stationary spin autocorrelation of the zero-field Sherrington–Kirkpatrick model at inverse temperature β = 1 has a common functional scaling limit for Gaussian and Rademacher couplings. With rate-one heat-bath clocks at every site, time is scaled by n^{2/3} and the mean spin autocorrelation is multiplied by n^{1/3}. The functions converge in law uniformly on compact positive-time intervals. Their limiting law is not a point mass: it retains sample-to-sample randomness, and its functions decay to zero at large times.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Functional-universality-of-critical-SK-autocorrelations-October-5-2026/critical-sk-autocorrelations.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Functional-universality-of-critical-SK-autocorrelations-October-5-2026)

## A spectral gap throughout the high-temperature Sherrington–Kirkpatrick phase

For every fixed inverse temperature $0< \beta< 1$, we prove that the unscaled spectral gap of single-site heat-bath dynamics for the zero-field Gaussian Sherrington–Kirkpatrick model is bounded away from zero with probability tending to one over the disorder. Equivalently, the Gibbs law satisfies a dimension-free Poincaré inequality for all functions.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-spectral-gap-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-spectral-gap-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026)

## Cutoff throughout the high-temperature Sherrington–Kirkpatrick phase

We prove worst-case total-variation cutoff for the zero-field Gaussian Sherrington–Kirkpatrick heat-bath dynamics at every fixed inverse temperature $0\leq\beta< 1$. With rate-one refresh at each spin, the cutoff location is $\log n/(2\lambda(\beta))$ for a positive deterministic rate $\lambda(\beta)$. The location for uniformly chosen single-site update attempts is n times as large. Convergence is in probability over the disorder.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cutoff-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cutoff-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026)

## Critical slowing down in the Sherrington–Kirkpatrick model

At the critical inverse temperature β = 1, we prove slow mixing for zero-field Gaussian Sherrington–Kirkpatrick heat-bath dynamics from typical equilibrium configurations held fixed as initial states. For every deterministic sequence $t_n=o(n^{2/3})$ in rate-one-per-site time, the Gibbs mass of initial states whose time-t_{n} total-variation distance from equilibrium exceeds 1/4 tends to one in probability over the disorder. The same statement holds for every deterministic integer sequence $k_n=o(n^{5/3})$ of uniform-site update attempts.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-slowing-down-in-the-Sherrington-Kirkpatrick-model-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-slowing-down-in-the-Sherrington-Kirkpatrick-model-September-24-2026)

## Stretched-exponential barriers for typical SK initial states

At every fixed inverse temperature β > 1, we prove a stretched-exponential obstruction to mixing for the zero-field Sherrington–Kirkpatrick model from typical equilibrium configurations held fixed as initial states. The Gibbs mass of states whose total-variation distance from equilibrium at time $\exp(n^{1/10000})$ exceeds 1/4 tends to one in probability over the disorder. This holds for rate-one-per-site heat-bath dynamics and after the same stated number of discrete update attempts.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stretched-exponential-barriers-for-typical-SK-initial-states-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stretched-exponential-barriers-for-typical-SK-initial-states-September-24-2026)

## A typical-start upper bound for low-temperature SK Glauber dynamics

For every fixed inverse temperature β > 1, we prove subexponential mixing for rate-one-per-site heat-bath dynamics in the zero-field Gaussian Sherrington–Kirkpatrick model from a typical equilibrium configuration. If one Gibbs-sampled configuration is held fixed as the initial state, its total-variation distance from equilibrium is at most 1/4 by time $\exp(n^{1-1/40000000})$, with joint probability tending to one over the disorder and the sampled state.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-typical-start-upper-bound-for-low-temperature-SK-Glauber-dynamics-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-typical-start-upper-bound-for-low-temperature-SK-Glauber-dynamics-September-24-2026)

## Critical mixing in the Sherrington–Kirkpatrick model

At the critical inverse temperature β = 1, we determine the worst-start total-variation mixing exponent for single-site heat-bath dynamics in the zero-field Gaussian Sherrington–Kirkpatrick model. The mixing time is $n^{2/3+o(1)}$ when every site has rate one, or $n^{5/3+o(1)}$ attempted uniform-site updates, in probability over the disorder.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-mixing-in-the-Sherrington-Kirkpatrick-model-September-25-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-mixing-in-the-Sherrington-Kirkpatrick-model-September-25-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/227.md). A family link does not certify every claim or every companion paper.
