# 227 · Critical SK autocorrelation processes and dynamics across the temperature transition

**Subject:** Probability and statistical mechanics

## The question, intuitively

How does spin autocorrelation evolve at and across the critical temperature of a mean-field spin glass?

## Papers in this family

- [Universality of critical quench autocorrelations in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universality-of-critical-quench-autocorrelations-in-the-Sherrington-Kirkpatrick-model-October-5-2026/main.pdf) — [note](../../papers/paper-99d1b2540dbd7300.md)
- [Functional universality of critical SK autocorrelations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Functional-universality-of-critical-SK-autocorrelations-October-5-2026/critical-sk-autocorrelations.pdf) — [note](../../papers/paper-82d889f640f732c5.md)
- [A spectral gap throughout the high-temperature Sherrington–Kirkpatrick phase](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-spectral-gap-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/main.pdf) — [note](../../papers/paper-c5a80d7e80833383.md)
- [Cutoff throughout the high-temperature Sherrington–Kirkpatrick phase](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cutoff-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/paper.pdf) — [note](../../papers/paper-5a1b81f875948a0f.md)
- [Critical slowing down in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-slowing-down-in-the-Sherrington-Kirkpatrick-model-September-24-2026/paper.pdf) — [note](../../papers/paper-616b3348b753182b.md)
- [Stretched-exponential barriers for typical SK initial states](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stretched-exponential-barriers-for-typical-SK-initial-states-September-24-2026/paper.pdf) — [note](../../papers/paper-ae9d6f4731a499b2.md)
- [A typical-start upper bound for low-temperature SK Glauber dynamics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-typical-start-upper-bound-for-low-temperature-SK-Glauber-dynamics-September-24-2026/paper.pdf) — [note](../../papers/paper-5a30fcdc25b27faa.md)
- [Critical mixing in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-mixing-in-the-Sherrington-Kirkpatrick-model-September-25-2026/paper.pdf) — [note](../../papers/paper-ae7b730a28a3b97b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
