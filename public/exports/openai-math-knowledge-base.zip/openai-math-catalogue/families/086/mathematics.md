# 086 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that the principal-value trilinear Hilbert transform with shifts $x-t$, $x-2t$, $x-3t$ is bounded from $L^3(\mathbb R)^3$ to $L^1(\mathbb R)$. This resolves the L^{3} exponent case of the standard conjecture for slopes 1, 2, 3.

## An L^{3} bound for the trilinear Hilbert transform

We prove that the trilinear Hilbert transform with fixed slopes 1, 2, 3 maps $L^3(\mathbb R)\times L^3(\mathbb R)\times L^3(\mathbb R)$ to $L^1(\mathbb R)$, resolving this case of the trilinear Hilbert transform conjecture.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L3-bound-for-the-trilinear-Hilbert-transform-October-5-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L3-bound-for-the-trilinear-Hilbert-transform-October-5-2026)
