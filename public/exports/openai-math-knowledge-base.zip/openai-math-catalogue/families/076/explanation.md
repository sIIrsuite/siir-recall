# 076 · Real ultraflat Littlewood polynomials and unbounded binary merit factors

**Subject:** Real and complex analysis

## The question, intuitively

Can a polynomial with only plus/minus-one coefficients have almost constant magnitude around the unit circle?

## Papers in this family

- [Ultraflat real Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ultraflat-real-Littlewood-polynomials-October-5-2026/ultraflat-real-littlewood-polynomials.pdf) — [note](../../papers/paper-76a894adace3c264.md)
- [Nearly minimal maxima and positive minima of Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nearly-minimal-maxima-and-positive-minima-of-Littlewood-polynomials-October-5-2026/littlewood-lower-envelope.pdf) — [note](../../papers/paper-a32daef83e1a1ea8.md)
- [Asymptotically minimal maxima of real Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Asymptotically-minimal-maxima-of-real-Littlewood-polynomials-September-23-2026/paper.pdf) — [note](../../papers/paper-d1f8195df6797ddf.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
