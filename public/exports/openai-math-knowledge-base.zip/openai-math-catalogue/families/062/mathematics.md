# 062 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the LeBrun–Salamon conjecture: every closed connected positive quaternionic-Kähler manifold of real dimension at least eight is homothetic to a compact symmetric Wolf space. It also proves contact-Fano homogeneity and classifies smooth connected complex projective contact manifolds of complex dimension at least three: those with $b_2=1$ are adjoint varieties with their canonical contact structures, while those with $b_2\ge2$ have underlying manifold $\mathbb P(T^*Z)$ for a smooth projective variety Z.

## Contact Fano manifolds and the LeBrun–Salamon conjecture

We resolve the contact-Fano homogeneity conjecture and the Riemannian LeBrun–Salamon conjecture positively. Every smooth connected complex projective contact Fano manifold of complex dimension at least three, with its given contact distribution, is contact-isomorphic to the adjoint variety of a simple complex Lie algebra. Consequently, every closed connected smooth positive quaternionic-Kähler manifold of real dimension $4m\geq8$ is homothetic to a compact symmetric Wolf space.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Contact-Fano-manifolds-and-the-LeBrun-Salamon-conjecture-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Contact-Fano-manifolds-and-the-LeBrun-Salamon-conjecture-September-23-2026)
