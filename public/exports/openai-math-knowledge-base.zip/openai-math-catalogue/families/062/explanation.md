# 062 · Projective contact classification and the LeBrun–Salamon conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Are positive quaternionic-Kähler spaces and their complex contact partners all of the predicted homogeneous types?

## Papers in this family

- [Contact Fano manifolds and the LeBrun–Salamon conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Contact-Fano-manifolds-and-the-LeBrun-Salamon-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-fa36a2613dcfba18.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
