# 044 · The equivariant cohomological Hikita conjecture

**Subject:** Algebraic and complex geometry

## The question, intuitively

Does the topology of one symplectic space match the fixed-point geometry of its proposed dual?

## Papers in this family

- [The equivariant cohomological Hikita conjecture for arbitrary quivers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-equivariant-cohomological-Hikita-conjecture-for-arbitrary-quivers-September-24-2026/main.pdf) — [note](../../papers/paper-959d4b7bbafd0cc7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
