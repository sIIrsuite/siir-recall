# 119 · The Courtade–Kumar and Hellinger conjectures

**Subject:** Theoretical computer science

## The question, intuitively

Which single Boolean summary of a noisy binary signal preserves the most information about the original signal?

## Papers in this family

- [Sharp binary-information contraction on the discrete cube](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-binary-information-contraction-on-the-discrete-cube-September-24-2026/main.pdf) — [note](../../papers/paper-7b195817917cb11a.md)
- [Hellinger contraction with arbitrary Boolean output bias](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hellinger-contraction-with-arbitrary-Boolean-output-bias-September-24-2026/main.pdf) — [note](../../papers/paper-77c6b4075ae8a38d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
