# 055 · Gepner symmetry and large-volume stability on threefolds

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can one build stability conditions compatible both with categorical symmetries and with large-volume geometry?

## Papers in this family

- [A Gepner stability condition on every smooth quintic threefold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Gepner-stability-condition-on-every-smooth-quintic-threefold-September-24-2026/paper.pdf) — [note](../../papers/paper-f723d2df8a642c2a.md)
- [Prescribed large-volume charges on threefolds with trivial canonical bundle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prescribed-large-volume-charges-on-threefolds-with-trivial-canonical-bundle-September-24-2026/paper.pdf) — [note](../../papers/paper-5db9fa091b5b53e7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
