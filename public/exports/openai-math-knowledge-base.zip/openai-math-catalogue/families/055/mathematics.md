# 055 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Toda's Gepner conjecture for every smooth complex quintic threefold, constructing a numerical Bridgeland stability condition with the prescribed phase shift 2/5. Also constructs numerical Bridgeland stability conditions at every sufficiently large volume on all smooth projective complex threefolds with trivial canonical bundle, with the exact ordinary and square-root-Todd central charges.

## A Gepner stability condition on every smooth quintic threefold

We prove Toda's normalized quintic Gepner conjecture. On every smooth complex quintic threefold, we construct a numerical Bridgeland stability condition for which tensoring by the hyperplane bundle, followed by the spherical twist at the structure sheaf, increases phase by 2/5.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Gepner-stability-condition-on-every-smooth-quintic-threefold-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Gepner-stability-condition-on-every-smooth-quintic-threefold-September-24-2026)

## Prescribed large-volume charges on threefolds with trivial canonical bundle

Let X be a smooth projective complex threefold with trivial canonical bundle. We construct numerical Bridgeland stability conditions with the exact ordinary and square-root-Todd central charges at every sufficiently large volume. One volume threshold works on an open set of real twists and ample directions. The resulting stability conditions have the support property on the full numerical Grothendieck group and stable point sheaves. Separately, on every smooth projective complex threefold we prove a strong tilt inequality above a volume threshold uniform in the object and twist along a fixed polarization.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prescribed-large-volume-charges-on-threefolds-with-trivial-canonical-bundle-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prescribed-large-volume-charges-on-threefolds-with-trivial-canonical-bundle-September-24-2026)
