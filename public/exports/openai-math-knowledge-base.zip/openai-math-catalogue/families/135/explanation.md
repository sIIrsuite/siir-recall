# 135 · Homogeneous depth-five lower bounds for iterated matrix multiplication

**Subject:** Theoretical computer science

## The question, intuitively

Can explicit matrix-product polynomials force large homogeneous depth-five arithmetic circuits?

## Papers in this family

- [Homogeneous depth-five lower bounds for iterated matrix multiplication](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Homogeneous-depth-five-lower-bounds-for-iterated-matrix-multiplication-September-25-2026/Homogeneous-depth-five-lower-bounds-for-iterated-matrix-multiplication-September-25-2026.pdf) — [note](../../papers/paper-15b46a0552dd4598.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
