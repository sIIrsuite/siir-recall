# 189 · Cycle–clique Ramsey numbers

**Subject:** Combinatorics

## The question, intuitively

How large a complete graph forces either a monochromatic cycle or a monochromatic clique?

## Papers in this family

- [Cycle--clique Ramsey numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cycle-clique-Ramsey-numbers-September-25-2026/Cycle-clique-Ramsey-numbers-September-25-2026.pdf) — [note](../../papers/paper-4da79009900807be.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
