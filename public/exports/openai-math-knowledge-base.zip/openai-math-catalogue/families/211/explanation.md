# 211 · The geometric phase diagram, diffusion, and spectra of random planar maps

**Subject:** Probability and statistical mechanics

## The question, intuitively

What large-scale geometry, diffusion, and spectral behavior emerges from a randomly generated planar map?

## Papers in this family

- [Random Walks on Critical FK–Ising Maps and Liouville Brownian Motion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-Walks-on-Critical-FK-Ising-Maps-and-Liouville-Brownian-Motion-October-5-2026/fk-ising-walk-limit.pdf) — [note](../../papers/paper-54124ba8a3aa7f14.md)
- [Spectral convergence for critical FK–Ising planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spectral-convergence-for-critical-FK-Ising-planar-maps-October-5-2026/spectral-convergence-critical-fk-ising-planar-maps.pdf) — [note](../../papers/paper-7b019d8a67510f29.md)
- [A Linear Clock for Random Walk on Tree-Weighted Planar Maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Linear-Clock-for-Random-Walk-on-Tree-Weighted-Planar-Maps-October-5-2026/linear-clock-random-walk-tree-weighted-planar-maps.pdf) — [note](../../papers/paper-69d43feceb95984a.md)
- [Canonical conformal limits of subcritical FK planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Canonical-conformal-limits-of-subcritical-FK-planar-maps-September-24-2026/main.pdf) — [note](../../papers/paper-6b60070a1f1264f1.md)
- [The critical Liouville quantum sphere and geometric limits of FK maps at q=4](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-Liouville-quantum-sphere-and-geometric-limits-of-FK-maps-at-q-equals-4-September-24-2026/main.pdf) — [note](../../papers/paper-d48dbb2784c3b335.md)
- [Metric-measure limits of subcritical FK and spanning-tree planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-measure-limits-of-subcritical-FK-and-spanning-tree-planar-maps-September-24-2026/main.pdf) — [note](../../papers/paper-b64da66738135f38.md)
- [Brownian continuum random tree limits of finite Fortuin–Kasteleyn maps above four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brownian-continuum-random-tree-limits-of-finite-Fortuin-Kasteleyn-maps-above-four-September-24-2026/main.pdf) — [note](../../papers/paper-6cd400ca66893442.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
