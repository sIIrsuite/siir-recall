# 046 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Constructs a smooth projective complex fourfold with large fundamental group whose universal cover contains no positive-dimensional compact analytic subvariety but is neither Stein nor holomorphically convex. A separate smooth projective complex surface already disproves unrestricted Shafarevich holomorphic convexity in dimension two.

## A projective fourfold with large fundamental group and non-Stein universal cover

We construct a smooth projective complex fourfold with large fundamental group whose universal cover is not Stein. The universal cover contains no positive-dimensional compact complex-analytic subvariety, so this disproves Shafarevich's holomorphic-convexity conjecture even under the large-fundamental-group hypothesis.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-projective-fourfold-with-large-fundamental-group-and-non-Stein-universal-cover-October-5-2026/large-fundamental-group-non-stein.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-projective-fourfold-with-large-fundamental-group-and-non-Stein-universal-cover-October-5-2026)

## A surface counterexample to Shafarevich holomorphic convexity

We construct a smooth connected projective complex surface whose universal cover is not holomorphically convex. This disproves the Shafarevich conjecture on holomorphic convexity in complex dimension two.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-surface-counterexample-to-Shafarevich-holomorphic-convexity-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-surface-counterexample-to-Shafarevich-holomorphic-convexity-September-23-2026)
