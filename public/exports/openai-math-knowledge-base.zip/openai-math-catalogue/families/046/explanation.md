# 046 · Shafarevich counterexamples in dimension two and with large fundamental group

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can a compact complex surface violate the predicted convexity behavior of its universal cover?

## Papers in this family

- [A projective fourfold with large fundamental group and non-Stein universal cover](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-projective-fourfold-with-large-fundamental-group-and-non-Stein-universal-cover-October-5-2026/large-fundamental-group-non-stein.pdf) — [note](../../papers/paper-795e69702de05958.md)
- [A surface counterexample to Shafarevich holomorphic convexity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-surface-counterexample-to-Shafarevich-holomorphic-convexity-September-23-2026/paper.pdf) — [note](../../papers/paper-3f564d3c7259bd48.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
