# 237 · The three-quarter exponent for honeycomb self-avoiding walk

**Subject:** Probability and statistical mechanics

## The question, intuitively

How does the typical spatial extent of a long self-avoiding walk grow with its length on the honeycomb lattice?

## Papers in this family

- [Radial transfer estimates and polygon length laws for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Radial-transfer-estimates-and-polygon-length-laws-for-honeycomb-walks-September-26-2026/main.pdf) — [note](../../papers/paper-c4ca973623b6665b.md)
- [Critical honeycomb chords with prescribed boundary endpoints](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-honeycomb-chords-with-prescribed-boundary-endpoints-September-26-2026/main.pdf) — [note](../../papers/paper-1623bdbccc2a2701.md)
- [Cylinder loop weights and planar nesting](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-loop-weights-and-planar-nesting-September-26-2026/main.pdf) — [note](../../papers/paper-27978ff68108bb0f.md)
- [Mass and covering exponents for fixed-length honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mass-and-covering-exponents-for-fixed-length-honeycomb-walks-September-26-2026/main.pdf) — [note](../../papers/paper-2b2060590067f4cc.md)
- [Signed cylinder propagation and marked polygons on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-cylinder-propagation-and-marked-polygons-on-the-honeycomb-lattice-September-26-2026/main.pdf) — [note](../../papers/paper-4609154dd5780e4d.md)
- [Cylinder amplitudes and logarithmic bridge-length windows on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-amplitudes-and-logarithmic-bridge-length-windows-on-the-honeycomb-lattice-September-26-2026/main.pdf) — [note](../../papers/paper-16d0f105b651fc4a.md)
- [Marked polygon correlations and one-arc bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Marked-polygon-correlations-and-one-arc-bounds-September-26-2026/main.pdf) — [note](../../papers/paper-7c8d8c156d0831e1.md)
- [Disk transfer representations and confined bridge mass](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Disk-transfer-representations-and-confined-bridge-mass-September-26-2026/main.pdf) — [note](../../papers/paper-3a5149b0a5380c41.md)
- [Polynomial vacuum representations and bridge mass for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-vacuum-representations-and-bridge-mass-for-honeycomb-walks-September-26-2026/main.pdf) — [note](../../papers/paper-5757305667c1206f.md)
- [Renewal and changes of law for critical honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Renewal-and-changes-of-law-for-critical-honeycomb-walks-September-26-2026/main.pdf) — [note](../../papers/paper-8632c2fa3c9adfcf.md)
- [Critical strip-crossing mass on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-strip-crossing-mass-on-the-honeycomb-lattice-September-26-2026/main.pdf) — [note](../../papers/paper-ee954b0db73049fb.md)
- [Uniform marked-polygon estimates and sharp finite bridge moments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-marked-polygon-estimates-and-sharp-finite-bridge-moments-September-26-2026/main.pdf) — [note](../../papers/paper-f0fb1035bae11b12.md)
- [Cap-selected amplitudes and triangle chords for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cap-selected-amplitudes-and-triangle-chords-for-honeycomb-walks-September-26-2026/main.pdf) — [note](../../papers/paper-46a375ad32855920.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
