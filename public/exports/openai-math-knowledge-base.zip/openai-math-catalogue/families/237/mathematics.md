# 237 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the diameter form of Nienhuis's predicted three-quarter exponent: a uniformly chosen n-step self-avoiding walk on the honeycomb lattice has diameter $n^{3/4+o(1)}$. Its local mass and covering numbers have exponent 4/3. These estimates hold at every sufficiently large fixed length, simultaneously across scales, with arbitrarily high polynomial probability. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/237.md))

## Radial transfer estimates and polygon length laws for honeycomb walks

We prove critical diameter-tail exponents −2 for unrooted honeycomb polygons and −2/3 for length-weighted polygons, together with a truncated second-length-moment bound of exponent 2/3. Consequently, polygons conditioned to have length at least n have diameter $n^{3/4+o(1)}$ in probability under either weight.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Radial-transfer-estimates-and-polygon-length-laws-for-honeycomb-walks-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Radial-transfer-estimates-and-polygon-length-laws-for-honeycomb-walks-September-26-2026)

## Critical honeycomb chords with prescribed boundary endpoints

Critical self-avoiding walks between prescribed, macroscopically separated boundary ports of a regular honeycomb hexagon have length $R^{4/3+o(1)}$ in probability, where R is the scale of the hexagon. We prove the corresponding statements for half-plane arches, parallel cuts and nonparallel pure cuts. The half-plane law also has mean length $R^{4/3+o(1)}$. A separate strip argument gives endpoint mean laws on one density-one set of heights and in an aligned, critically weighted mixture of all even heights in a macroscopic interval.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-honeycomb-chords-with-prescribed-boundary-endpoints-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-honeycomb-chords-with-prescribed-boundary-endpoints-September-26-2026)

## Cylinder loop weights and planar nesting

We determine the growth exponent, at every fixed positive loop fugacity, of the critical honeycomb partition function for disjoint polygons separating two prescribed markers on a balanced cylinder. At fugacity two the cylinder exponent is 1/6; the corresponding planar nesting exponent and middle-strip nesting exponent are 1/12.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-loop-weights-and-planar-nesting-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-loop-weights-and-planar-nesting-September-26-2026)

## Mass and covering exponents for fixed-length honeycomb walks

For uniform self-avoiding walks of every sufficiently large integer length on the honeycomb lattice, we prove diameter exponent 3/4 and simultaneous local-mass and covering exponent 4/3, with arbitrary positive exponent slack and arbitrary polynomial failure probability.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mass-and-covering-exponents-for-fixed-length-honeycomb-walks-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mass-and-covering-exponents-for-fixed-length-honeycomb-walks-September-26-2026)

## Signed cylinder propagation and marked polygons on the honeycomb lattice

At the critical activity and loop fugacity two, we prove a 1/6 partition exponent for disjoint honeycomb polygons separating opposite marks on a balanced infinite cylinder, and a 1/12 planar nesting exponent. For ordered first-exit chords in a regular hexagon of side R, with both boundary ports summed and diameter at least $R/10$, the finite critical partition is $R^{3/4+o(1)}$ and the normalized mean length is $R^{4/3+o(1)}$. A separate two-bond estimate on tilted cylinders with controlled site proportions bounds the length-square mass of planar polygons of diameter at most H, modulo translations, by $H^{2/3+o(1)}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-cylinder-propagation-and-marked-polygons-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-cylinder-propagation-and-marked-polygons-on-the-honeycomb-lattice-September-26-2026)

## Cylinder amplitudes and logarithmic bridge-length windows on the honeycomb lattice

We prove a logarithmic window of critical honeycomb bridge lengths: summed through height $2h(\log h)^{1/64}$, bridges of lengths between $h^{4/3}(\log h)^{-1/8}$ and $2h^{4/3}(\log h)^{1/2}$ have mass at least $h^{3/4}(\log h)^{-C}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-amplitudes-and-logarithmic-bridge-length-windows-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-amplitudes-and-logarithmic-bridge-length-windows-on-the-honeycomb-lattice-September-26-2026)

## Marked polygon correlations and one-arc bounds

At the critical honeycomb vertex activity, the squared-length mass of simple polygons of diameter at most H, counted modulo translations, is at most $H^{2/3+o(1)}$. We also prove a quantitative two-mark cylinder estimate and a polynomial one-arc bound uniform even for arbitrarily unequal marked intervals.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Marked-polygon-correlations-and-one-arc-bounds-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Marked-polygon-correlations-and-one-arc-bounds-September-26-2026)

## Disk transfer representations and confined bridge mass

We prove that critical honeycomb bridges crossing a strip of width R have mean length $R^{4/3+o(1)}$, with the same exponent after confinement to a fixed multiple of the strip width. The initial boundary port is fixed, the terminal port is summed, and all finite lengths receive their critical weights. The bridge mass is comparable to R^{−1/4}; the half-plane arch kernel at endpoint separation m is comparable to m^{−5/4}.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Disk-transfer-representations-and-confined-bridge-mass-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Disk-transfer-representations-and-confined-bridge-mass-September-26-2026)

## Polynomial vacuum representations and bridge mass for honeycomb walks

We prove that, under the all-length critical measure, a honeycomb bridge crossing a strip of h layers, with its initial port fixed and its terminal port free, has mean length $h^{4/3+o(1)}$. We also obtain central visit probability $R^{-2/3+o(1)}$ and mean length $R^{4/3+o(1)}$ for macroscopic free-boundary chords in a regular hexagon.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-vacuum-representations-and-bridge-mass-for-honeycomb-walks-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-vacuum-representations-and-bridge-mass-for-honeycomb-walks-September-26-2026)

## Renewal and changes of law for critical honeycomb walks

For critical honeycomb self-avoiding walk, we prove spatial exponent 3/4 for the infinite irreducible-bridge law and for bridges of every sufficiently large compatible even length. We establish the corresponding thermal laws at every large discount scale, including all positive length and spatial moments. For unrestricted uniform walks, the endpoint lower law holds on a common set of lengths of natural density one. We also determine the near-critical exponential correlation scale and small-force free-energy exponent, and prove spatial local lower bounds that permit conditioning on a prescribed terminal vertex.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Renewal-and-changes-of-law-for-critical-honeycomb-walks-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Renewal-and-changes-of-law-for-critical-honeycomb-walks-September-26-2026)

## Critical strip-crossing mass on the honeycomb lattice

At the critical weight of the regular honeycomb lattice, the total weight of self-avoiding paths crossing a strip of height N is comparable to N^{−1/4}. The first horizontal-displacement moment of return paths is comparable to N^{3/4}.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-strip-crossing-mass-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-strip-crossing-mass-on-the-honeycomb-lattice-September-26-2026)

## Uniform marked-polygon estimates and sharp finite bridge moments

We prove a uniform bound for critical honeycomb polygons through two axial marks on a periodic staircase. The bound retains an explicit power of the ratio between the period and the marked separation. We also prove sharp finite strip estimates: bridge mass of order h^{−1/4}, first-length mass at most $Ch^{13/12}$, and mass at least $ch^{-1/4}$ on bridges with length at least $ch^{4/3}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-marked-polygon-estimates-and-sharp-finite-bridge-moments-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-marked-polygon-estimates-and-sharp-finite-bridge-moments-September-26-2026)

## Cap-selected amplitudes and triangle chords for honeycomb walks

At the critical honeycomb fugacity, self-avoiding port-to-port chords in an equilateral lattice triangle of side R, summed over both boundary endpoints and restricted to diameter at least $R/100$, have partition sum comparable to R^{3/4} and mean length $R^{4/3+o(1)}$. We also determine the amplitude selected by two vacuum caps on a cylinder of circumference N and prove that it grows as $N^{1/6+o(1)}$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cap-selected-amplitudes-and-triangle-chords-for-honeycomb-walks-September-26-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cap-selected-amplitudes-and-triangle-chords-for-honeycomb-walks-September-26-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/237.md). A family link does not certify every claim or every companion paper.
