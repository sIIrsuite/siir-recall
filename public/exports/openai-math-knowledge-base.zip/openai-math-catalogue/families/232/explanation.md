# 232 · Gaussian fields and interfaces for triangular-lattice Lipschitz heights

**Subject:** Probability and statistical mechanics

## The question, intuitively

Do constrained lattice height surfaces and their boundaries converge to Gaussian fields and conformal random curves?

## Papers in this family

- [Gaussian free-field limits of weighted integer Lipschitz heights](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Gaussian-free-field-limits-of-weighted-integer-Lipschitz-heights-October-6-2026/paper.pdf) — [note](../../papers/paper-189e926318245c9b.md)
- [The Gaussian free field limit of integer Lipschitz heights with two-arc boundary data](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-integer-Lipschitz-heights-with-two-arc-boundary-data-October-6-2026/paper.pdf) — [note](../../papers/paper-e1e49bdf24ad73ed.md)
- [Uniform real Lipschitz surfaces on the triangular lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-real-Lipschitz-surfaces-on-the-triangular-lattice-October-6-2026/paper.pdf) — [note](../../papers/paper-5f4afcf42c4ee82a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
