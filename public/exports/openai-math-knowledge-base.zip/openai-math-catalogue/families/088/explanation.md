# 088 · Sharp projection-body inequalities and a counterexample to simplex maximization

**Subject:** Convex and metric geometry

## The question, intuitively

Which convex shapes extremize inequalities involving their shadows and projection bodies?

## Papers in this family

- [Petty’s projection-volume conjecture in dimensions at least four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pettys-projection-volume-conjecture-in-dimensions-at-least-four-September-24-2026/paper.pdf) — [note](../../papers/paper-baa6c59ad25ce6a1.md)
- [A product counterexample to the simplex maximum for projection-body volume](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-product-counterexample-to-the-simplex-maximum-for-projection-body-volume-September-24-2026/paper.pdf) — [note](../../papers/paper-34632678d2159ed5.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
