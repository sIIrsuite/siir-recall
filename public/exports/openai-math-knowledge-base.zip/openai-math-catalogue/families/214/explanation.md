# 214 · The Benjamini–Schramm nonuniqueness conjecture

**Subject:** Probability and statistical mechanics

## The question, intuitively

On nonamenable graphs, must there be a regime with infinitely many infinite percolation clusters?

## Papers in this family

- [Nonuniqueness of percolation on nonamenable quasi-transitive graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonuniqueness-of-percolation-on-nonamenable-quasi-transitive-graphs-September-24-2026/paper.pdf) — [note](../../papers/paper-18e943ed19efd895.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
