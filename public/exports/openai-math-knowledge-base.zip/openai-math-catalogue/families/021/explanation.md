# 021 · A quadratic bound for Jacobsthal’s function

**Subject:** Number theory

## The question, intuitively

How long can a run of consecutive integers avoid every number coprime to a fixed integer?

## Papers in this family

- [A quadratic bound for Jacobsthal's function](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-quadratic-bound-for-Jacobsthals-function-September-25-2026/paper.pdf) — [note](../../papers/paper-b18cf026d826b615.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
