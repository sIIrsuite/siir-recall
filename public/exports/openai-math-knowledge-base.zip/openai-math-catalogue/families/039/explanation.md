# 039 · Nagata’s conjecture and maximal Seshadri constants

**Subject:** Algebraic and complex geometry

## The question, intuitively

How large must the degree of a plane curve be if it passes through many general points with prescribed multiplicities?

## Papers in this family

- [Nagata's conjecture for plane curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nagatas-Conjecture-for-Plane-Curves-September-23-2026/main.pdf) — [note](../../papers/paper-1ccf84aff034290f.md)
- [Maximal Seshadri constants on arbitrary polarized surfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Seshadri-Constants-on-Arbitrary-Polarized-Surfaces-September-23-2026/main.pdf) — [note](../../papers/paper-d7ef9ee23794ed34.md)
- [Maximal Multipoint Seshadri Constants in Higher Dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Multipoint-Seshadri-Constants-in-Higher-Dimensions-October-5-2026/main.pdf) — [note](../../papers/paper-94c4fa3857313b44.md)
- [Maximal multipoint Seshadri constants in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-multipoint-Seshadri-constants-in-positive-characteristic-October-5-2026/seshadri-positive-characteristic.pdf) — [note](../../papers/paper-f38457a50f77de9f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
