# 039 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Nagata's strict inequality $\sum_i m_i< d\sqrt r$ for every nonzero effective plane curve of degree d through r ≥ 10 very general complex points, with arbitrary multiplicities m_{i}. It also proves maximal multipoint Seshadri constants $(L^n/r)^{1/n}$ for every smooth polarized projective variety of dimension n ≥ 2 and all sufficiently large r: at very general points over ℂ, and at the geometric generic tuple over any algebraically closed field of positive characteristic. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/039.md))

## Nagata's conjecture for plane curves

We prove that a nonzero effective plane curve of degree d at r ≥ 10 very general complex points has total multiplicity strictly less than $d\sqrt r$. The inequality holds simultaneously for all curves, including reducible and nonreduced curves, and establishes Nagata's conjecture in its strict, nonhomogeneous form.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nagatas-Conjecture-for-Plane-Curves-September-23-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nagatas-Conjecture-for-Plane-Curves-September-23-2026)

## Maximal Seshadri constants on arbitrary polarized surfaces

We prove that, for every smooth integral complex projective surface S and every ample line bundle L, the multipoint Seshadri constant at r very general points equals $\sqrt{L^2/r}$ for every sufficiently large integer r. This resolves positively the qualitative Nagata–Biran conjecture for surfaces.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Seshadri-Constants-on-Arbitrary-Polarized-Surfaces-September-23-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Seshadri-Constants-on-Arbitrary-Polarized-Surfaces-September-23-2026)

## Maximal Multipoint Seshadri Constants in Higher Dimensions

Let L be an ample line bundle on a smooth integral complex projective variety X of dimension n ≥ 3. We prove that there is a threshold $r_0=r_0(X,L)$ such that for every integer $r\ge r_0$, the ordinary multipoint Seshadri constant at r very general points equals the volume bound $(L^n/r)^{1/n}$. This establishes the qualitative Nagata–Biran–Szemberg assertion in these dimensions.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Multipoint-Seshadri-Constants-in-Higher-Dimensions-October-5-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Multipoint-Seshadri-Constants-in-Higher-Dimensions-October-5-2026)

## Maximal multipoint Seshadri constants in positive characteristic

Let L be an ample line bundle on a smooth integral projective variety X over an algebraically closed field of positive characteristic, with $\dim X=n\ge3$. We prove that there is a threshold $r_0=r_0(X,L)$ such that for every integer $r\ge r_0$, the ordinary multipoint Seshadri constant at the geometric generic tuple of r points equals the volume bound $(L^n/r)^{1/n}$. The same conclusion holds in dimension two. This establishes the positive-characteristic form of the qualitative Nagata–Biran–Szemberg assertion at geometric generic tuples.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-multipoint-Seshadri-constants-in-positive-characteristic-October-5-2026/seshadri-positive-characteristic.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-multipoint-Seshadri-constants-in-positive-characteristic-October-5-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/039.md). A family link does not certify every claim or every companion paper.
