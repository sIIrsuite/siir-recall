# 207 · The ℓ¹-Bass conjecture for all discrete groups

**Subject:** Algebra

## The question, intuitively

Do traces associated with group-ring projective modules vanish outside the predicted conjugacy classes?

## Papers in this family

- [The ℓ¹-Bass Conjecture for Discrete Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-l1-Bass-Conjecture-for-Discrete-Groups-October-5-2026/l1-bass-conjecture.pdf) — [note](../../papers/paper-a3fd00f07c325ccc.md)
- [The Bass trace conjecture and the characteristic-zero Kaplansky idempotent conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Bass-trace-conjecture-for-complex-group-rings-September-24-2026/The-Bass-trace-conjecture-for-complex-group-rings-September-24-2026.pdf) — [note](../../papers/paper-6207799c710c8652.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
