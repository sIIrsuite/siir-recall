# 206 · Finite lattice representation and undecidability

**Subject:** Algebra

## The question, intuitively

Can every finite lattice arise from congruences of a finite algebra, and can that realization question be decided algorithmically?

## Papers in this family

- [Finite congruence lattices: characterization and undecidability](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Congruence-Lattices-Characterization-and-Undecidability-September-24-2026/paper.pdf) — [note](../../papers/paper-815639a1968248ca.md)
- [A negative solution to the finite lattice representation problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Negative-Solution-to-the-Finite-Lattice-Representation-Problem-September-24-2026/paper.pdf) — [note](../../papers/paper-c3c2c749a8b85b08.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
