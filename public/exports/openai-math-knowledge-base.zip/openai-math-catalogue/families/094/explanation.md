# 094 · Subpolynomial dimension reduction in L_{p}

**Subject:** Convex and metric geometry

## The question, intuitively

Can a finite configuration in an Lp space be compressed into far fewer coordinates while preserving its distances approximately?

## Papers in this family

- [Subpolynomial dimension reduction in Lp](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-dimension-reduction-in-Lp-September-23-2026/paper.pdf) — [note](../../papers/paper-7ed3cd025e4304a8.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
