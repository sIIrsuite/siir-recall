# 094 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every fixed $1< p< \infty$ and distortion D > 1, every n-point subset of real L_{p} embeds into $\ell_p^d$ with distortion at most D and dimension $d=n^{o(1)}$, answering Naor's sublinear-dimension question for p ≠ 2. In contrast, exact embeddings require worst-case dimension $\Theta(n^2)$ when p ≠ 2. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/094.md))

## Subpolynomial dimension reduction in Lp

For every fixed $1< p< \infty$ and D > 1, every n-point subset of a real L_{p} space embeds into $\ell_p^d$ with distortion at most D and subpolynomial dimension $d=n^{o(1)}$. The target has the same exponent p, and the embedding need not be linear.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-dimension-reduction-in-Lp-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-dimension-reduction-in-Lp-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/094.md). A family link does not certify every claim or every companion paper.
