# 117 · Uniform sparsest cut: hardness and semidefinite gaps

**Subject:** Theoretical computer science

## The question, intuitively

How well can a graph's sparsest balanced bottleneck be approximated, and where do semidefinite relaxations fail?

## Papers in this family

- [Constant-factor hardness of uniform sparsest cut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-uniform-sparsest-cut-September-24-2026/Constant-factor-hardness-of-uniform-sparsest-cut-September-24-2026.pdf) — [note](../../papers/paper-669f1c1402a6992e.md)
- [Near-square-root logarithmic integrality gaps for uniform sparsest cut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Near-square-root-logarithmic-integrality-gaps-for-uniform-sparsest-cut-September-24-2026/Near-square-root-logarithmic-integrality-gaps-for-uniform-sparsest-cut-September-24-2026.pdf) — [note](../../papers/paper-b26f379b6eb43f24.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
