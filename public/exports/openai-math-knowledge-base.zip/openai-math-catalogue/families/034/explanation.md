# 034 · Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity

**Subject:** Algebraic and complex geometry

## The question, intuitively

Does weak positivity of a canonical divisor eventually produce enough global sections to define a geometric map?

## Papers in this family

- [Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-for-compact-Kahler-spaces-under-logarithmic-Iitaka-subadditivity-October-6-2026/main.pdf) — [note](../../papers/paper-424f5ed2215b4c5f.md)
- [Uniform indices for semi-log-canonical log Calabi–Yau pairs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-indices-for-semi-log-canonical-log-Calabi-Yau-pairs-October-5-2026/uniform-slc-index.pdf) — [note](../../papers/paper-ff457278f57b8298.md)
- [Conditional good minimal models for compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-good-minimal-models-for-compact-Kahler-fourfolds-October-6-2026/paper.pdf) — [note](../../papers/paper-a6bd97ad81186b68.md)
- [Log abundance in characteristic zero](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-characteristic-zero-September-24-2026/paper.pdf) — [note](../../papers/paper-b377a2b00e07188b.md)
- [Minimal metrics and interior injectivity for nef adjoints](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-metrics-and-interior-injectivity-for-nef-adjoints-September-27-2026/paper.pdf) — [note](../../papers/paper-a5e49d36c53310fb.md)
- [Fourfold nonvanishing by minimal metrics and moving jets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fourfold-nonvanishing-by-minimal-metrics-and-moving-jets-September-27-2026/paper.pdf) — [note](../../papers/paper-097f3c56951bbe0a.md)
- [Lifting sections from the reduced support of an adjoint](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lifting-sections-from-the-reduced-support-of-an-adjoint-September-27-2026/paper.pdf) — [note](../../papers/paper-b601dd5aa1919960.md)
- [Schnell fiber spaces and good canonical models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Schnell-fiber-spaces-and-good-canonical-models-September-24-2026/paper.pdf) — [note](../../papers/paper-bd37d68fad2d217f.md)
- [Uniform log Iitaka fibrations and bounded moduli denominators](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-log-Iitaka-fibrations-and-bounded-moduli-denominators-October-4-2026/uniform-log-iitaka.pdf) — [note](../../papers/paper-9cb2f769aff9f869.md)
- [Uniform Pluricanonical Iitaka Fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Pluricanonical-Iitaka-Fibrations-October-3-2026/paper.pdf) — [note](../../papers/paper-c76d8f4c06f30c9e.md)
- [Relative denominators and effective systems for log Calabi-Yau fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-denominators-and-effective-systems-for-log-Calabi-Yau-fibrations-September-27-2026/paper.pdf) — [note](../../papers/paper-c1ff3749eb0809bf.md)
- [Arithmetic Stein-degree bounds for log Calabi–Yau pairs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-Stein-degree-bounds-for-log-Calabi-Yau-pairs-September-25-2026/paper.pdf) — [note](../../papers/paper-695ce8117c76962b.md)
- [Uniform effective log Iitaka fibrations for fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-effective-log-Iitaka-fibrations-for-fourfolds-September-26-2026/paper.pdf) — [note](../../papers/paper-7e78ca645286362c.md)
- [Abundance after nonvanishing for compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-after-nonvanishing-for-compact-Kahler-fourfolds-September-27-2026/paper.pdf) — [note](../../papers/paper-632b092179f58b6d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
