# 034 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Using logarithmic Iitaka subadditivity, proves log abundance in every dimension for normal compact Kähler log canonical pairs with effective rational boundary: an analytically nef ℚ-Cartier adjoint is semiample. It also proves projective log abundance over every algebraically closed field of characteristic zero and the effective Iitaka fibration conjecture for smooth projective varieties of nonnegative Kodaira dimension in that setting. A further result resolves the finite-rational-coefficient index conjecture for connected projective semi-log-canonical log Calabi–Yau pairs over such fields in each fixed dimension and for each fixed finite set of rational boundary coefficients, with a uniform index independent of the number of components.

## Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity

Assume logarithmic Iitaka subadditivity for surjective morphisms with connected fibers between smooth projective complex varieties with compatible reduced simple normal crossing boundaries. We prove log abundance for normal irreducible compact Kähler spaces in every dimension: for a log canonical pair $(X,\Delta)$ with effective rational boundary and $K_X+\Delta$ ℚ-Cartier, analytic nefness of $K_X+\Delta$ implies semiampleness.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-for-compact-Kahler-spaces-under-logarithmic-Iitaka-subadditivity-October-6-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-for-compact-Kahler-spaces-under-logarithmic-Iitaka-subadditivity-October-6-2026)

## Uniform indices for semi-log-canonical log Calabi–Yau pairs

We prove a uniform index theorem for connected projective semi-log-canonical log Calabi–Yau pairs in every fixed dimension at least four over an algebraically closed field of characteristic zero. For boundary coefficients in a fixed finite rational set, a single multiple of the log canonical divisor is Cartier and linearly trivial. The multiple depends only on the dimension and coefficient set, not on the number of irreducible components. Together with the established theorem in dimensions at most three, this resolves the finite-rational-coefficient semi-log-canonical index conjecture.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-indices-for-semi-log-canonical-log-Calabi-Yau-pairs-October-5-2026/uniform-slc-index.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-indices-for-semi-log-canonical-log-Calabi-Yau-pairs-October-5-2026)

## Conditional good minimal models for compact Kähler fourfolds

Assuming orbifold Iitaka subadditivity and abundance for nef fourfold adjoints of nonnegative Kodaira dimension, we prove the existence of good minimal models for globally strongly ℚ-factorial compact Kähler klt fourfold pairs with effective rational boundary and analytically pseudo-effective actual ℚ-Cartier adjoint. The ordinary fourfold minimal model program supplies the nef endpoint. We prove nonvanishing by fibration arguments and, in algebraic dimension zero, by singular metrics, holomorphic foliations, and extension from a reduced boundary. The projective abundance argument used in the proof is included in full.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-good-minimal-models-for-compact-Kahler-fourfolds-October-6-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-good-minimal-models-for-compact-Kahler-fourfolds-October-6-2026)

## Log abundance in characteristic zero

We prove the rational-boundary log abundance conjecture in every dimension over algebraically closed fields of characteristic zero: every nef ℚ-Cartier log canonical divisor on a projective log canonical pair with effective rational boundary is semiample. Over ℂ, the proof also establishes canonical nonvanishing for smooth projective varieties in every dimension.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-characteristic-zero-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-characteristic-zero-September-24-2026)

## Minimal metrics and interior injectivity for nef adjoints

Let $(H,\Theta)$ be a projective complex klt pair with effective rational boundary and nef ℚ-Cartier adjoint. On any projective log resolution, minimal semipositive metrics on the pulled-back adjoint exist and have zero Lelong numbers everywhere. On smooth projective complex varieties, we also prove an H^{1}-injectivity theorem for rational interior boundaries with simple-normal-crossing support when both endpoint bundles carry zero-Lelong semipositive metrics.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-metrics-and-interior-injectivity-for-nef-adjoints-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-metrics-and-interior-injectivity-for-nef-adjoints-September-27-2026)

## Fourfold nonvanishing by minimal metrics and moving jets

We prove canonical nonvanishing for smooth connected projective complex fourfolds: if K_{X} is pseudo-effective, then $H^0(X,mK_X)\ne0$ for some positive integer m.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fourfold-nonvanishing-by-minimal-metrics-and-moving-jets-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fourfold-nonvanishing-by-minimal-metrics-and-moving-jets-September-27-2026)

## Lifting sections from the reduced support of an adjoint

For a projective ℚ-factorial dlt pair with effective rational boundary over an algebraically closed field of characteristic zero, we prove that the adjoint has positive Iitaka dimension whenever a nonzero effective Cartier multiple is supported on the coefficient-one boundary and restricts to a semiample line bundle on its whole reduced support. This gives log abundance after nonvanishing in dimension at most four over ℂ.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lifting-sections-from-the-reduced-support-of-an-adjoint-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lifting-sections-from-the-reduced-support-of-an-adjoint-September-27-2026)

## Schnell fiber spaces and good canonical models

We prove the Campana–Peternell inequality $\kappa(X)\geq\kappa(D)$ for a smooth connected projective complex variety X and an effective Cartier divisor D whenever $m_0K_X-D$ is pseudo-effective for some positive integer m_{0}. For an algebraic fiber space $f\colon X\to Y$ between smooth connected projective complex varieties, the hypothesis that $m_0K_X-f^*H$ is pseudo-effective with H ample Cartier gives $\kappa(X)=\kappa(F)+\dim Y$ for a very general smooth fiber F, as well as nonzero sections of $mK_X-f^*H$ for all sufficiently large divisible m.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Schnell-fiber-spaces-and-good-canonical-models-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Schnell-fiber-spaces-and-good-canonical-models-September-24-2026)

## Uniform log Iitaka fibrations and bounded moduli denominators

For normal projective log canonical pairs over algebraically closed fields of characteristic zero, of fixed dimension d ≥ 5 and with effective boundary coefficients in a fixed finite rational set, we prove that one complete rounded pluricanonical system generates the full Iitaka field whenever the ℚ-Cartier log canonical divisor has nonnegative Kodaira dimension. Its degree depends only on the dimension and coefficient set. For the paper's normalized canonical bundle formulae over ℂ, we also bound the Cartier denominators of the moduli divisors on smooth projective determining models in terms of the dimension and coefficient set.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-log-Iitaka-fibrations-and-bounded-moduli-denominators-October-4-2026/uniform-log-iitaka.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-log-Iitaka-fibrations-and-bounded-moduli-denominators-October-4-2026)

## Uniform Pluricanonical Iitaka Fibrations

We prove the effective Iitaka fibration conjecture in characteristic zero. For each dimension, one pluricanonical degree defines the Iitaka fibration of every smooth integral projective variety of that dimension and nonnegative Kodaira dimension over an algebraically closed field. The associated sections generate the full Iitaka function field.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Pluricanonical-Iitaka-Fibrations-October-3-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Pluricanonical-Iitaka-Fibrations-October-3-2026)

## Relative denominators and effective systems for log Calabi-Yau fibrations

We prove uniform denominator and effective-system bounds for log Calabi-Yau fibrations from projective log canonical complex pairs of dimension at most four onto positive-dimensional bases, with boundary coefficients in a fixed finite rational set. The bounds give a uniform trivializing degree and a uniform b-Cartier multiple of the moduli b-divisor. When the base divisor is big, a uniform complete rounded adjoint system has section ratios generating the full base function field.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-denominators-and-effective-systems-for-log-Calabi-Yau-fibrations-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-denominators-and-effective-systems-for-log-Calabi-Yau-fibrations-September-27-2026)

## Arithmetic Stein-degree bounds for log Calabi–Yau pairs

Fix d ≥ 1 and t > 0. Let $(X,B)$ be an ordinary projective log canonical ℚ-pair of dimension d over a characteristic-zero field k, with X normal and integral, $H^0(X,\mathcal O_X)=k$, B effective, and $K_X+B\sim_{\mathbb Q}0$. We prove that every prime component S of B with coefficient at least t satisfies $[k_S:k]\leq N(d,t)$, where k_{S} is the relative algebraic closure of k in $k(S)$. This also bounds the Stein degree of S over k, proving the contraction-to-a-point formulation of Birkar's Stein-degree conjecture for ordinary ℚ-pairs.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-Stein-degree-bounds-for-log-Calabi-Yau-pairs-September-25-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-Stein-degree-bounds-for-log-Calabi-Yau-pairs-September-25-2026)

## Uniform effective log Iitaka fibrations for fourfolds

We prove the finite-rational-coefficient case of the effective log Iitaka conjecture in dimension four. For normal projective log canonical complex fourfolds with boundary coefficients in a fixed finite rational set and pseudo-effective rational Cartier adjoint, one uniform degree makes the complete rounded reflexive system nonempty and its section ratios generate the full Iitaka field. We also prove a uniform canonical index bound for projective klt complex fourfolds with rationally trivial canonical divisor.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-effective-log-Iitaka-fibrations-for-fourfolds-September-26-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-effective-log-Iitaka-fibrations-for-fourfolds-September-26-2026)

## Abundance after nonvanishing for compact Kähler fourfolds

We prove semiampleness of the actual ℚ-Cartier adjoint $K_X+\Delta$ of a normal connected compact Kähler klt fourfold whenever it is analytically nef and some positive Cartier multiple has a nonzero section. The boundary is effective and rational; the fourfold need not be projective or ℚ-factorial. In Iitaka dimension zero, a positive Cartier multiple is the trivial holomorphic line bundle.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-after-nonvanishing-for-compact-Kahler-fourfolds-September-27-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-after-nonvanishing-for-compact-Kahler-fourfolds-September-27-2026)
