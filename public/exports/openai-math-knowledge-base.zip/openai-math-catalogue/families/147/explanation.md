# 147 · The near-boundary Birkhoff conjecture

**Subject:** Dynamical systems and ergodic theory

## The question, intuitively

If a billiard is smoothly integrable near its boundary, must its boundary be an ellipse?

## Papers in this family

- [Continuous Phase Foliations Create Analytic Caustic Collars](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Continuous-Phase-Foliations-Create-Analytic-Caustic-Collars-September-24-2026/paper.pdf) — [note](../../papers/paper-a33520af93cb6e3e.md)
- [Rigidity of Smooth Billiards with a Continuous Caustic Collar](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rigidity-of-Smooth-Billiards-with-a-Continuous-Caustic-Collar-September-24-2026/paper.pdf) — [note](../../papers/paper-71a85ff50cd0b5dc.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
