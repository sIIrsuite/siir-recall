# 006 · Goldfeld’s conjecture: densities and mean analytic rank

**Subject:** Number theory

## The question, intuitively

If we twist an elliptic curve in all quadratic ways, how frequently does it have zero or one independent rational direction?

## Papers in this family

- [Goldfeld's analytic density conjecture and the 2-converse for elliptic curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Goldfelds-analytic-density-conjecture-and-the-2-converse-for-elliptic-curves-October-7-2026/paper.pdf) — [note](../../papers/paper-4e07e64d4982e982.md)
- [The mean analytic rank of quadratic twists of elliptic curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-mean-analytic-rank-of-quadratic-twists-of-elliptic-curves-October-6-2026/paper.pdf) — [note](../../papers/paper-d16a695c835ad31d.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
