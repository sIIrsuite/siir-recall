# 090 · Triangular-lattice optimality, long-range Riesz and Coulomb energies, and spherical logarithmic energy

**Subject:** Convex and metric geometry

## The question, intuitively

Why should triangular arrangements minimize suitable long-range repulsive energies, and what is the corresponding spherical behavior?

## Papers in this family

- [An atomic certificate for triangular-lattice universal optimality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-atomic-certificate-for-triangular-lattice-universal-optimality-September-26-2026/paper.pdf) — [note](../../papers/paper-5943bd03b2930cfb.md)
- [Universal optimality of the triangular lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-optimality-of-the-triangular-lattice-September-23-2026/paper.pdf) — [note](../../papers/paper-bbd4e1a1173c3f7b.md)
- [A sharp Fourier certificate for planar circle packing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-Fourier-certificate-for-planar-circle-packing-September-23-2026/paper.pdf) — [note](../../papers/paper-31e9cc4857e0f3f4.md)
- [Triangular minimality for planar Coulomb renormalized energy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Triangular-minimality-for-planar-Coulomb-renormalized-energy-September-23-2026/paper.pdf) — [note](../../papers/paper-91d5bb1b617478bf.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
