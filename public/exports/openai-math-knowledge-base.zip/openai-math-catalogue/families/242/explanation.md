# 242 · Single-fold Diophantine representations and undecidability under an at-most-one-solution promise

**Subject:** Mathematical logic

## The question, intuitively

Can recursively enumerable sets be encoded by polynomial equations with at most one auxiliary solution for each input?

## Papers in this family

- [Single-fold Diophantine representations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Single-fold-Diophantine-representations-September-24-2026/paper.pdf) — [note](../../papers/paper-d4cd188fb2cb316e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
