# 179 · The circulant Hadamard and Barker-sequence conjectures

**Subject:** Combinatorics

## The question, intuitively

Can highly symmetric plus/minus-one matrices or long binary sequences attain the conjectured perfect correlation patterns?

## Papers in this family

- [The circulant Hadamard conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-circulant-Hadamard-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-25bab455cfc62825.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
