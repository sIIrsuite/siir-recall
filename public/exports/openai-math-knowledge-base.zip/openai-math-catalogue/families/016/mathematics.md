# 016 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the abelian Zilber–Pink conjecture over $\overline{\mathbb Q}$: every irreducible subvariety has finitely many maximal atypical subvarieties relative to its smallest containing torsion coset. It also proves the full curve case in the Siegel threefold $\mathcal A_2$ for Hodge-generic curves defined over $\overline{\mathbb Q}$, without boundary or reduction assumptions.

## The abelian Zilber–Pink conjecture

We prove the abelian Zilber–Pink conjecture over $\overline{\mathbb Q}$. Every irreducible subvariety of an abelian variety has only finitely many maximal atypical subvarieties, where atypicality is measured inside its smallest containing torsion coset.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Abelian-Zilber-Pink-Conjecture-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Abelian-Zilber-Pink-Conjecture-September-24-2026)

## The E×CM component of Zilber–Pink for curves in A2

We prove the $E\times\mathrm{CM}$ component of Zilber–Pink for Hodge-generic algebraic curves in $\mathcal A_2$ over $\overline{\mathbb Q}$. Each such curve contains only finitely many points whose abelian surface is isogenous to a product of elliptic curves with at least one factor having complex multiplication.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-E-times-CM-Component-of-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-E-times-CM-Component-of-Zilber-Pink-for-Curves-in-A2-September-24-2026)

## Quaternionic division points on curves in the Siegel threefold

We prove the quaternionic-division component of Zilber–Pink for curves in $\mathcal A_2$ over $\overline{\mathbb Q}$. A Hodge-generic algebraic curve contains only finitely many points whose full geometric rational endomorphism algebra is an indefinite quaternion division algebra over ℚ. No boundary or reduction hypothesis is required.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quaternionic-Division-Points-on-Curves-in-the-Siegel-Threefold-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quaternionic-Division-Points-on-Curves-in-the-Siegel-Threefold-September-24-2026)

## Elliptic squares and Zilber–Pink for curves in A2

We prove that every Hodge-generic algebraic curve in $\mathcal A_2$ over $\overline{\mathbb Q}$ contains only finitely many points whose abelian surface is isogenous to the square of an elliptic curve without complex multiplication (CM). Combining this result with the companion $E\times\mathrm{CM}$ and quaternionic-division finiteness theorems, we prove the curve case of Zilber–Pink in $\mathcal A_2$ over $\overline{\mathbb Q}$, without a boundary hypothesis.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-Squares-and-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-Squares-and-Zilber-Pink-for-Curves-in-A2-September-24-2026)
