# 016 · Zilber–Pink in abelian varieties and the Siegel threefold

**Subject:** Number theory

## The question, intuitively

When an algebraic family meets unusually special subspaces, must those exceptional intersections follow a controlled pattern?

## Papers in this family

- [The abelian Zilber–Pink conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Abelian-Zilber-Pink-Conjecture-September-24-2026/paper.pdf) — [note](../../papers/paper-5f6563d80875cb63.md)
- [The E×CM component of Zilber–Pink for curves in A2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-E-times-CM-Component-of-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) — [note](../../papers/paper-8c980448a55015ec.md)
- [Quaternionic division points on curves in the Siegel threefold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quaternionic-Division-Points-on-Curves-in-the-Siegel-Threefold-September-24-2026/paper.pdf) — [note](../../papers/paper-2ef48b291790dcd2.md)
- [Elliptic squares and Zilber–Pink for curves in A2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-Squares-and-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) — [note](../../papers/paper-b74213ff4d7cd242.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
