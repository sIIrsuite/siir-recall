# 008 · The Deligne–Drinfeld conjecture

**Subject:** Number theory

## The question, intuitively

Is a symmetry algebra underlying fundamental arithmetic constructions generated freely by one basic ingredient in each odd degree?

## Papers in this family

- [The Deligne-Drinfeld conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Deligne-Drinfeld-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-f4b3bda1fd07a075.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
