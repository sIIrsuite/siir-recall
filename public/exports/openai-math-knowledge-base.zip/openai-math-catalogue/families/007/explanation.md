# 007 · Ordinary two-point correlations and the corrected Elliott conjecture

**Subject:** Number theory

## The question, intuitively

Do multiplicative arithmetic sequences lose correlation when sampled along two different linear patterns?

## Papers in this family

- [Ordinary two-point correlations of multiplicative functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/final.pdf) — [note](../../papers/paper-f60e4abaa8fe9cb2.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
