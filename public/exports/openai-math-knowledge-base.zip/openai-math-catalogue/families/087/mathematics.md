# 087 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves the symmetric and nonsymmetric geometric Mahler conjectures in every dimension, with Hanner polytopes and simplices as the respective volume-product minimizers and all equality cases classified. The corresponding sharp functional Mahler inequalities also hold. For n ≥ 2, every symmetric polar product $K\times K^\circ$ in dimension $2n$ has Gromov width 4. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/087.md))

## The symmetric Mahler conjecture and its equality cases

We resolve the symmetric Mahler conjecture positively, including its equality classification. Every origin-symmetric convex body in ℝ^{n} has volume product at least $4^n/n!$, with equality exactly for invertible linear images of Hanner polytopes.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-symmetric-Mahler-conjecture-and-its-equality-cases-September-22-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-symmetric-Mahler-conjecture-and-its-equality-cases-September-22-2026)

## The Mahler Conjecture for General Convex Bodies

We resolve the Mahler conjecture for general convex bodies positively. For every convex body $K\subset\mathbb R^n$, n ≥ 1, with Santaló point $s(K)$, $|K|\,|(K-s(K))^\circ|\ge (n+1)^{n+1}/(n!)^2$, with equality exactly for simplices.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mahler-Conjecture-for-General-Convex-Bodies-September-22-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mahler-Conjecture-for-General-Convex-Bodies-September-22-2026)

## Symplectic Balls in Symmetric Polar Products

For every integer n ≥ 2 and every origin-symmetric convex body $K\subset\mathbb R^n$, we prove that the Gromov width of $\mathop{\mathrm{int}}\nolimits K\times\mathop{\mathrm{int}}\nolimits K^\circ$ is 4. We construct smooth symplectic embeddings of standard balls of every capacity $0< c< 4$ into this polar product. Volume preservation then resolves the symmetric Mahler conjecture positively in every dimension.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symplectic-Balls-in-Symmetric-Polar-Products-September-22-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symplectic-Balls-in-Symmetric-Polar-Products-September-22-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/087.md). A family link does not certify every claim or every companion paper.
