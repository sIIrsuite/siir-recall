# 087 · The Mahler conjectures, functional inequalities and polar-product symplectic width

**Subject:** Convex and metric geometry

## The question, intuitively

How small can the product of the volume of a convex body and the volume of its polar be?

## Papers in this family

- [The symmetric Mahler conjecture and its equality cases](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-symmetric-Mahler-conjecture-and-its-equality-cases-September-22-2026/paper.pdf) — [note](../../papers/paper-b07e69d4140dae68.md)
- [The Mahler Conjecture for General Convex Bodies](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mahler-Conjecture-for-General-Convex-Bodies-September-22-2026/paper.pdf) — [note](../../papers/paper-853109e89b8dc2fc.md)
- [Symplectic Balls in Symmetric Polar Products](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symplectic-Balls-in-Symmetric-Polar-Products-September-22-2026/paper.pdf) — [note](../../papers/paper-0e551ff041d4ae00.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
