# 164 · Hindman’s finite sums and products conjecture

**Subject:** Combinatorics

## The question, intuitively

Does every finite coloring of the natural numbers contain an infinite set whose finite sums and products all have one color?

## Papers in this family

- [Monochromatic finite sums and products in the positive integers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Monochromatic-finite-sums-and-products-in-the-positive-integers-September-23-2026/paper.pdf) — [note](../../papers/paper-f0e22ea0125d7f58.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
