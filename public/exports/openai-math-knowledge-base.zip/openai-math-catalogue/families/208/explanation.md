# 208 · Finite symmetric tensor categories and the Verlinde tower

**Subject:** Algebra

## The question, intuitively

How can finite symmetric tensor categories in positive characteristic be classified using Verlinde-type structures?

## Papers in this family

- [Fiber functors for finite symmetric tensor categories in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fiber-functors-for-finite-symmetric-tensor-categories-in-positive-characteristic-September-24-2026/paper.pdf) — [note](../../papers/paper-ced36e9f9f1df495.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
