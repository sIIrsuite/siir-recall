# 208 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that every finite symmetric tensor category over an algebraically closed field k of characteristic p > 0 admits a k-linear exact faithful strong symmetric monoidal fiber functor to a higher Verlinde category $\mathrm{Ver}_{p^n}$. The level may depend on the category, and the theorem includes characteristic two, resolving the finite case of the Benson–Etingof–Ostrik conjecture.

## Fiber functors for finite symmetric tensor categories in positive characteristic

We prove the finite case of the Benson–Etingof–Ostrik conjecture: every finite symmetric tensor category over an algebraically closed field k of characteristic p > 0 admits a k-linear exact faithful strong symmetric monoidal functor to a finite higher Verlinde category $\mathop{\mathrm{Ver}}\nolimits _{p^n}(k)$. The result includes characteristic two, and the level n may depend on the category.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fiber-functors-for-finite-symmetric-tensor-categories-in-positive-characteristic-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fiber-functors-for-finite-symmetric-tensor-categories-in-positive-characteristic-September-24-2026)
