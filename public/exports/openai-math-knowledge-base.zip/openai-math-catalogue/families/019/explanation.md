# 019 · The local p-adic section conjecture and global consequences

**Subject:** Number theory

## The question, intuitively

Can a compatible choice of points encoded in Galois-group data actually come from a geometric point?

## Papers in this family

- [Étale covers with a prescribed exterior sheet](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Etale-covers-with-a-prescribed-exterior-sheet-September-24-2026/main.pdf) — [note](../../papers/paper-adc2655fabe9a960.md)
- [The p-adic section conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-p-adic-section-conjecture-October-6-2026/main.pdf) — [note](../../papers/paper-c39cb55bdb28163e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
