# 019 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves that rational points on every smooth proper geometrically connected curve of genus at least two over a finite extension of ℚ_{p} correspond bijectively to conjugacy classes of sections of its full arithmetic étale fundamental group. It also proves Grothendieck's section conjecture over ℚ for the modular curves $X_0(N)$ and $X_1(N)$ of genus at least two.

## Étale covers with a prescribed exterior sheet

Let X be a smooth proper hyperbolic curve over an algebraic closure of a p-adic local field. Given finitely many disjoint small open disks, we construct one connected finite étale cover with a sheet isomorphic to their entire exterior and with degree divisible by p on every connected component above each disk.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Etale-covers-with-a-prescribed-exterior-sheet-September-24-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Etale-covers-with-a-prescribed-exterior-sheet-September-24-2026)

## The p-adic section conjecture

We prove the local p-adic section conjecture for smooth proper geometrically connected curves of genus at least two, over every finite extension of ℚ_{p}. Combined with established finite-descent theorems, this also yields the global section conjecture for smooth proper geometrically connected curves of genus at least two over number fields when their finite-cover descent locus equals their rational points; this includes $X_0(N)$ and $X_1(N)$ of genus at least two over ℚ.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-p-adic-section-conjecture-October-6-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-p-adic-section-conjecture-October-6-2026)
