# 170 · Sharp logarithmic exponents for off-diagonal Ramsey numbers

**Subject:** Combinatorics

## The question, intuitively

How sharply can we estimate Ramsey numbers when one of the required monochromatic clique sizes is fixed?

## Papers in this family

- [The sharp logarithmic exponent of r(5,t)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Sharp-Logarithmic-Exponent-of-r-5-t-September-24-2026/paper.pdf) — [note](../../papers/paper-18a63ab98aab5c73.md)
- [Sharp logarithmic exponents for fixed off-diagonal Ramsey numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-Logarithmic-Exponents-for-Fixed-Off-Diagonal-Ramsey-Numbers-September-24-2026/paper.pdf) — [note](../../papers/paper-3e6d3f180c806d78.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
