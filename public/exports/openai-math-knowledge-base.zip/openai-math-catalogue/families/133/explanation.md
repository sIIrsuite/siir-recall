# 133 · The computational complexity of Weisfeiler–Leman refinement

**Subject:** Theoretical computer science

## The question, intuitively

How much computational work does iterative Weisfeiler–Leman graph refinement actually require?

## Papers in this family

- [Parity lifts and bounded-treewidth witnesses for Weisfeiler–Leman equivalence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Parity-lifts-and-bounded-treewidth-witnesses-for-Weisfeiler-Leman-equivalence-September-25-2026/paper.pdf) — [note](../../papers/paper-363a3d4723d50577.md)
- [The complexity of identifying a graph by Weisfeiler–Leman refinement](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-complexity-of-identifying-a-graph-by-Weisfeiler-Leman-refinement-September-25-2026/paper.pdf) — [note](../../papers/paper-6594217390655ed8.md)
- [Unconditional time lower bounds for Weisfeiler–Leman equivalence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unconditional-time-lower-bounds-for-Weisfeiler-Leman-equivalence-September-25-2026/paper.pdf) — [note](../../papers/paper-29d6e91ab2b893b8.md)
- [Variable-dimension Weisfeiler–Leman equivalence on general and subcubic graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Variable-dimension-Weisfeiler-Leman-equivalence-on-general-and-subcubic-graphs-September-25-2026/paper.pdf) — [note](../../papers/paper-04af26066aee9c8c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
