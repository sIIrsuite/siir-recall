# 160 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves Erdős's superexponential-growth question for van der Waerden numbers. If $W_r(k)$ is the least interval length forcing a monochromatic k-term progression in every r-coloring, then $W_r(k)> k^{ck\lfloor\log_2 r\rfloor}$ for an absolute c > 0, all r ≥ 2 and sufficiently large k, uniformly in r. In particular, $W_r(k)^{1/k}\to\infty$ for each fixed r. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/160.md))

## Quantitative Superexponential Bounds for van der Waerden Numbers

We prove that there are absolute constants c > 0 and K_{0} such that $W_r(k)> k^{ck\lfloor\log_2 r\rfloor}$ for every $k\ge K_0$ and r ≥ 2. Consequently $W_r(k)^{1/k}\to\infty$ for each fixed r ≥ 2, giving a quantitative positive resolution of Erdős's superexponential-growth question, including the two-color case.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantitative-Superexponential-Bounds-for-van-der-Waerden-Numbers-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantitative-Superexponential-Bounds-for-van-der-Waerden-Numbers-September-23-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/160.md). A family link does not certify every claim or every companion paper.
