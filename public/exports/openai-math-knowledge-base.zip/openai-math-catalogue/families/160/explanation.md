# 160 · Superexponential van der Waerden numbers

**Subject:** Combinatorics

## The question, intuitively

How fast does the interval length needed to force monochromatic arithmetic progressions grow?

## Papers in this family

- [Quantitative Superexponential Bounds for van der Waerden Numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantitative-Superexponential-Bounds-for-van-der-Waerden-Numbers-September-23-2026/paper.pdf) — [note](../../papers/paper-81b18a4e8e665558.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
