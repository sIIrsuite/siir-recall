# 054 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every sufficiently large admissible Hassett discriminant, a very general smooth complex cubic fourfold is irrational despite having both an untwisted geometric K3 category and an integral Hodge-theoretic K3 association. This disproves Kuznetsov's rationality conjecture and the sufficiency of the associated-K3 criterion for rationality; the discriminant threshold is ineffective.

## Irrational cubic fourfolds with geometric K3 categories

For every sufficiently large admissible Hassett discriminant, we prove that a very general cubic fourfold of that discriminant is irrational, although its Kuznetsov component is equivalent to the ordinary derived category of a projective K3 surface. The discriminant threshold is ineffective. This disproves Kuznetsov's rationality conjecture. The same cubics have associated untwisted polarized K3 surfaces in the Hodge-theoretic sense, so they also disprove the sufficiency direction of the associated-K3 rationality prediction.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026)
