# 054 · Irrational cubic fourfolds with Hodge-theoretic and categorical K3 associations

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can a cubic fourfold remain nonrational even when several K3-type structures make it resemble expected rational examples?

## Papers in this family

- [Irrational cubic fourfolds with geometric K3 categories](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026.pdf) — [note](../../papers/paper-64185cbf8d42f952.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
