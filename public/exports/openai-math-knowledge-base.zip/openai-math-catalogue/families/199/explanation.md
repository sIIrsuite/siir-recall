# 199 · Counterexamples to Auslander–Reiten, Tachikawa and related homological conjectures

**Subject:** Algebra

## The question, intuitively

Do vanishing self-extension conditions force a module or algebra to have the predicted projective or injective structure?

## Papers in this family

- [An explicit counterexample to the Auslander-Reiten conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-counterexample-to-the-Auslander-Reiten-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-79581b711f50a64d.md)
- [A counterexample to Tachikawa's second conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Tachikawas-second-conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-ba058fe207bc26ec.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
