# 069 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the unramified de Rham quantum geometric Langlands equivalence for every connected simple complex algebraic group on every smooth projective connected complex curve, at every shifted level $c\in\mathbb C\setminus\mathbb Q$. It identifies the full derived categories of twisted D-modules for the group and its Langlands dual, retaining all global forms and connected components.

## Global quantum geometric Langlands at irrational level

We prove the unramified quantum geometric Langlands equivalence for every connected simple complex algebraic group G and every level $c\in\mathbb C\setminus\mathbb Q$, including non-real levels. For every smooth projective connected complex curve X, it identifies the full twisted D-module categories on $\mathop{\mathrm{Bun}}\nolimits _G(X)$ and $\mathop{\mathrm{Bun}}\nolimits _{G^\vee}(X)$ at the dual shifted levels c and $-1/(rc)$, where r is the lacing number. The equivalence uses the given global forms and includes all connected components.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-quantum-geometric-Langlands-at-irrational-level-October-4-2026/quantum-langlands.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-quantum-geometric-Langlands-at-irrational-level-October-4-2026)
