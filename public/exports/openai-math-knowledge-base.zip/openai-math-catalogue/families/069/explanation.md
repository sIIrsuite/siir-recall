# 069 · Global quantum geometric Langlands at irrational level

**Subject:** Algebraic and complex geometry

## The question, intuitively

Can quantum-deformed geometric representation data be paired across the Langlands correspondence at irrational coupling?

## Papers in this family

- [Global quantum geometric Langlands at irrational level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-quantum-geometric-Langlands-at-irrational-level-October-4-2026/quantum-langlands.pdf) — [note](../../papers/paper-7c40db5babc2000f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
