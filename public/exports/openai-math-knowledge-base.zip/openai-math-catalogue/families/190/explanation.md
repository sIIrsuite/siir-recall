# 190 · Polynomial removal fails for ordered binary matrices

**Subject:** Combinatorics

## The question, intuitively

Can removing every forbidden pattern from an ordered binary matrix require more than polynomial dependence on pattern density?

## Papers in this family

- [Polynomial removal fails for ordered binary matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-removal-fails-for-ordered-binary-matrices-September-25-2026/paper.pdf) — [note](../../papers/paper-6456af5a1db59e32.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
