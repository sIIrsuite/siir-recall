# 251 · Amenability, unitarizability, and strong Ulam stability

**Subject:** Group theory

## The question, intuitively

How closely are invariant averaging, unitary realizations, and stability of approximate group representations related?

## Papers in this family

- [Unitarizability implies amenability for discrete groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unitarizability-Implies-Amenability-for-Countable-Groups-September-23-2026/paper.pdf) — [note](../../papers/paper-023df749e3e23b54.md)
- [Strong Ulam Stability Characterizes Amenability](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strong-Ulam-Stability-Characterizes-Amenability-October-5-2026/strong-ulam-stability.pdf) — [note](../../papers/paper-3150e8d1bee4abae.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
