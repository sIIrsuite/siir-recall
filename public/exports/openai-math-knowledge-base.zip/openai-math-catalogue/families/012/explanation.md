# 012 · Independent largest prime factors of consecutive integers

**Subject:** Number theory

## The question, intuitively

Are the largest prime factors of neighboring integers statistically independent in the long run?

## Papers in this family

- [The joint Dickman law for consecutive integers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-joint-Dickman-law-for-consecutive-integers-September-24-2026/paper.pdf) — [note](../../papers/paper-7c9b89f9acaa639b.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
