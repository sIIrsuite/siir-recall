# 185 · Counterexamples to infinite matroid intersection and packing/covering

**Subject:** Combinatorics

## The question, intuitively

Do familiar intersection and packing-covering principles for finite matroids remain valid for infinite matroids?

## Papers in this family

- [A Counterexample to the Infinite Matroid Packing/Covering Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-the-Infinite-Matroid-Packing-Covering-Conjecture-September-24-2026/paper.pdf) — [note](../../papers/paper-8948bbcce83ba7e9.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
