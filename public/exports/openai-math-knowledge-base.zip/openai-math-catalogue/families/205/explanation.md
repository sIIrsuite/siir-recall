# 205 · Saxl’s conjecture and universal tensor squares

**Subject:** Algebra

## The question, intuitively

Does the tensor square of a staircase representation contain every irreducible representation of the relevant symmetric group?

## Papers in this family

- [Universal Tensor Squares for Symmetric Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-Tensor-Squares-for-Symmetric-Groups-September-24-2026/main.pdf) — [note](../../papers/paper-b50343a2ec8d5fb9.md)
- [A Cyclic Polytabloid Proof of Saxl's Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Cyclic-Polytabloid-Proof-of-Saxls-Conjecture-September-24-2026/paper.pdf) — [note](../../papers/paper-1ae49d454fec628f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
