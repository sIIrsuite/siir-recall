# 205 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Saxl's conjecture: the tensor square of every staircase representation contains every irreducible complex representation of the corresponding symmetric group. More generally, every S_{n} with $n\notin\{2,4,9\}$ has an irreducible representation whose tensor square contains all irreducibles. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/205.md))

## Universal Tensor Squares for Symmetric Groups

For every positive integer n other than 2, 4, and 9, we prove that some irreducible complex representation of S_{n} has a tensor square containing every irreducible representation. This resolves the tensor square conjecture for symmetric groups affirmatively.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-Tensor-Squares-for-Symmetric-Groups-September-24-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-Tensor-Squares-for-Symmetric-Groups-September-24-2026)

## A Cyclic Polytabloid Proof of Saxl's Conjecture

For every staircase partition, we prove that the tensor square of the corresponding irreducible complex representation of the symmetric group contains every irreducible representation of that group. This proves Saxl's conjecture.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Cyclic-Polytabloid-Proof-of-Saxls-Conjecture-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Cyclic-Polytabloid-Proof-of-Saxls-Conjecture-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/205.md). A family link does not certify every claim or every companion paper.
