# 035 · Log-canonical threefold abundance in numerical dimension one

**Subject:** Algebraic and complex geometry

## The question, intuitively

For a mildly singular three-dimensional space whose canonical divisor has one effective numerical direction, does that direction come from a global map?

## Papers in this family

- [Log abundance in numerical dimension one for threefolds in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-numerical-dimension-one-for-threefolds-in-positive-characteristic-October-5-2026/paper.pdf) — [note](../../papers/paper-ea927814ebabc3d2.md)
- [Abundance in numerical dimension one for terminal threefolds in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-in-numerical-dimension-one-for-terminal-threefolds-in-positive-characteristic-September-24-2026/paper.pdf) — [note](../../papers/paper-ad7a849f20c5e87a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
