# 035 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves log abundance for projective log canonical threefold pairs over algebraically closed fields of characteristic p > 3 when the effective boundary is rational and the ℚ-Cartier adjoint is nef of numerical dimension one. The adjoint is semiample, without requiring the original variety to be terminal or ℚ-factorial.

## Log abundance in numerical dimension one for threefolds in positive characteristic

We prove the numerical-dimension-one case of log abundance for threefolds over algebraically closed fields of characteristic p > 3. If $(X,B)$ is a projective log canonical threefold pair with effective rational boundary, and $K_X+B$ is ℚ-Cartier, nef, and of numerical dimension one, then $K_X+B$ is semiample. Neither terminality nor ℚ-factoriality of X is required.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-numerical-dimension-one-for-threefolds-in-positive-characteristic-October-5-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-numerical-dimension-one-for-threefolds-in-positive-characteristic-October-5-2026)

## Abundance in numerical dimension one for terminal threefolds in positive characteristic

Let X be a projective ℚ-factorial terminal threefold over an algebraically closed field of characteristic p > 3. We prove the numerical-dimension-one case of abundance: if K_{X} is nef with $\nu(K_X)=1$, then K_{X} is semiample and $\kappa(X,K_X)=1$.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-in-numerical-dimension-one-for-terminal-threefolds-in-positive-characteristic-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-in-numerical-dimension-one-for-terminal-threefolds-in-positive-characteristic-September-24-2026)
