# 177 · Bounded-degree coboundary expanders

**Subject:** Combinatorics

## The question, intuitively

Can bounded-degree complexes have robust higher-dimensional expansion, analogous to well-connected sparse graphs?

## Papers in this family

- [Bounded-degree coboundary expanders in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/paper.pdf) — [note](../../papers/paper-1029f319b3e46860.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
