# 198 · A counterexample to finitistic-dimension finiteness

**Subject:** Algebra

## The question, intuitively

Must finite projective resolutions over a finite-dimensional algebra have a uniformly bounded maximum length?

## Papers in this family

- [An algebra of infinite little finitistic dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-algebra-of-infinite-little-finitistic-dimension-September-23-2026/paper.pdf) — [note](../../papers/paper-315560cf0726c894.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
