# 047 · Zariski cancellation and affine fibrations over the complex numbers

**Subject:** Algebraic and complex geometry

## The question, intuitively

If adding one affine coordinate makes two algebraic spaces isomorphic, were the original spaces already isomorphic?

## Papers in this family

- [An explicit failure of complex affine-space cancellation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-failure-of-complex-affine-space-cancellation-September-23-2026/paper.pdf) — [note](../../papers/paper-c01f49713c2f01d3.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
