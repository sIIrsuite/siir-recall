# 171 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves the Burr–Erdős hypercube Ramsey conjecture: the two-color Ramsey number of the n-dimensional cube is $\Theta(2^n)$. Thus every red-blue coloring of a complete graph on a universal constant times the cube's number of vertices contains a monochromatic copy of the cube.

## The hypercube Ramsey number has linear order

We prove that the two-color Ramsey number of the n-dimensional binary cube is at most $C2^n$, where C is an absolute constant. This resolves positively the hypercube Ramsey conjecture of Burr and Erdős.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-hypercube-Ramsey-number-has-linear-order-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-hypercube-Ramsey-number-has-linear-order-September-23-2026)
