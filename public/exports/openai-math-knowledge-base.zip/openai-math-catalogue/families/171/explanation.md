# 171 · The hypercube Ramsey conjecture

**Subject:** Combinatorics

## The question, intuitively

How large a complete graph forces a monochromatic copy of a high-dimensional hypercube?

## Papers in this family

- [The hypercube Ramsey number has linear order](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-hypercube-Ramsey-number-has-linear-order-September-23-2026/paper.pdf) — [note](../../papers/paper-50aa1b3ee10eed4e.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
