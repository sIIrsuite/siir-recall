# 248 · Thompson's group F is nonamenable

**Subject:** Group theory

## The question, intuitively

Does Thompson's group F admit an invariant notion of averaging over all of its elements?

## Papers in this family

- [Thompson's group F is nonamenable](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thompsons-group-F-is-nonamenable-September-23-2026/paper.pdf) — [note](../../papers/paper-f19833c96eb43ea6.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
