# 096 · The Gaussian propeller conjecture in every dimension

**Subject:** Convex and metric geometry

## The question, intuitively

Which partition of Gaussian space maximizes a specified barycentric objective, and is the propeller-shaped partition optimal?

## Papers in this family

- [The Gaussian propeller bound in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-Propeller-Bound-in-Every-Dimension-September-24-2026/main.pdf) — [note](../../papers/paper-d53eafe7e9ff96b2.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
