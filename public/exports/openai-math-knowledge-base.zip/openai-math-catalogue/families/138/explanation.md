# 138 · Subset Sum in $O(2^{0.49n})$ time

**Subject:** Theoretical computer science

## The question, intuitively

Can subset sum be solved faster than the classic square-root-of-the-search-space exponential scale?

## Papers in this family

- [Subset Sum in Time $O(2^{0.49n})$](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subset-Sum-in-Time-2-power-0-49n-October-4-2026/subset-sum.pdf) — [note](../../papers/paper-ebd91ba7507763dc.md)
- [A Low-Space Algorithm for Worst-Case Subset Sum](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Low-Space-Algorithm-for-Worst-Case-Subset-Sum-September-26-2026/paper.pdf) — [note](../../papers/paper-744dc527663d3c7f.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
