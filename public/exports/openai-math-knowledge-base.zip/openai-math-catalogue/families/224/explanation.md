# 224 · Critical and quenched near-critical universality for Poisson–Voronoi percolation

**Subject:** Probability and statistical mechanics

## The question, intuitively

Does random Voronoi percolation have the same universal continuum behavior as standard planar percolation, even near criticality?

## Papers in this family

- [From critical crossings to quenched near-critical universality in Voronoi percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-critical-crossings-to-quenched-near-critical-universality-in-Voronoi-percolation-October-5-2026/critical-crossings-quenched-near-critical-universality-voronoi-percolation.pdf) — [note](../../papers/paper-b0b29e21115b0472.md)
- [A Pivotal Amplitude for Voronoi Percolation from Cardy's Formula](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Pivotal-Amplitude-for-Voronoi-Percolation-from-Cardys-Formula-October-5-2026/voronoi-pivotal-amplitude.pdf) — [note](../../papers/paper-3ec0af99e46668cc.md)
- [Cardy’s formula for critical Poisson–Voronoi percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cardys-formula-for-critical-Poisson-Voronoi-percolation-September-23-2026/paper.pdf) — [note](../../papers/paper-6df5f15a9d19a90c.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
