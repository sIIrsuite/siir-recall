# 224 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves Cardy's formula for annealed critical Poisson–Voronoi crossing probabilities in every bounded Jordan quadrilateral. With each model normalized by its own expected unit-square pivotal count, the conditional joint near-critical crossing-threshold laws for rational polygonal quads converge in environment probability to the triangular-lattice reference law. This establishes quenched near-critical universality for crossing thresholds.

## From critical crossings to quenched near-critical universality in Voronoi percolation

Taking Cardy's crossing formula for critical Poisson–Voronoi percolation as an input, we prove a universal joint limit for the near-critical crossing thresholds of rational polygonal quadrilaterals under the monotone coupling. Conditional on the Poisson tessellation, the threshold law converges in probability over tessellations to the same law as on the triangular lattice. Each model is normalized by its own expected number of color-pivotal sites for a unit-square crossing.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-critical-crossings-to-quenched-near-critical-universality-in-Voronoi-percolation-October-5-2026/critical-crossings-quenched-near-critical-universality-voronoi-percolation.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-critical-crossings-to-quenched-near-critical-universality-in-Voronoi-percolation-October-5-2026)

## A Pivotal Amplitude for Voronoi Percolation from Cardy's Formula

Taking Cardy's conformal crossing formula for critical planar Poisson–Voronoi percolation in every bounded Jordan quadrilateral as an input, we prove that the expected number of color-pivotal cells for a unit-square crossing is asymptotic to a positive constant times $\varepsilon ^{-3/4}$, where the point intensity is $\varepsilon ^{-2}$. No rate of convergence in Cardy's formula is required.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Pivotal-Amplitude-for-Voronoi-Percolation-from-Cardys-Formula-October-5-2026/voronoi-pivotal-amplitude.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Pivotal-Amplitude-for-Voronoi-Percolation-from-Cardys-Formula-October-5-2026)

## Cardy’s formula for critical Poisson–Voronoi percolation

We prove Cardy's formula for annealed crossing probabilities in critical planar Poisson–Voronoi percolation in every bounded Jordan quadrilateral. This proves the annealed crossing-probability form of the conformal-invariance conjecture for this model.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cardys-formula-for-critical-Poisson-Voronoi-percolation-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cardys-formula-for-critical-Poisson-Voronoi-percolation-September-23-2026)
