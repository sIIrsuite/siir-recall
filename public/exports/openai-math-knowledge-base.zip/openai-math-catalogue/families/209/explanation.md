# 209 · Integral counterexamples to Gersten’s conjecture

**Subject:** Algebra

## The question, intuitively

Does the expected exactness of algebraic K-theory along a regular local space always survive integrally?

## Papers in this family

- [An integral counterexample to Gersten's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026.pdf) — [note](../../papers/paper-c0b9fdf6093b01fe.md)
- [An integral degree-three Gersten counterexample](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Degree-Three-Gersten-Counterexample-September-26-2026/paper.pdf) — [note](../../papers/paper-2f448c5a4c2a25ac.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
