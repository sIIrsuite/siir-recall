# 209 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Disproves unrestricted integral Gersten injectivity in degrees 3 and 5. Two explicit two-dimensional ramified regular local rings of mixed characteristic $(0,5)$ have nonzero integral K-theory classes that vanish over their fraction fields.

## An integral counterexample to Gersten's conjecture

We construct a two-dimensional ramified regular local ring A of mixed characteristic $(0,5)$ for which $K_5(A)\to K_5(\mathop{\mathrm{Frac}}\nolimits A)$ has a nonzero kernel. This disproves Gersten's conjecture in its unrestricted integral form.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026)

## An integral degree-three Gersten counterexample

We construct a two-dimensional ramified regular local ring A in mixed characteristic $(0,5)$ for which the integral map $K_3(A)\to K_3(\mathop{\mathrm{Frac}}\nolimits A)$ has nonzero kernel. This gives a negative answer to the unrestricted integral Gersten conjecture.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Degree-Three-Gersten-Counterexample-September-26-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Degree-Three-Gersten-Counterexample-September-26-2026)
