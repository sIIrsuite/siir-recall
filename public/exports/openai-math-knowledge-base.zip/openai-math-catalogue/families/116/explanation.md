# 116 · Uniform black-box noncommutative identity testing across characteristics

**Subject:** Theoretical computer science

## The question, intuitively

Can an algorithm detect whether a noncommutative polynomial is identically zero using only input-output access?

## Papers in this family

- [Uniform Matrix Hitting Points in Every Positive Characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Matrix-Hitting-Points-in-Every-Positive-Characteristic-October-4-2026/uniform-matrix-hitting-points-positive-characteristic.pdf) — [note](../../papers/paper-bafcd17a1009229c.md)
- [One Rational Matrix Hitting Point for Noncommutative Formulas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/One-Rational-Matrix-Hitting-Point-for-Noncommutative-Formulas-September-24-2026/One-Rational-Matrix-Hitting-Point-for-Noncommutative-Formulas-September-24-2026.pdf) — [note](../../papers/paper-e8702eb3edf4cc7e.md)
- [Polynomial Hitting Lists for Noncommutative Rational Formulas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf) — [note](../../papers/paper-677471faece59b68.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
