# 081 · Riesz transforms and rectifiability in higher codimension

**Subject:** Real and complex analysis

## The question, intuitively

Can bounded singular-integral behavior force a rough higher-codimension set to resemble smooth surfaces?

## Papers in this family

- [Riesz transforms and uniform rectifiability in higher codimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Riesz-transforms-and-uniform-rectifiability-in-higher-codimension-September-24-2026/paper.pdf) — [note](../../papers/paper-6e3930fcb4205109.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
