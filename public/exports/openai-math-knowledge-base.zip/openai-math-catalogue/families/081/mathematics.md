# 081 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Resolves the remaining higher-codimension Riesz-transform rectifiability problem: for d ≥ 4 and $2\le n\le d-2$, an n-Ahlfors–David regular Radon measure on ℝ^{d} is uniformly n-rectifiable whenever its n-dimensional Riesz transform is uniformly L^{2}-bounded over all positive hard truncations. The rectifiability bounds depend only on dimension, regularity and operator bounds. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/081.md))

## Riesz transforms and uniform rectifiability in higher codimension

We prove that an n-Ahlfors–David regular Radon measure on ℝ^{d} is uniformly n-rectifiable if its n-dimensional Riesz transform is uniformly bounded from scalar $L^2(\mu)$ to vector-valued $L^2(\mu)$ over all positive hard truncations, for integers d ≥ 4 and $2\le n\le d-2$. This gives a positive answer to the David–Semmes Riesz-transform question in its remaining higher-codimension range. The conclusion gives uniform big pieces of Lipschitz images of Euclidean balls.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Riesz-transforms-and-uniform-rectifiability-in-higher-codimension-September-24-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Riesz-transforms-and-uniform-rectifiability-in-higher-codimension-September-24-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/081.md). A family link does not certify every claim or every companion paper.
