# 027 · Potential integral density on curve character varieties

**Subject:** Number theory

## The question, intuitively

After enlarging the number field, can integral points become geometrically dense in spaces of representations of curve groups?

## Papers in this family

- [Integral points on character varieties of curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-points-on-character-varieties-of-curves-September-25-2026/paper.pdf) — [note](../../papers/paper-746c4859bd0007c7.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
