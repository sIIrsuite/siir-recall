# 238 · Optimal logarithmic mixing of the Thorp shuffle

**Subject:** Probability and statistical mechanics

## The question, intuitively

How many rounds of the Thorp card shuffle are needed to approach a uniformly random permutation?

## Papers in this family

- [Optimal-order mixing of the Thorp shuffle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Optimal-order-mixing-of-the-Thorp-shuffle-September-26-2026/paper.pdf) — [note](../../papers/paper-025591fd075b13f8.md)
- [Random coordinate frames and partial permutation laws](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-coordinate-frames-and-partial-permutation-laws-September-26-2026/main.pdf) — [note](../../papers/paper-33d1bc7e07c70610.md)
- [From partial permutation information to Fourier bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-partial-permutation-information-to-Fourier-bounds-September-26-2026/main.pdf) — [note](../../papers/paper-d7bc9b13ce9fc85f.md)
- [Conditional information under deterministic coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-information-under-deterministic-coordinate-sweeps-September-26-2026/main.pdf) — [note](../../papers/paper-494bf6af76754487.md)
- [Conditional permutations in a revealed switching environment](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-permutations-in-a-revealed-switching-environment-September-26-2026/paper.pdf) — [note](../../papers/paper-ce6a8a7cfdd51cf0.md)
- [Routing densities and representation contraction for Thorp sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Routing-densities-and-representation-contraction-for-Thorp-sweeps-September-26-2026/paper.pdf) — [note](../../papers/paper-d4649633f45577f3.md)
- [Row–column symmetry and contraction of coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Row-column-symmetry-and-contraction-of-coordinate-sweeps-September-26-2026/paper.pdf) — [note](../../papers/paper-4cd1b43908669d25.md)
- [Random-subspace tests and trace smoothing for coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-subspace-tests-and-trace-smoothing-for-coordinate-sweeps-September-26-2026/paper.pdf) — [note](../../papers/paper-23352c559ca6130f.md)
- [Compatibility entropy and the spectrum of a Thorp sweep](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Compatibility-entropy-and-the-spectrum-of-a-Thorp-sweep-September-26-2026/paper.pdf) — [note](../../papers/paper-066bd17e20c91725.md)
- [Signed tensor densities and diagram budgets for the Thorp shuffle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-tensor-densities-and-diagram-budgets-for-coordinate-sweeps-September-26-2026/paper.pdf) — [note](../../papers/paper-5677e8662d3a064d.md)
- [Conditional coordinate sweeps and analytic transfer](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-coordinate-sweeps-and-analytic-transfer-September-26-2026/main.pdf) — [note](../../papers/paper-2a0250a8d5ca112d.md)
- [A strict four-row permanent inequality and permutation moments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-four-row-permanent-inequality-and-permutation-moments-September-26-2026/main.pdf) — [note](../../papers/paper-cfd3197691c1cfa4.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
