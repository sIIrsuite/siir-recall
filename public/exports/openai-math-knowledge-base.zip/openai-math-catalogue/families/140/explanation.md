# 140 · Memory–sample lower bounds for noiseless Gaussian regression

**Subject:** Theoretical computer science

## The question, intuitively

How does limited memory increase the number of samples needed to learn even noiseless Gaussian linear regression?

## Papers in this family

- [Memory and precision in noiseless Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Memory-and-precision-in-noiseless-Gaussian-regression-September-27-2026/paper.pdf) — [note](../../papers/paper-6439eb3dd3429538.md)
- [Posterior replicas and conditional information in Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Posterior-replicas-and-conditional-information-in-Gaussian-regression-September-27-2026/paper.pdf) — [note](../../papers/paper-78317a39d1179b5d.md)
- [Localization costs and information growth for exact Gaussian observations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Localization-costs-and-information-growth-for-exact-Gaussian-observations-September-27-2026/paper.pdf) — [note](../../papers/paper-a5921432de007825.md)
- [Projection moments, positive cap domination, and Riesz estimates on the sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projection-moments-positive-cap-domination-and-Riesz-estimates-on-the-sphere-September-27-2026/paper.pdf) — [note](../../papers/paper-2999ebb39d71ea49.md)
- [Replacing Gaussian observations in memory-constrained inference](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Replacing-Gaussian-observations-in-memory-constrained-inference-September-27-2026/paper.pdf) — [note](../../papers/paper-b4fd6b04daecaaec.md)
- [Subsphere methods for memory-sample lower bounds in noiseless Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subsphere-methods-for-memory-sample-lower-bounds-in-noiseless-Gaussian-regression-September-27-2026/paper.pdf) — [note](../../papers/paper-c2d31b0748a514bc.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
