# 156 · Borsuk's conjecture fails in dimension nine

**Subject:** Combinatorics

## The question, intuitively

Can every bounded set in nine dimensions be partitioned into ten sets of strictly smaller diameter?

## Papers in this family

- [A nine-dimensional counterexample to Borsuk's covering assertion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-nine-dimensional-counterexample-to-Borsuks-covering-assertion-September-23-2026/paper.pdf) — [note](../../papers/paper-81f27172430098ac.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
