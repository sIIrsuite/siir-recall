# 191 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

For every sufficiently large n, constructs n points in the unit square such that every triangle has area at least $n^{-2+c}$ for one absolute c > 0. This disproves the conjectured almost-n^{−2} upper bound in Heilbronn's triangle problem, which asks how large the smallest determined triangle can be. ([Lean](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/191.md))

## A power improvement in the Heilbronn triangle lower bound

There are absolute constants $\eta,c_1> 0$ such that, for every sufficiently large integer n, one can choose n points in the unit square so that every triangle they determine has area at least $c_1n^{-2+\eta}$. Thus the almost n^{−2} upper-bound formulation of Heilbronn's triangle problem is false. The exponent η is fixed but extremely small.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-improvement-in-the-Heilbronn-triangle-lower-bound-September-25-2026/main.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-improvement-in-the-Heilbronn-triangle-lower-bound-September-25-2026)

## Formalization pointer

[Lean documentation for this family](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/lean/docs/191.md). A family link does not certify every claim or every companion paper.
