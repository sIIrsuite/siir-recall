# 191 · A power improvement in the Heilbronn triangle lower bound

**Subject:** Combinatorics

## The question, intuitively

How can n points in a unit region be arranged so that their smallest triangle has as large an area as possible?

## Papers in this family

- [A power improvement in the Heilbronn triangle lower bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-improvement-in-the-Heilbronn-triangle-lower-bound-September-25-2026/main.pdf) — [note](../../papers/paper-0f76d582cea5b698.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
