# 200 · Mathematical source summaries

These are source claims from OpenAI’s catalogue, not an independent proof assessment or reconstructed full theorem formalism. Hypotheses in the manuscript PDF take precedence.

## Family claim in the catalogue

Proves the Eisenbud–Green–Harris and lex-plus-powers conjectures over every characteristic-zero field. Any homogeneous ideal containing a regular sequence, of arbitrary length and degrees at least two, admits a lex-plus-powers ideal with the same Hilbert function and no smaller graded Betti numbers.

## The Artinian Lex-Plus-Powers Betti Theorem

We prove the Eisenbud–Green–Harris and lex-plus-powers conjectures over every characteristic-zero field for homogeneous regular sequences of any positive length, with degrees at least two. For every homogeneous ideal containing such a sequence, the corresponding lex-plus-powers ideal has the same Hilbert function and at least as large a graded Betti number in every homological and internal degree.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Artinian-Lex-Plus-Powers-Betti-Theorem-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Artinian-Lex-Plus-Powers-Betti-Theorem-September-23-2026)

## Commuting Division-Coefficient Forms and the Artinian Eisenbud--Green--Harris Conjecture

We prove the Eisenbud–Green–Harris conjecture over every characteristic-zero field for homogeneous regular sequences of any positive length, with degrees at least two. Thus every homogeneous ideal containing such a sequence has the Hilbert function of a monomial ideal containing the corresponding pure powers.

[Manuscript PDF](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Commuting-Division-Coefficient-Forms-and-the-Artinian-Eisenbud-Green-Harris-Conjecture-September-23-2026/paper.pdf) · [Directory and citation instructions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Commuting-Division-Coefficient-Forms-and-the-Artinian-Eisenbud-Green-Harris-Conjecture-September-23-2026)
