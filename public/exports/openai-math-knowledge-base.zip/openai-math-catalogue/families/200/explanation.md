# 200 · Eisenbud–Green–Harris and lex-plus-powers

**Subject:** Algebra

## The question, intuitively

Can Hilbert functions of ideals containing regular sequences always be matched by specially ordered monomial ideals?

## Papers in this family

- [The Artinian Lex-Plus-Powers Betti Theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Artinian-Lex-Plus-Powers-Betti-Theorem-September-23-2026/paper.pdf) — [note](../../papers/paper-0752e6125087fff2.md)
- [Commuting Division-Coefficient Forms and the Artinian Eisenbud--Green--Harris Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Commuting-Division-Coefficient-Forms-and-the-Artinian-Eisenbud-Green-Harris-Conjecture-September-23-2026/paper.pdf) — [note](../../papers/paper-38092584f7c33b6a.md)

This short question explains the family’s common motivation; companion papers may handle distinct subcases or technical steps. Read the parallel mathematical pane for the exact source summaries.
