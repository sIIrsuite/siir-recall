# OpenAI maths catalogue for Sahil’s Knowledge Notebook

Start with [CATALOGUE.md](CATALOGUE.md). This is a content package for the existing notebook, with explanations and mathematical source summaries kept in separate panes.

- 719 manuscripts in the current source catalogue, across 372 families.
- Three withdrawn historical manuscripts retained separately: 722 manuscript records total.
- An original intuitive question for every family, reused by its related paper entries.
- Each paper’s own source abstract, PDF link, directory link, stable ID, and status.
- Official discipline grouping extracted from OpenAI’s overview.

## Files

| File or folder | Purpose |
|---|---|
| `CATALOGUE.md` | Complete browsable list with brief intuitive family descriptions and every manuscript |
| `catalogue.json` | Normalized family and manuscript records for search/filtering |
| `notebook-notes.json` | 372 note objects with parallel `explanationMarkdown` and `mathematicsMarkdown` fields |
| `families/<id>/explanation.md` | Plain-language family question and paper list |
| `families/<id>/mathematics.md` | Original source family claim and manuscript abstracts |
| `papers/*.md` | All 722 individual manuscript entries |
| `IMPORT.md` | Integration contract for the notebook’s coding agent |
| `sources/` | Source snapshot, revision history, and withdrawal notices |
| `ATTRIBUTION.md`, `LICENSE` | Source attribution and Apache license |

This package does not modify the live notebook. The JSON format is a documented intermediate content format; an adapter is needed if the notebook’s importer uses another schema. The mathematical pane contains catalogue summaries and abstracts, not newly derived full symbolic theorem statements. No manuscript PDFs or Lean projects are bundled.

## Provenance

Snapshot date: 12 October 2026. Source commit: `fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb`. Historical withdrawal entries use `adc7f1241b42e322a6451854ab7e4b4c146bf78a`.

OpenAI describes results at different stages of verification. “Listed in current catalogue” is a publication-status field, not a judgment that the result is correct. The family’s Lean documentation link is a pointer rather than a certification of every associated paper.

The intuitive questions are explanatory simplifications based on source catalogue text. Exact assumptions, regimes, and claim strength must be read in the original manuscript.
