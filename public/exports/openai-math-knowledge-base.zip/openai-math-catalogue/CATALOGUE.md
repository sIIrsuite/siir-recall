# OpenAI maths · Intuitive problem catalogue

Snapshot: 12 October 2026. **719 current manuscripts · 372 families · 3 withdrawn manuscripts**. The three withdrawn records are retained separately, giving the original 722-paper inventory.

Each family has an original plain-language question, followed by every associated paper. Closely related papers share the family description; each individual paper note retains its own source abstract. Source claims are attributed to OpenAI and have not been independently reviewed.

Use `families/<id>/explanation.md` and `mathematics.md` as parallel panes. `catalogue.json` stores the complete searchable inventory; `notebook-notes.json` supplies ready-made two-pane note objects.

## Number theory

### 001 · Milne’s rationality conjecture and algebraic specialization

When a complex algebraic shape is reduced modulo a prime, do its special geometric classes retain rational, compatible numerical measurements?

[Explanation pane](families/001/explanation.md) · [Mathematical source pane](families/001/mathematics.md)

- [Milne's rationality conjecture for abelian varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Milnes-rationality-conjecture-for-abelian-varieties-October-7-2026/paper.pdf) · [individual note](papers/paper-41244e5999885425.md)

### 002 · The full BSD formula from low Selmer corank

Can counting solutions modulo primes predict both the number of independent rational points on an elliptic curve and the exact arithmetic factors in that prediction?

[Explanation pane](families/002/explanation.md) · [Mathematical source pane](families/002/mathematics.md)

- [Exact Birch–Swinnerton-Dyer Formula from Low Selmer Corank](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Birch-Swinnerton-Dyer-Formula-from-Low-Selmer-Corank-October-7-2026/exact-bsd-low-selmer-corank.pdf) · [individual note](papers/paper-aee3a541adf87fc6.md)
- [The Selmer converse for elliptic curves at every prime](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Selmer-converse-for-elliptic-curves-at-every-prime-October-7-2026/main.pdf) · [individual note](papers/paper-c2730d2162c4ba85.md)
- [The two-primary Birch–Swinnerton-Dyer formula in Selmer corank at most one](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-two-primary-Birch-Swinnerton-Dyer-formula-in-Selmer-corank-at-most-one-October-6-2026/paper.pdf) · [individual note](papers/paper-ea57f249dfa58a57.md)

### 003 · The quasi-Riemann hypothesis

Can we guarantee that zeta and related functions have no zeros in a fixed strip near the right edge of their critical region?

[Explanation pane](families/003/explanation.md) · [Mathematical source pane](families/003/mathematics.md)

- [The Quasi-Riemann Hypothesis: A Zero-Free Half-Plane $\Re s> 7/8$](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-September-30-2026/paper.pdf) · [individual note](papers/paper-8210fff0730119ab.md)
- [The Quasi-Riemann Hypothesis (alternate 11/12 proof)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Quasi-Riemann-Hypothesis-October-5-2026/paper2.pdf) · [individual note](papers/paper-c75e76b6eca657a3.md)
- [Uniform exclusion of Landau–Siegel zeros](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-exclusion-of-Landau-Siegel-zeros-October-1-2026/paper.pdf) · [individual note](papers/paper-7bad5a85ecaf0460.md)

### 004 · Hilbert’s tenth problem over ℚ

Could a universal algorithm decide whether any polynomial equation has a solution made entirely of fractions?

[Explanation pane](families/004/explanation.md) · [Mathematical source pane](families/004/mathematics.md)

- [Hilbert’s tenth problem over the rational numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hilberts-tenth-problem-over-the-rational-numbers-October-6-2026/main.pdf) · [individual note](papers/paper-348091debfddac2f.md)
- [A pointwise 2-converse for elliptic curves with rational two-torsion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-pointwise-2-converse-for-elliptic-curves-with-rational-two-torsion-October-7-2026/paper.pdf) · [individual note](papers/paper-a41c29e7a091e9ca.md)

### 005 · Irrationality of Catalan’s constant

Can the alternating sum of reciprocal odd squares ever equal a ratio of two integers?

[Explanation pane](families/005/explanation.md) · [Mathematical source pane](families/005/mathematics.md)

- [Catalan's constant is irrational](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Catalans-constant-is-irrational-September-24-2026/paper.pdf) · [individual note](papers/paper-fdc68c5049b55490.md)

### 006 · Goldfeld’s conjecture: densities and mean analytic rank

If we twist an elliptic curve in all quadratic ways, how frequently does it have zero or one independent rational direction?

[Explanation pane](families/006/explanation.md) · [Mathematical source pane](families/006/mathematics.md)

- [Goldfeld's analytic density conjecture and the 2-converse for elliptic curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Goldfelds-analytic-density-conjecture-and-the-2-converse-for-elliptic-curves-October-7-2026/paper.pdf) · [individual note](papers/paper-4e07e64d4982e982.md)
- [The mean analytic rank of quadratic twists of elliptic curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-mean-analytic-rank-of-quadratic-twists-of-elliptic-curves-October-6-2026/paper.pdf) · [individual note](papers/paper-d16a695c835ad31d.md)

### 007 · Ordinary two-point correlations and the corrected Elliott conjecture

Do multiplicative arithmetic sequences lose correlation when sampled along two different linear patterns?

[Explanation pane](families/007/explanation.md) · [Mathematical source pane](families/007/mathematics.md)

- [Ordinary two-point correlations of multiplicative functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ordinary-two-point-correlations-of-multiplicative-functions-September-24-2026/final.pdf) · [individual note](papers/paper-f60e4abaa8fe9cb2.md)

### 008 · The Deligne–Drinfeld conjecture

Is a symmetry algebra underlying fundamental arithmetic constructions generated freely by one basic ingredient in each odd degree?

[Explanation pane](families/008/explanation.md) · [Mathematical source pane](families/008/mathematics.md)

- [The Deligne-Drinfeld conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Deligne-Drinfeld-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-f4b3bda1fd07a075.md)

### 009 · Function-field reconstruction from Milnor K-theory and Galois data

How much of a field can you reconstruct from information about multiplication and the symmetries of its algebraic extensions?

[Explanation pane](families/009/explanation.md) · [Mathematical source pane](families/009/mathematics.md)

- [Reconstruction of Function Fields from Mod-ℓ Milnor K-Theory](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Reconstruction-of-Function-Fields-from-Mod-ell-Milnor-K-Theory-October-5-2026/mod-ell-bogomolov-pop.pdf) · [individual note](papers/paper-45e07fd3de5cedac.md)
- [Reconstruction from Milnor K-theory modulo the characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Reconstruction-from-Milnor-K-theory-modulo-the-characteristic-October-5-2026/paper.pdf) · [individual note](papers/paper-accc0683da8d3452.md)
- [The Bogomolov-Pop reconstruction theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Bogomolov-Pop-reconstruction-theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-be169f950b63e3af.md)

### 010 · Unrestricted pro-modularity at the prime two

Do all suitably odd two-dimensional arithmetic representations at the prime two arise from modular-form machinery?

[Explanation pane](families/010/explanation.md) · [Mathematical source pane](families/010/mathematics.md)

- [Unrestricted pro-modularity at the prime two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unrestricted-pro-modularity-at-the-prime-two-October-6-2026/two-adic-promodularity.pdf) · [individual note](papers/paper-83ba9e49036ec83b.md)
- [The Dimension of the Two-Adic Hecke Algebra at Odd Level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Dimension-of-the-Two-Adic-Hecke-Algebra-at-Odd-Level-October-5-2026/two-adic-hecke.pdf) · [individual note](papers/paper-7a1e02a1fbc099c6.md)
- [Fontaine–Mazur modularity at the prime 2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fontaine-Mazur-modularity-at-the-prime-2-October-6-2026/paper.pdf) · [individual note](papers/paper-f63d29ba34ebbfd1.md)

### 011 · Prime-factor statistics of $p-1$

Choose a large prime and subtract one: how are the sizes of the resulting prime factors distributed?

[Explanation pane](families/011/explanation.md) · [Mathematical source pane](families/011/mathematics.md)

- [Weighted dilation graphs, smooth shifted primes and totient fibers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weighted-Dilation-Graphs-Smooth-Shifted-Primes-and-Totient-Fibers-September-24-2026/paper.pdf) · [individual note](papers/paper-4d25fbf130460dc0.md)
- [The Poisson-Dirichlet law for prime predecessors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Poisson-Dirichlet-Law-for-Prime-Predecessors-September-24-2026/paper.pdf) · [individual note](papers/paper-db1fcdc1a94ede93.md)
- [Prime Predecessors with an Even Number of Prime Factors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prime-Predecessors-with-an-Even-Number-of-Prime-Factors-September-17-2026/paper.pdf) · [individual note](papers/paper-c769fbe8f003c74e.md)

### 012 · Independent largest prime factors of consecutive integers

Are the largest prime factors of neighboring integers statistically independent in the long run?

[Explanation pane](families/012/explanation.md) · [Mathematical source pane](families/012/mathematics.md)

- [The joint Dickman law for consecutive integers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-joint-Dickman-law-for-consecutive-integers-September-24-2026/paper.pdf) · [individual note](papers/paper-7c9b89f9acaa639b.md)

### 013 · Ostmann’s inverse Goldbach conjecture

Can the prime numbers eventually be decomposed as the sum of two genuinely smaller infinite sets?

[Explanation pane](families/013/explanation.md) · [Mathematical source pane](families/013/mathematics.md)

- [The additive indecomposability of the primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/the-additive-indecomposability-of-the-primes-September-24-2026/paper.pdf) · [individual note](papers/paper-43fb111777b443f4.md)

### 014 · Restricted geometric Langlands, global Arthur enhancements, and generic Ramanujan

Can arithmetic symmetry data and geometric objects be matched in the precise form predicted by the Langlands program?

[Explanation pane](families/014/explanation.md) · [Mathematical source pane](families/014/mathematics.md)

- [Global Arthur Enhancements of Cuspidal Excursion Parameters](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Arthur-Enhancements-of-Cuspidal-Excursion-Parameters-October-5-2026/manuscript.pdf) · [individual note](papers/paper-efdce37425d7a5b8.md)
- [Rationality of the Canonical Unramified Arthur Filtration](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rationality-of-the-Canonical-Unramified-Arthur-Filtration-September-24-2026/paper.pdf) · [individual note](papers/paper-6596fc2a5ebf81e7.md)
- [Ramanujan-Arthur Decompositions of Cuspidal Functions at Full Finite Level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ramanujan-Arthur-Decompositions-of-Cuspidal-Functions-at-Full-Finite-Level-September-24-2026/paper.pdf) · [individual note](papers/paper-af4997bb6c2ccb85.md)
- [Temperedness at ramified places for globally generic exceptional groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Temperedness-at-ramified-places-for-globally-generic-exceptional-groups-October-5-2026/ramified-ramanujan.pdf) · [individual note](papers/paper-47f182aeab1b86c6.md)
- [The Restricted Geometric Langlands Equivalence in Positive Characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Restricted-Geometric-Langlands-Equivalence-in-Positive-Characteristic-September-24-2026/paper.pdf) · [individual note](papers/paper-c0474794729685a4.md)
- [Constructible tame Hecke eigensheaves in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constructible-tame-Hecke-eigensheaves-in-positive-characteristic-October-5-2026/constructible-tame-hecke-eigensheaves-positive-characteristic.pdf) · [individual note](papers/paper-18aa6aa885b48d0d.md)
- [Tame Hecke Eigensheaves with Several Marked Points](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tame-Hecke-Eigensheaves-with-Several-Marked-Points-October-5-2026/Tame-Hecke-Eigensheaves-with-Several-Marked-Points.pdf) · [individual note](papers/paper-df7b9e1a28878eb2.md)
- [Frobenius Structures on Tame Hecke Eigensheaves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Frobenius-Structures-on-Tame-Hecke-Eigensheaves-October-5-2026/tame-hecke-frobenius.pdf) · [individual note](papers/paper-dbe60f3502ee282b.md)

### 015 · Torus-packet equidistribution in prime, quartic, and sextic degrees

As arithmetic objects become more complicated, do their associated torus orbits spread evenly through the surrounding space?

[Explanation pane](families/015/explanation.md) · [Mathematical source pane](families/015/mathematics.md)

- [Equidistribution of Prime-Degree Torus Packets with Arbitrary Local Type](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Prime-Degree-Torus-Packets-with-Arbitrary-Local-Type-September-24-2026/paper.pdf) · [individual note](papers/paper-56f4a0f27af6dc17.md)
- [Equidistribution of primitive quartic torus packets for arbitrary orders](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Primitive-Quartic-Torus-Packets-for-Arbitrary-Orders-October-5-2026/quartic-torus-packets.pdf) · [individual note](papers/paper-1106c030fb2a636d.md)
- [Equidistribution of Primitive Sextic Torus Packets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equidistribution-of-Primitive-Sextic-Torus-Packets-October-5-2026/primitive-sextic-torus-packets.pdf) · [individual note](papers/paper-d53d47dc14579ef0.md)

### 016 · Zilber–Pink in abelian varieties and the Siegel threefold

When an algebraic family meets unusually special subspaces, must those exceptional intersections follow a controlled pattern?

[Explanation pane](families/016/explanation.md) · [Mathematical source pane](families/016/mathematics.md)

- [The abelian Zilber–Pink conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Abelian-Zilber-Pink-Conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-5f6563d80875cb63.md)
- [The E×CM component of Zilber–Pink for curves in A2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-E-times-CM-Component-of-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) · [individual note](papers/paper-8c980448a55015ec.md)
- [Quaternionic division points on curves in the Siegel threefold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quaternionic-Division-Points-on-Curves-in-the-Siegel-Threefold-September-24-2026/paper.pdf) · [individual note](papers/paper-2ef48b291790dcd2.md)
- [Elliptic squares and Zilber–Pink for curves in A2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-Squares-and-Zilber-Pink-for-Curves-in-A2-September-24-2026/paper.pdf) · [individual note](papers/paper-b74213ff4d7cd242.md)

### 017 · The irrationality exponent of π is 2

How exceptionally well can fractions approximate pi, compared with the generic accuracy scale of denominator squared?

[Explanation pane](families/017/explanation.md) · [Mathematical source pane](families/017/mathematics.md)

- [The irrationality exponent of pi is 2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-irrationality-exponent-of-pi-is-2-September-24-2026/paper.pdf) · [individual note](papers/paper-c070260b781163b5.md)

### 018 · The Margulis–Platonov conjecture over global fields

Are normal subgroups of certain arithmetic matrix groups exactly the ones predicted by their local algebraic structure?

[Explanation pane](families/018/explanation.md) · [Mathematical source pane](families/018/mathematics.md)

- [The Margulis–Platonov conjecture over global function fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Margulis-Platonov-conjecture-over-global-function-fields-October-5-2026/margulis-platonov-global-function-fields.pdf) · [individual note](papers/paper-51f6a9c2d26f3489.md)
- [The Margulis–Platonov conjecture over number fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Margulis-Platonov-conjecture-over-number-fields-September-23-2026/paper.pdf) · [individual note](papers/paper-251b5946efe85365.md)

### 019 · The local p-adic section conjecture and global consequences

Can a compatible choice of points encoded in Galois-group data actually come from a geometric point?

[Explanation pane](families/019/explanation.md) · [Mathematical source pane](families/019/mathematics.md)

- [Étale covers with a prescribed exterior sheet](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Etale-covers-with-a-prescribed-exterior-sheet-September-24-2026/main.pdf) · [individual note](papers/paper-adc2655fabe9a960.md)
- [The p-adic section conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-p-adic-section-conjecture-October-6-2026/main.pdf) · [individual note](papers/paper-c39cb55bdb28163e.md)

### 020 · Squarefree quartics and power-free polynomial values

How often does a polynomial take values with no repeated prime factors, or no prime factor repeated too many times?

[Explanation pane](families/020/explanation.md) · [Mathematical source pane](families/020/mathematics.md)

- [Squarefree values of quartics and power-free values of polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Squarefree-values-of-quartics-and-power-free-values-of-polynomials-September-24-2026/manuscript.pdf) · [individual note](papers/paper-b048d707c8589e15.md)

### 021 · A quadratic bound for Jacobsthal’s function

How long can a run of consecutive integers avoid every number coprime to a fixed integer?

[Explanation pane](families/021/explanation.md) · [Mathematical source pane](families/021/mathematics.md)

- [A quadratic bound for Jacobsthal's function](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-quadratic-bound-for-Jacobsthals-function-September-25-2026/paper.pdf) · [individual note](papers/paper-b18cf026d826b615.md)

### 022 · The weak inhomogeneous Duffin–Schaeffer conjecture

When can infinitely many shifted rational approximations hit a real number at a prescribed accuracy?

[Explanation pane](families/022/explanation.md) · [Mathematical source pane](families/022/mathematics.md)

- [The Weak Inhomogeneous Duffin–Schaeffer Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-inhomogeneous-Duffin-Schaeffer-conjecture-September-25-2026/paper.pdf) · [individual note](papers/paper-0e911d75d561126a.md)

### 023 · Patterson's first moment for cubic Gauss sums

How much cancellation occurs when cubic exponential sums are averaged over arithmetic inputs?

[Explanation pane](families/023/explanation.md) · [Mathematical source pane](families/023/mathematics.md)

- [An unconditional first moment for cubic Gauss sums](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-unconditional-first-moment-for-cubic-Gauss-sums-September-25-2026/paper.pdf) · [individual note](papers/paper-73ec63fe954d377b.md)

### 024 · An asymptotic formula for the number of totients

How many distinct integers up to a given size occur as values of Euler's totient function?

[Explanation pane](families/024/explanation.md) · [Mathematical source pane](families/024/mathematics.md)

- [An asymptotic formula for the number of totients](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-asymptotic-formula-for-the-number-of-totients-September-25-2026/An-asymptotic-formula-for-the-number-of-totients-September-25-2026.pdf) · [individual note](papers/paper-1ad730bf23413812.md)

### 025 · Short Egyptian fractions

How efficiently can a fraction be written as a short sum of reciprocals of integers?

[Explanation pane](families/025/explanation.md) · [Mathematical source pane](families/025/mathematics.md)

- [Short Egyptian fractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Short-Egyptian-fractions-September-25-2026/Short-Egyptian-fractions-September-25-2026.pdf) · [individual note](papers/paper-784dcaafbf16bcd8.md)

### 026 · Positive lower density of large prime gaps

Do unusually large gaps between consecutive primes occur with a positive frequency at the relevant normalized scale?

[Explanation pane](families/026/explanation.md) · [Mathematical source pane](families/026/mathematics.md)

- [Positive lower density of large prime gaps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-lower-density-of-large-prime-gaps-September-25-2026/main.pdf) · [individual note](papers/paper-6c8b0cfe563af4c2.md)

### 027 · Potential integral density on curve character varieties

After enlarging the number field, can integral points become geometrically dense in spaces of representations of curve groups?

[Explanation pane](families/027/explanation.md) · [Mathematical source pane](families/027/mathematics.md)

- [Integral points on character varieties of curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-points-on-character-varieties-of-curves-September-25-2026/paper.pdf) · [individual note](papers/paper-746c4859bd0007c7.md)

### 028 · Uniformly bounded components of Gaussian-prime graphs

If Gaussian primes are connected whenever they lie nearby, can any connected cluster grow arbitrarily large at a fixed connection range?

[Explanation pane](families/028/explanation.md) · [Mathematical source pane](families/028/mathematics.md)

- [Bounded-Step Walks on Gaussian Primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-Step-Walks-on-Gaussian-Primes-September-26-2026/paper.pdf) · [individual note](papers/paper-d62b7c0bb57a39d9.md)

### 029 · Primitive roots for every admissible integer base

For a fixed admissible integer, are there enough primes for which its powers generate every nonzero residue?

[Explanation pane](families/029/explanation.md) · [Mathematical source pane](families/029/mathematics.md)

- [Primitive roots for every admissible integer base](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Primitive-roots-for-every-admissible-integer-base-October-4-2026/primitive-roots-all-integer-bases.pdf) · [individual note](papers/paper-76cde1fd28d1b97b.md)
- [Simultaneous primitive roots: a conditional lower bound for prime bases](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simultaneous-primitive-roots-a-conditional-lower-bound-for-prime-bases-October-4-2026/simultaneous-primitive-roots-conditional-lower-bound-prime-bases.pdf) · [individual note](papers/paper-b3df55700f873490.md)

### 030 · Modularity of elliptic curves over imaginary quadratic fields

Do elliptic curves over imaginary quadratic fields correspond to the predicted modular objects?

[Explanation pane](families/030/explanation.md) · [Mathematical source pane](families/030/mathematics.md)

- [Modularity of elliptic curves over imaginary quadratic fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Modularity-of-elliptic-curves-over-imaginary-quadratic-fields-October-4-2026/paper.pdf) · [individual note](papers/paper-d5bba57c7bc17855.md)

### 031 · Uchida’s conjecture for open homomorphisms of Galois groups

Does a sufficiently rich map between absolute Galois groups necessarily come from a map between the underlying fields?

[Explanation pane](families/031/explanation.md) · [Mathematical source pane](families/031/mathematics.md)

- [Open Homomorphisms of Global Solvably Closed Galois Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Open-Homomorphisms-of-Global-Solvably-Closed-Galois-Groups-October-5-2026/open-homomorphisms-solvably-closed-galois-groups.pdf) · [individual note](papers/paper-384881aa9dbf1324.md)

## Algebraic and complex geometry

### 032 · The rational Hodge conjecture for CM abelian varieties

For abelian varieties with complex multiplication, do the rational cohomological classes singled out by Hodge theory come from actual algebraic subvarieties?

[Explanation pane](families/032/explanation.md) · [Mathematical source pane](families/032/mathematics.md)

- [The rational Hodge conjecture for CM abelian varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-October-6-2026/paper.pdf) · [individual note](papers/paper-d5946623a117b69b.md)
- [Algebraic Kuga–Satake correspondences and Hodge conjectures on a K3 quadratic locus](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Algebraic-Kuga-Satake-correspondences-and-Hodge-conjectures-on-a-K3-quadratic-locus-September-30-2026/paper.pdf) · [individual note](papers/paper-edce813b623423a0.md)
- [Weil classes and Hodge classes on abelian powers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weil-classes-and-Hodge-classes-on-abelian-powers-October-6-2026/paper.pdf) · [individual note](papers/paper-fd7a8ca65c7df300.md)
- [Abelian covers, Gale correspondences, and the Hodge conjecture for powers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abelian-covers-Gale-correspondences-and-the-Hodge-conjecture-for-powers-October-6-2026/paper.pdf) · [individual note](papers/paper-58a4e5f68e87d4ff.md)
- [A Conditional Reduction for Algebraic Kuga–Satake Correspondences](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Conditional-Reduction-for-Algebraic-Kuga-Satake-Correspondences-September-10-2026/paper.pdf) · [individual note](papers/paper-b16ed7ffedd101a3.md)

### 033 · Iitaka subadditivity, variation, and logarithmic additivity

How does the algebraic complexity of a fibered space relate to the complexities of its base and fibers?

[Explanation pane](families/033/explanation.md) · [Mathematical source pane](families/033/mathematics.md)

- [Orbifold and logarithmic Iitaka subadditivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Orbifold-and-logarithmic-Iitaka-subadditivity-September-26-2026/paper.pdf) · [individual note](papers/paper-052fa626f6fd10a3.md)
- [Logarithmic Kodaira dimension and whole-fiber variation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Logarithmic-Kodaira-dimension-and-whole-fiber-variation-September-26-2026/paper.pdf) · [individual note](papers/paper-b2fd732655b98e18.md)
- [The reverse logarithmic Kodaira inequality and additivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-reverse-logarithmic-Kodaira-inequality-and-additivity-September-26-2026/paper.pdf) · [individual note](papers/paper-717502ed32f5ea8d.md)
- [Projective Hodge lines and ordinary Iitaka subadditivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projective-Hodge-lines-and-ordinary-Iitaka-subadditivity-September-27-2026/paper.pdf) · [individual note](papers/paper-1f26bb3a15dfa51e.md)
- [B-semiampleness for compact log-smooth Kähler fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/B-semiampleness-for-compact-log-smooth-Kahler-fibrations-September-10-2026/paper.pdf) · [individual note](papers/paper-189cb97d8d8cf611.md)

### 034 · Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity

Does weak positivity of a canonical divisor eventually produce enough global sections to define a geometric map?

[Explanation pane](families/034/explanation.md) · [Mathematical source pane](families/034/mathematics.md)

- [Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-for-compact-Kahler-spaces-under-logarithmic-Iitaka-subadditivity-October-6-2026/main.pdf) · [individual note](papers/paper-424f5ed2215b4c5f.md)
- [Uniform indices for semi-log-canonical log Calabi–Yau pairs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-indices-for-semi-log-canonical-log-Calabi-Yau-pairs-October-5-2026/uniform-slc-index.pdf) · [individual note](papers/paper-ff457278f57b8298.md)
- [Conditional good minimal models for compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-good-minimal-models-for-compact-Kahler-fourfolds-October-6-2026/paper.pdf) · [individual note](papers/paper-a6bd97ad81186b68.md)
- [Log abundance in characteristic zero](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-characteristic-zero-September-24-2026/paper.pdf) · [individual note](papers/paper-b377a2b00e07188b.md)
- [Minimal metrics and interior injectivity for nef adjoints](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-metrics-and-interior-injectivity-for-nef-adjoints-September-27-2026/paper.pdf) · [individual note](papers/paper-a5e49d36c53310fb.md)
- [Fourfold nonvanishing by minimal metrics and moving jets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fourfold-nonvanishing-by-minimal-metrics-and-moving-jets-September-27-2026/paper.pdf) · [individual note](papers/paper-097f3c56951bbe0a.md)
- [Lifting sections from the reduced support of an adjoint](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lifting-sections-from-the-reduced-support-of-an-adjoint-September-27-2026/paper.pdf) · [individual note](papers/paper-b601dd5aa1919960.md)
- [Schnell fiber spaces and good canonical models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Schnell-fiber-spaces-and-good-canonical-models-September-24-2026/paper.pdf) · [individual note](papers/paper-bd37d68fad2d217f.md)
- [Uniform log Iitaka fibrations and bounded moduli denominators](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-log-Iitaka-fibrations-and-bounded-moduli-denominators-October-4-2026/uniform-log-iitaka.pdf) · [individual note](papers/paper-9cb2f769aff9f869.md)
- [Uniform Pluricanonical Iitaka Fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Pluricanonical-Iitaka-Fibrations-October-3-2026/paper.pdf) · [individual note](papers/paper-c76d8f4c06f30c9e.md)
- [Relative denominators and effective systems for log Calabi-Yau fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-denominators-and-effective-systems-for-log-Calabi-Yau-fibrations-September-27-2026/paper.pdf) · [individual note](papers/paper-c1ff3749eb0809bf.md)
- [Arithmetic Stein-degree bounds for log Calabi–Yau pairs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-Stein-degree-bounds-for-log-Calabi-Yau-pairs-September-25-2026/paper.pdf) · [individual note](papers/paper-695ce8117c76962b.md)
- [Uniform effective log Iitaka fibrations for fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-effective-log-Iitaka-fibrations-for-fourfolds-September-26-2026/paper.pdf) · [individual note](papers/paper-7e78ca645286362c.md)
- [Abundance after nonvanishing for compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-after-nonvanishing-for-compact-Kahler-fourfolds-September-27-2026/paper.pdf) · [individual note](papers/paper-632b092179f58b6d.md)

### 035 · Log-canonical threefold abundance in numerical dimension one

For a mildly singular three-dimensional space whose canonical divisor has one effective numerical direction, does that direction come from a global map?

[Explanation pane](families/035/explanation.md) · [Mathematical source pane](families/035/mathematics.md)

- [Log abundance in numerical dimension one for threefolds in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Log-abundance-in-numerical-dimension-one-for-threefolds-in-positive-characteristic-October-5-2026/paper.pdf) · [individual note](papers/paper-ea927814ebabc3d2.md)
- [Abundance in numerical dimension one for terminal threefolds in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Abundance-in-numerical-dimension-one-for-terminal-threefolds-in-positive-characteristic-September-24-2026/paper.pdf) · [individual note](papers/paper-ad7a849f20c5e87a.md)

### 036 · Numerical semiampleness and generalized minimal models

Can numerical positivity be promoted to a divisor generated by sections, enabling a minimal geometric model?

[Explanation pane](families/036/explanation.md) · [Mathematical source pane](families/036/mathematics.md)

- [Numerical semiampleness of nef adjoint classes on compact Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-semiampleness-of-nef-adjoint-classes-on-compact-Kahler-manifolds-October-6-2026/numerical-generalized-abundance.pdf) · [individual note](papers/paper-d41f9804e8ab4c9f.md)
- [Numerical Semiampleness of Nef Adjoint Divisors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Numerical-Semiampleness-of-Nef-Adjoint-Divisors-October-3-2026/paper.pdf) · [individual note](papers/paper-87816fa04c98b838.md)
- [Minimal models and Mori fibre spaces for generalized log canonical Q-pairs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-and-Mori-fibre-spaces-for-generalized-log-canonical-Q-pairs-September-24-2026/paper.pdf) · [individual note](papers/paper-c2ec482185c7f8b6.md)
- [Minimal models in numerical dimension one](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Minimal-models-in-numerical-dimension-one-September-24-2026/paper.pdf) · [individual note](papers/paper-2b06c4ac177472f7.md)

### 037 · The ordinary-double-point volume gap

Is the simplest quadratic singularity separated from all other singularities by a sharp volume gap?

[Explanation pane](families/037/explanation.md) · [Mathematical source pane](families/037/mathematics.md)

- [The ordinary-double-point gap in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-ordinary-double-point-gap-in-every-dimension-September-24-2026/paper.pdf) · [individual note](papers/paper-a37e1240d4559d92.md)
- [The normalized-volume gap in dimension four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-normalized-volume-gap-in-dimension-four-September-24-2026/paper.pdf) · [individual note](papers/paper-6d0756f02d665ccc.md)

### 038 · Fujita’s freeness conjecture

How much positivity must be added to a canonical divisor before its sections have no common zero?

[Explanation pane](families/038/explanation.md) · [Mathematical source pane](families/038/mathematics.md)

- [Fujita's freeness conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fujitas-freeness-conjecture-September-23-2026/Fujitas-freeness-conjecture-September-23-2026.pdf) · [individual note](papers/paper-2cc2bedc293afb0a.md)

### 039 · Nagata’s conjecture and maximal Seshadri constants

How large must the degree of a plane curve be if it passes through many general points with prescribed multiplicities?

[Explanation pane](families/039/explanation.md) · [Mathematical source pane](families/039/mathematics.md)

- [Nagata's conjecture for plane curves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nagatas-Conjecture-for-Plane-Curves-September-23-2026/main.pdf) · [individual note](papers/paper-1ccf84aff034290f.md)
- [Maximal Seshadri constants on arbitrary polarized surfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Seshadri-Constants-on-Arbitrary-Polarized-Surfaces-September-23-2026/main.pdf) · [individual note](papers/paper-d7ef9ee23794ed34.md)
- [Maximal Multipoint Seshadri Constants in Higher Dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-Multipoint-Seshadri-Constants-in-Higher-Dimensions-October-5-2026/main.pdf) · [individual note](papers/paper-94c4fa3857313b44.md)
- [Maximal multipoint Seshadri constants in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Maximal-multipoint-Seshadri-constants-in-positive-characteristic-October-5-2026/seshadri-positive-characteristic.pdf) · [individual note](papers/paper-f38457a50f77de9f.md)

### 040 · Bloch’s conjecture for complex surfaces

Can a complex surface with little holomorphic two-form information also have the predicted simple algebraic zero-cycle structure?

[Explanation pane](families/040/explanation.md) · [Mathematical source pane](families/040/mathematics.md)

- [Bloch’s conjecture for surfaces with p_g=0](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Blochs-Conjecture-for-Surfaces-with-pg-equals-q-equals-0-September-24-2026/paper.pdf) · [individual note](papers/paper-1ab9b4fafafc4c96.md)

### 041 · Hyperkähler SYZ and projective-space bases

Must certain special higher-dimensional geometric spaces fiber into tori, and what can their bases look like?

[Explanation pane](families/041/explanation.md) · [Mathematical source pane](families/041/mathematics.md)

- [Projective-space bases of Lagrangian fibrations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projective-Space-Bases-of-Lagrangian-Fibrations-September-23-2026/main.pdf) · [individual note](papers/paper-932a41dd33fe316e.md)
- [The strong hyperkähler SYZ conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Strong-Hyperkahler-SYZ-Conjecture-September-23-2026/main.pdf) · [individual note](papers/paper-69159e76a9b2cf00.md)

### 042 · Oka classification for minimal compact complex surfaces: Kodaira dimension zero and class VII

Which compact complex surfaces allow flexible holomorphic maps in the sense of Oka theory?

[Explanation pane](families/042/explanation.md) · [Mathematical source pane](families/042/mathematics.md)

- [Every complex K3 surface is Oka](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-complex-K3-surface-is-Oka-September-23-2026/paper.pdf) · [individual note](papers/paper-c482e720561f2932.md)

### 043 · P = W for fixed-determinant SL_{n} moduli spaces

Do two filtrations arising from geometric fibrations and mixed Hodge theory encode exactly the same information?

[Explanation pane](families/043/explanation.md) · [Mathematical source pane](families/043/mathematics.md)

- [P=W in composite rank for fixed determinant](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/P-equals-W-in-composite-rank-for-fixed-determinant-September-24-2026/P-equals-W-in-composite-rank-for-fixed-determinant-September-24-2026.pdf) · [individual note](papers/paper-1cf374a79985cce5.md)

### 044 · The equivariant cohomological Hikita conjecture

Does the topology of one symplectic space match the fixed-point geometry of its proposed dual?

[Explanation pane](families/044/explanation.md) · [Mathematical source pane](families/044/mathematics.md)

- [The equivariant cohomological Hikita conjecture for arbitrary quivers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-equivariant-cohomological-Hikita-conjecture-for-arbitrary-quivers-September-24-2026/main.pdf) · [individual note](papers/paper-959d4b7bbafd0cc7.md)

### 046 · Shafarevich counterexamples in dimension two and with large fundamental group

Can a compact complex surface violate the predicted convexity behavior of its universal cover?

[Explanation pane](families/046/explanation.md) · [Mathematical source pane](families/046/mathematics.md)

- [A projective fourfold with large fundamental group and non-Stein universal cover](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-projective-fourfold-with-large-fundamental-group-and-non-Stein-universal-cover-October-5-2026/large-fundamental-group-non-stein.pdf) · [individual note](papers/paper-795e69702de05958.md)
- [A surface counterexample to Shafarevich holomorphic convexity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-surface-counterexample-to-Shafarevich-holomorphic-convexity-September-23-2026/paper.pdf) · [individual note](papers/paper-3f564d3c7259bd48.md)

### 047 · Zariski cancellation and affine fibrations over the complex numbers

If adding one affine coordinate makes two algebraic spaces isomorphic, were the original spaces already isomorphic?

[Explanation pane](families/047/explanation.md) · [Mathematical source pane](families/047/mathematics.md)

- [An explicit failure of complex affine-space cancellation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-failure-of-complex-affine-space-cancellation-September-23-2026/paper.pdf) · [individual note](papers/paper-c01f49713c2f01d3.md)

### 048 · A characteristic-zero counterexample to Lipman–Zariski

If tangent directions behave like a free module, must an algebraic space be nonsingular?

[Explanation pane](families/048/explanation.md) · [Mathematical source pane](families/048/mathematics.md)

- [A singular normal affine surface with free tangent sheaf](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-singular-normal-affine-surface-with-free-tangent-sheaf-September-23-2026/paper.pdf) · [individual note](papers/paper-6343e7b14aa1020f.md)

### 049 · A stable-coordinate counterexample in four variables

If a polynomial becomes a coordinate after adding variables, must it already have been a coordinate before stabilization?

[Explanation pane](families/049/explanation.md) · [Mathematical source pane](families/049/mathematics.md)

- [A stable coordinate that is not a coordinate in four variables](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-stable-coordinate-that-is-not-a-coordinate-in-four-variables-October-5-2026/stable-coordinate-four-variables.pdf) · [individual note](papers/paper-3dbb3c9dc50ee15e.md)
- [An explicit noncoordinate polynomial with affine three-space zero fibre](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-noncoordinate-polynomial-with-affine-three-space-zero-fibre-September-24-2026/paper.pdf) · [individual note](papers/paper-0f04a0bdb4d7bf8b.md)

### 050 · A counterexample to Griffiths’ positivity conjecture

Must every ample vector bundle admit a Hermitian metric with the stronger curvature positivity Griffiths predicted?

[Explanation pane](families/050/explanation.md) · [Mathematical source pane](families/050/mathematics.md)

- [Ample rank-two bundles on the quadric surface without Griffiths-positive metrics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/ample-rank-two-bundles-on-the-quadric-surface-without-griffiths-positive-metrics-September-24-2026/paper.pdf) · [individual note](papers/paper-480e66aa8b91e7aa.md)

### 051 · Kobayashi’s canonical-ampleness conjecture

Does a projective space with no entire complex curves have a positive canonical bundle?

[Explanation pane](families/051/explanation.md) · [Mathematical source pane](families/051/mathematics.md)

- [Canonical ampleness of compact hyperbolic Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Canonical-ampleness-of-compact-hyperbolic-Kahler-manifolds-September-23-2026/canonical-ampleness.pdf) · [individual note](papers/paper-26bad5fbc8b3e71d.md)

### 052 · Tangent splittings and product decompositions

If the tangent bundle splits, must the geometric space itself split as a product after passing to a suitable cover?

[Explanation pane](families/052/explanation.md) · [Mathematical source pane](families/052/mathematics.md)

- [Universal-cover splitting for compact Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-cover-splitting-for-compact-Kahler-manifolds-September-23-2026/paper.pdf) · [individual note](papers/paper-8f2e32e697966189.md)
- [Integrability of split tangent bundles on rationally connected manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integrability-of-split-tangent-bundles-on-rationally-connected-manifolds-September-23-2026/main.pdf) · [individual note](papers/paper-d9b0c2c323f8dc37.md)

### 053 · A counterexample to Pixton completeness in Chow

Do the known tautological relations account for all relations among algebraic cycles on moduli spaces of curves?

[Explanation pane](families/053/explanation.md) · [Mathematical source pane](families/053/mathematics.md)

- [A high-arity counterexample to Pixton completeness in Chow](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-high-arity-counterexample-to-Pixton-completeness-in-Chow-September-24-2026/paper.pdf) · [individual note](papers/paper-8aec1fdb175ede4b.md)

### 054 · Irrational cubic fourfolds with Hodge-theoretic and categorical K3 associations

Can a cubic fourfold remain nonrational even when several K3-type structures make it resemble expected rational examples?

[Explanation pane](families/054/explanation.md) · [Mathematical source pane](families/054/mathematics.md)

- [Irrational cubic fourfolds with geometric K3 categories](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026/Irrational-cubic-fourfolds-with-geometric-K3-categories-September-24-2026.pdf) · [individual note](papers/paper-64185cbf8d42f952.md)

### 055 · Gepner symmetry and large-volume stability on threefolds

Can one build stability conditions compatible both with categorical symmetries and with large-volume geometry?

[Explanation pane](families/055/explanation.md) · [Mathematical source pane](families/055/mathematics.md)

- [A Gepner stability condition on every smooth quintic threefold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Gepner-stability-condition-on-every-smooth-quintic-threefold-September-24-2026/paper.pdf) · [individual note](papers/paper-f723d2df8a642c2a.md)
- [Prescribed large-volume charges on threefolds with trivial canonical bundle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prescribed-large-volume-charges-on-threefolds-with-trivial-canonical-bundle-September-24-2026/paper.pdf) · [individual note](papers/paper-5db9fa091b5b53e7.md)

### 056 · Termination of projective and Kähler fourfold minimal model programs

Can repeated canonical simplification steps in a four-dimensional geometric space continue forever?

[Explanation pane](families/056/explanation.md) · [Mathematical source pane](families/056/mathematics.md)

- [Termination of generalized log canonical flips on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-of-generalized-log-canonical-flips-on-compact-Kahler-fourfolds-October-7-2026/termination-generalized-lc-kahler-fourfolds.pdf) · [individual note](papers/paper-4f3458b40983a327.md)
- [Termination of generalized-canonical flips on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-of-generalized-canonical-flips-on-compact-Kahler-fourfolds-October-6-2026/termination-generalized-terminal-flips-compact-kahler-fourfolds.pdf) · [individual note](papers/paper-ce38a1375ede8564.md)
- [Termination for projective log canonical fourfolds with rational boundary](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Termination-for-projective-log-canonical-fourfolds-with-rational-boundary-September-24-2026/paper.pdf) · [individual note](papers/paper-07726b1ad079bcd5.md)
- [Finite ordinary minimal model programs on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-ordinary-minimal-model-programs-on-compact-Kahler-fourfolds-October-6-2026/paper.pdf) · [individual note](papers/paper-d03c3408afe701c9.md)
- [Finite ordinary minimal model programs on compact Kähler fourfolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-ordinary-minimal-model-programs-on-compact-Kahler-fourfolds-September-24-2026/paper.pdf) · [individual note](papers/paper-9cd0efd421231a3b.md)

### 057 · Fundamental groups of special complex varieties and root orbifolds

How complicated can the fundamental group of a geometrically special variety be?

[Explanation pane](families/057/explanation.md) · [Mathematical source pane](families/057/mathematics.md)

- [The abelianity conjecture for special compact Kähler manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-abelianity-conjecture-for-special-compact-Kahler-manifolds-September-23-2026/paper.pdf) · [individual note](papers/paper-3ce919f2014b379a.md)
- [Two-step monodromy of special quasi-projective varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Two-step-monodromy-of-special-quasi-projective-varieties-September-24-2026/paper.pdf) · [individual note](papers/paper-54c9163d4201b591.md)
- [A conditional abelianity theorem for special fourfold pairs with a half-weight divisor](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-conditional-abelianity-theorem-for-special-fourfold-pairs-with-a-half-weight-divisor-October-5-2026/main.pdf) · [individual note](papers/paper-08b187a03c0ef778.md)

### 058 · Semialgebraic universal covers and bounded domains

If a universal cover has a description by finitely many real polynomial inequalities, how rigid must its complex geometry be?

[Explanation pane](families/058/explanation.md) · [Mathematical source pane](families/058/mathematics.md)

- [Semialgebraic universal covers of normal projective varieties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Semialgebraic-universal-covers-of-normal-projective-varieties-September-24-2026/paper.pdf) · [individual note](papers/paper-c3639a0ea6ca2516.md)
- [Symmetry of semialgebraic bounded domains with compact quotient](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symmetry-of-semialgebraic-bounded-domains-with-compact-quotient-September-24-2026/paper.pdf) · [individual note](papers/paper-797062f12750f925.md)

### 059 · Counterexamples to Zariski’s multiplicity conjecture

Can two topologically equivalent complex singularities have different algebraic multiplicities?

[Explanation pane](families/059/explanation.md) · [Mathematical source pane](families/059/mathematics.md)

- [Ambiently homeomorphic isolated hypersurfaces of multiplicities two and three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurfaces-of-multiplicities-two-and-three-September-24-2026/paper.pdf) · [individual note](papers/paper-b37600a212e7ade9.md)
- [Ambiently homeomorphic isolated hypersurface germs in ℂ⁴ with multiplicities four and five](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ambiently-homeomorphic-isolated-hypersurface-germs-in-C4-with-multiplicities-four-and-five-September-27-2026/paper.pdf) · [individual note](papers/paper-023c99253d0c28f5.md)

### 060 · The Global Spherical Shell conjecture

Do the relevant compact complex surfaces always contain a large spherical shell accounting for their global structure?

[Explanation pane](families/060/explanation.md) · [Mathematical source pane](families/060/mathematics.md)

- [Global Spherical Shells on Minimal Surfaces of Class VII](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Spherical-Shells-on-Minimal-Surfaces-of-Class-VII-September-24-2026/paper.pdf) · [individual note](papers/paper-7c19d149c9f238c3.md)

### 062 · Projective contact classification and the LeBrun–Salamon conjecture

Are positive quaternionic-Kähler spaces and their complex contact partners all of the predicted homogeneous types?

[Explanation pane](families/062/explanation.md) · [Mathematical source pane](families/062/mathematics.md)

- [Contact Fano manifolds and the LeBrun–Salamon conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Contact-Fano-manifolds-and-the-LeBrun-Salamon-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-fa36a2613dcfba18.md)

### 063 · The generalized Mukai conjecture

How strongly does positive anticanonical curvature restrict a variety's dimension, Picard rank, and minimal rational-curve degree?

[Explanation pane](families/063/explanation.md) · [Mathematical source pane](families/063/mathematics.md)

- [The generalized Mukai conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Generalized-Mukai-Conjecture-September-24-2026/article.pdf) · [individual note](papers/paper-aef37bb679fb562b.md)

### 064 · Topological triviality of μ-constant surface singularities

If a family of surface singularities keeps its Milnor number fixed, must its local topology remain unchanged?

[Explanation pane](families/064/explanation.md) · [Mathematical source pane](families/064/mathematics.md)

- [Topological triviality of mu-constant families of surface singularities](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Topological-triviality-of-mu-constant-families-of-surface-singularities-September-24-2026/main.pdf) · [individual note](papers/paper-fbba4579fd09c2ed.md)

### 065 · Virasoro constraints for complete intersections and projective-bundle towers

Do curve-counting generating functions obey the infinite system of symmetry equations called Virasoro constraints?

[Explanation pane](families/065/explanation.md) · [Mathematical source pane](families/065/mathematics.md)

- [Virasoro Constraints under Projectivization](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-under-Projectivization-October-5-2026/virasoro-constraints-under-projectivization.pdf) · [individual note](papers/paper-36f5c2bcb9ef4a4d.md)
- [Virasoro Constraints for Projective Complete Intersections](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virasoro-Constraints-for-Projective-Complete-Intersections-September-24-2026/article.pdf) · [individual note](papers/paper-eb2b1271759b1c52.md)

### 066 · Bounded klt complements for Fano contractions

Can singular Fano-type geometry be controlled by complements of uniformly bounded complexity?

[Explanation pane](families/066/explanation.md) · [Mathematical source pane](families/066/mathematics.md)

- [Bounded klt complements for Fano contractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-klt-complements-for-Fano-contractions-September-25-2026/Bounded-klt-complements-for-Fano-contractions-September-25-2026.pdf) · [individual note](papers/paper-47d9a104e6236787.md)
- [Uniform Cartier sections for Fano type contractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Cartier-sections-for-Fano-type-contractions-September-25-2026/Uniform-Cartier-sections-for-Fano-type-contractions-September-25-2026.pdf) · [individual note](papers/paper-9966e5bd525585d5.md)

### 067 · The Campana–Peternell conjecture in dimension six

If a Fano manifold's tangent bundle is numerically positive, must it be homogeneous in the stated six-dimensional case?

[Explanation pane](families/067/explanation.md) · [Mathematical source pane](families/067/mathematics.md)

- [The Campana–Peternell conjecture in dimension six](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Campana-Peternell-conjecture-in-dimension-six-September-25-2026/main.pdf) · [individual note](papers/paper-a9206135c76f2805.md)

### 068 · Anticanonical nonvanishing in every dimension

Must the negative of the canonical divisor on a Fano variety always possess a nonzero global section?

[Explanation pane](families/068/explanation.md) · [Mathematical source pane](families/068/mathematics.md)

- [Anticanonical nonvanishing from smooth semipositivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Anticanonical-nonvanishing-from-smooth-semipositivity-September-26-2026/main.pdf) · [individual note](papers/paper-83b37855a387851f.md)
- [Invariant anticanonical indices and conversion of twisted differentials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Invariant-anticanonical-indices-and-conversion-of-twisted-differentials-September-26-2026/main.pdf) · [individual note](papers/paper-1177aafffd65980d.md)
- [Bounded anticanonical metrics on klt pairs and torus quotients](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-anticanonical-metrics-on-klt-pairs-and-torus-quotients-September-26-2026/main.pdf) · [individual note](papers/paper-0eb94c49d54818b7.md)
- [Cohomological transfer and equivariant anticanonical sections](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cohomological-transfer-and-equivariant-anticanonical-sections-September-26-2026/main.pdf) · [individual note](papers/paper-4a0cfce76bf7ad30.md)
- [Metric descent and rank-preserving contractions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-descent-and-rank-preserving-contractions-September-26-2026/main.pdf) · [individual note](papers/paper-95d893aa2d2f82c8.md)
- [Integrable metrics and effectivity with controlled boundary](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integrable-metrics-and-effectivity-with-controlled-boundary-September-26-2026/main.pdf) · [individual note](papers/paper-b96648a46d9f61fb.md)
- [Exact orders and invariant anticanonical linear systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-orders-and-invariant-anticanonical-linear-systems-September-26-2026/main.pdf) · [individual note](papers/paper-56fbb334c96554b3.md)

### 069 · Global quantum geometric Langlands at irrational level

Can quantum-deformed geometric representation data be paired across the Langlands correspondence at irrational coupling?

[Explanation pane](families/069/explanation.md) · [Mathematical source pane](families/069/mathematics.md)

- [Global quantum geometric Langlands at irrational level](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-quantum-geometric-Langlands-at-irrational-level-October-4-2026/quantum-langlands.pdf) · [individual note](papers/paper-7c40db5babc2000f.md)

## Real and complex analysis

### 071 · Koebe’s circle-domain conjecture

Can every planar domain be conformally reshaped so that each boundary component is a circle or a point?

[Explanation pane](families/071/explanation.md) · [Mathematical source pane](families/071/mathematics.md)

- [Removable Boundaries and Rigidity of Circle Domains](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Removable-Boundaries-and-Rigidity-of-Circle-Domains-September-23-2026/paper.pdf) · [individual note](papers/paper-eae0bfcc638e4874.md)
- [Koebe's Circle-Domain Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Koebes-Circle-Domain-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-635c35e8df0005bf.md)

### 072 · Brennan's conjecture and the integral-means spectrum

How concentrated can the derivative of a conformal map become near the boundary, while still remaining integrable?

[Explanation pane](families/072/explanation.md) · [Mathematical source pane](families/072/mathematics.md)

- [Brennan's conjecture and sharp inverse-square integral means](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brennans-conjecture-and-sharp-inverse-square-integral-means-September-24-2026/paper.pdf) · [individual note](papers/paper-ca3c127f5aba8ab3.md)
- [A strict inverse-first-power bound for univalent functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-inverse-first-power-bound-for-univalent-functions-September-24-2026/paper.pdf) · [individual note](papers/paper-8e29cc8f4983e207.md)

### 073 · The Falconer distance conjecture

How large must a fractal set be before its pairwise distances occupy positive length on the real line?

[Explanation pane](families/073/explanation.md) · [Mathematical source pane](families/073/mathematics.md)

- [The Falconer distance conjecture in all dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Falconer-distance-conjecture-in-all-dimensions-September-23-2026/paper.pdf) · [individual note](papers/paper-c4b20b597d07480d.md)

### 074 · Kakeya in three and four dimensions

How small can a set be if it contains a unit line segment pointing in every possible direction?

[Explanation pane](families/074/explanation.md) · [Mathematical source pane](families/074/mathematics.md)

- [The Kakeya maximal conjecture in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kakeya-maximal-conjecture-in-three-dimensions-September-23-2026/paper.pdf) · [individual note](papers/paper-3855f97cbf560e53.md)
- [Every four-dimensional Kakeya set has full Hausdorff dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Every-four-dimensional-Kakeya-set-has-full-Hausdorff-dimension-September-24-2026/paper.pdf) · [individual note](papers/paper-aeaee36af8d9a258.md)

### 075 · The $L\log L$ Fourier-convergence conjecture

How little integrability is enough to ensure that the Fourier series of a function converges almost everywhere?

[Explanation pane](families/075/explanation.md) · [Mathematical source pane](families/075/mathematics.md)

- [Almost-everywhere Fourier convergence in L log L](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Almost-everywhere-Fourier-convergence-in-L-log-L-September-23-2026/paper.pdf) · [individual note](papers/paper-996ced01dd679b88.md)

### 076 · Real ultraflat Littlewood polynomials and unbounded binary merit factors

Can a polynomial with only plus/minus-one coefficients have almost constant magnitude around the unit circle?

[Explanation pane](families/076/explanation.md) · [Mathematical source pane](families/076/mathematics.md)

- [Ultraflat real Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ultraflat-real-Littlewood-polynomials-October-5-2026/ultraflat-real-littlewood-polynomials.pdf) · [individual note](papers/paper-76a894adace3c264.md)
- [Nearly minimal maxima and positive minima of Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nearly-minimal-maxima-and-positive-minima-of-Littlewood-polynomials-October-5-2026/littlewood-lower-envelope.pdf) · [individual note](papers/paper-a32daef83e1a1ea8.md)
- [Asymptotically minimal maxima of real Littlewood polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Asymptotically-minimal-maxima-of-real-Littlewood-polynomials-September-23-2026/paper.pdf) · [individual note](papers/paper-d1f8195df6797ddf.md)

### 077 · Fourier restriction for positively curved surfaces

How much Fourier information can be restricted to a curved hypersurface without losing norm control?

[Explanation pane](families/077/explanation.md) · [Mathematical source pane](families/077/mathematics.md)

- [Elliptic capacity propagation and Fourier restriction to the sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026/Elliptic-capacity-propagation-and-Fourier-restriction-to-the-sphere-September-24-2026.pdf) · [individual note](papers/paper-e2a3a74983521b50.md)
- [Diagonal Fourier extension for positively curved surfaces in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026/Diagonal-Fourier-extension-for-positively-curved-surfaces-in-three-dimensions-September-24-2026.pdf) · [individual note](papers/paper-e8cc764c1b5cd604.md)

### 078 · The three-dimensional Bochner–Riesz conjecture

At what exponents do smoothed spherical Fourier cutoffs define bounded operators in three dimensions?

[Explanation pane](families/078/explanation.md) · [Mathematical source pane](families/078/mathematics.md)

- [Bochner–Riesz multipliers in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bochner-Riesz-Multipliers-in-Three-Dimensions-September-24-2026/Bochner-Riesz-Multipliers-in-Three-Dimensions-September-24-2026.pdf) · [individual note](papers/paper-55986c5ee747efe3.md)

### 079 · Local smoothing in three dimensions

Does averaging a moving wave over time improve its spatial regularity by the predicted amount?

[Explanation pane](families/079/explanation.md) · [Mathematical source pane](families/079/mathematics.md)

- [Critical local smoothing for the three-dimensional wave equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-local-smoothing-for-the-three-dimensional-wave-equation-September-24-2026/paper.pdf) · [individual note](papers/paper-eb51b4d542e20f27.md)

### 080 · The exact Sobolev endpoint for Schrödinger convergence

How smooth must initial quantum-wave data be so that Schrödinger evolution returns to it pointwise as time tends to zero?

[Explanation pane](families/080/explanation.md) · [Mathematical source pane](families/080/mathematics.md)

- [Endpoint convergence for the planar Schrodinger equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-convergence-for-the-planar-Schrodinger-equation-September-24-2026/paper.pdf) · [individual note](papers/paper-aba6f578d8e598ff.md)
- [Endpoint pointwise convergence for the Schrodinger equation in higher dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Endpoint-pointwise-convergence-for-the-Schrodinger-equation-in-higher-dimensions-September-24-2026/paper.pdf) · [individual note](papers/paper-5cfa80856f1bba48.md)

### 081 · Riesz transforms and rectifiability in higher codimension

Can bounded singular-integral behavior force a rough higher-codimension set to resemble smooth surfaces?

[Explanation pane](families/081/explanation.md) · [Mathematical source pane](families/081/mathematics.md)

- [Riesz transforms and uniform rectifiability in higher codimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Riesz-transforms-and-uniform-rectifiability-in-higher-codimension-September-24-2026/paper.pdf) · [individual note](papers/paper-6e3930fcb4205109.md)

### 082 · Annular variation and dyadic absolute bounds for the triangular Hilbert transform

How much cancellation survives in a singular integral coupling three directions, including variation across scales?

[Explanation pane](families/082/explanation.md) · [Mathematical source pane](families/082/mathematics.md)

- [Annular variation of the triangular Hilbert transform at the symmetric point](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Annular-variation-of-the-triangular-Hilbert-transform-at-the-symmetric-point-October-5-2026/annular-variation.pdf) · [individual note](papers/paper-91a1fc251311c9e3.md)
- [An L³ bound for the dyadic triangular Hilbert form](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L3-bound-for-the-dyadic-triangular-Hilbert-form-October-5-2026/dyadic-triangular-hilbert.pdf) · [individual note](papers/paper-d49bbfc14def2c7b.md)
- [The maximal triangular Hilbert transform at the symmetric point](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-maximal-triangular-Hilbert-transform-at-the-symmetric-point-September-24-2026/paper.pdf) · [individual note](papers/paper-e5c7201525f4a19f.md)

### 083 · Hilbert transforms along Lipschitz directions

Is singular integration along a direction field still bounded when the direction changes only in a Lipschitz manner?

[Explanation pane](families/083/explanation.md) · [Mathematical source pane](families/083/mathematics.md)

- [A uniform Hilbert transform estimate for Lipschitz directions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-uniform-Hilbert-transform-estimate-for-Lipschitz-directions-September-25-2026/main.pdf) · [individual note](papers/paper-355dcc1d5f0d69a2.md)

### 084 · The geometric case of the Erdős similarity conjecture

Can a measurable set of positive size avoid every scaled and translated copy of a specified geometric sequence?

[Explanation pane](families/084/explanation.md) · [Mathematical source pane](families/084/mathematics.md)

- [The geometric case of the Erdős similarity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-geometric-case-of-the-Erdos-similarity-conjecture-October-5-2026/geometric-erdos-similarity.pdf) · [individual note](papers/paper-a1c3c3a97abe4442.md)
- [The dyadic case of the Erdős similarity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-dyadic-case-of-the-Erdos-similarity-conjecture-September-25-2026/paper.pdf) · [individual note](papers/paper-06a721889eac6514.md)

### 085 · Endpoint Sobolev regularity of centered disk averages

How much differentiability can survive taking the largest centered average over disks?

[Explanation pane](families/085/explanation.md) · [Mathematical source pane](families/085/mathematics.md)

- [An Endpoint Gradient Bound for the Centered Disk Maximal Operator](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Endpoint-Gradient-Bound-for-the-Centered-Disk-Maximal-Operator-September-26-2026/article.pdf) · [individual note](papers/paper-3eee048d7739e517.md)

### 086 · An L^{3} bound for the trilinear Hilbert transform

Can three interacting functions be controlled by the expected cubic-integrability estimate for a singular operator?

[Explanation pane](families/086/explanation.md) · [Mathematical source pane](families/086/mathematics.md)

- [An L^{3} bound for the trilinear Hilbert transform](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L3-bound-for-the-trilinear-Hilbert-transform-October-5-2026/paper.pdf) · [individual note](papers/paper-0ae7e1de0b988a10.md)

## Convex and metric geometry

### 087 · The Mahler conjectures, functional inequalities and polar-product symplectic width

How small can the product of the volume of a convex body and the volume of its polar be?

[Explanation pane](families/087/explanation.md) · [Mathematical source pane](families/087/mathematics.md)

- [The symmetric Mahler conjecture and its equality cases](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-symmetric-Mahler-conjecture-and-its-equality-cases-September-22-2026/paper.pdf) · [individual note](papers/paper-b07e69d4140dae68.md)
- [The Mahler Conjecture for General Convex Bodies](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mahler-Conjecture-for-General-Convex-Bodies-September-22-2026/paper.pdf) · [individual note](papers/paper-853109e89b8dc2fc.md)
- [Symplectic Balls in Symmetric Polar Products](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symplectic-Balls-in-Symmetric-Polar-Products-September-22-2026/paper.pdf) · [individual note](papers/paper-0e551ff041d4ae00.md)

### 088 · Sharp projection-body inequalities and a counterexample to simplex maximization

Which convex shapes extremize inequalities involving their shadows and projection bodies?

[Explanation pane](families/088/explanation.md) · [Mathematical source pane](families/088/mathematics.md)

- [Petty’s projection-volume conjecture in dimensions at least four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pettys-projection-volume-conjecture-in-dimensions-at-least-four-September-24-2026/paper.pdf) · [individual note](papers/paper-baa6c59ad25ce6a1.md)
- [A product counterexample to the simplex maximum for projection-body volume](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-product-counterexample-to-the-simplex-maximum-for-projection-body-volume-September-24-2026/paper.pdf) · [individual note](papers/paper-34632678d2159ed5.md)

### 089 · Bounded-distortion L_{1} embeddings of planar and bounded-treewidth graphs

Can graph distances be represented as distances between vectors measured by total coordinatewise displacement with uniformly bounded distortion?

[Explanation pane](families/089/explanation.md) · [Mathematical source pane](families/089/mathematics.md)

- [Planar Graph Metrics Embed into L1 with Constant Distortion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Planar-Graph-Metrics-Embed-into-L1-with-Constant-Distortion-September-23-2026/paper.pdf) · [individual note](papers/paper-1ca672e303a58aff.md)
- [L1 Embeddings of Graphs of Bounded Treewidth](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/L1-Embeddings-of-Graphs-of-Bounded-Treewidth-September-23-2026/paper.pdf) · [individual note](papers/paper-a732d1138d040d4c.md)

### 090 · Triangular-lattice optimality, long-range Riesz and Coulomb energies, and spherical logarithmic energy

Why should triangular arrangements minimize suitable long-range repulsive energies, and what is the corresponding spherical behavior?

[Explanation pane](families/090/explanation.md) · [Mathematical source pane](families/090/mathematics.md)

- [An atomic certificate for triangular-lattice universal optimality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-atomic-certificate-for-triangular-lattice-universal-optimality-September-26-2026/paper.pdf) · [individual note](papers/paper-5943bd03b2930cfb.md)
- [Universal optimality of the triangular lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-optimality-of-the-triangular-lattice-September-23-2026/paper.pdf) · [individual note](papers/paper-bbd4e1a1173c3f7b.md)
- [A sharp Fourier certificate for planar circle packing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-Fourier-certificate-for-planar-circle-packing-September-23-2026/paper.pdf) · [individual note](papers/paper-31e9cc4857e0f3f4.md)
- [Triangular minimality for planar Coulomb renormalized energy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Triangular-minimality-for-planar-Coulomb-renormalized-energy-September-23-2026/paper.pdf) · [individual note](papers/paper-91d5bb1b617478bf.md)

### 091 · Logarithmic and L_{p} Brunn–Minkowski inequalities and the B-conjecture

How do convex-body volumes change under geometric interpolation, and are the predicted logarithmic concavity bounds sharp?

[Explanation pane](families/091/explanation.md) · [Mathematical source pane](families/091/mathematics.md)

- [The logarithmic Brunn–Minkowski conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-logarithmic-Brunn-Minkowski-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-1c8ee12e593f5b42.md)

### 092 · The optimal order of convex-body covering density

How efficiently can translated copies of one convex body cover high-dimensional space?

[Explanation pane](families/092/explanation.md) · [Mathematical source pane](families/092/mathematics.md)

- [A single-lattice covering bound of order n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-single-lattice-covering-bound-of-order-n-log-n-September-23-2026/paper.pdf) · [individual note](papers/paper-e021dd6ed3a78625.md)
- [Translative covering densities of order n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Translative-covering-densities-of-order-n-log-n-September-23-2026/paper.pdf) · [individual note](papers/paper-f24a5e830f7bd50f.md)

### 093 · Dimension-free logarithmic Sobolev inequality for subgaussian log-concave measures

Can concentration and entropy control for sufficiently regular log-concave distributions be independent of dimension?

[Explanation pane](families/093/explanation.md) · [Mathematical source pane](families/093/mathematics.md)

- [A dimension-free logarithmic Sobolev inequality for subgaussian log-concave measures](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-dimension-free-logarithmic-Sobolev-inequality-for-subgaussian-log-concave-measures-September-23-2026/paper.pdf) · [individual note](papers/paper-c082d973442fd637.md)

### 094 · Subpolynomial dimension reduction in L_{p}

Can a finite configuration in an Lp space be compressed into far fewer coordinates while preserving its distances approximately?

[Explanation pane](families/094/explanation.md) · [Mathematical source pane](families/094/mathematics.md)

- [Subpolynomial dimension reduction in Lp](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-dimension-reduction-in-Lp-September-23-2026/paper.pdf) · [individual note](papers/paper-7ed3cd025e4304a8.md)

### 095 · Hyperbolicity cones without semidefinite lifts

Can every convex cone defined by a hyperbolic polynomial be represented through a larger semidefinite constraint?

[Explanation pane](families/095/explanation.md) · [Mathematical source pane](families/095/mathematics.md)

- [Hyperbolicity Cones Without Semidefinite Lifts](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hyperbolicity-Cones-Without-Semidefinite-Lifts-October-5-2026/nonliftable-hyperbolicity.pdf) · [individual note](papers/paper-d2a2e35ed58f7add.md)
- [A nonspectrahedral hyperbolicity cone](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Nonspectrahedral-Hyperbolicity-Cone-September-24-2026/nonspectrahedral-hyperbolicity-cone.pdf) · [individual note](papers/paper-784dd751a0bb3112.md)
- [An Exact Semidefinite Lift of a Nonspectrahedral Hyperbolicity Cone](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Exact-Semidefinite-Lift-of-a-Nonspectrahedral-Hyperbolicity-Cone-October-5-2026/Exact-Semidefinite-Lift-of-a-Nonspectrahedral-Hyperbolicity-Cone.pdf) · [individual note](papers/paper-adcffb5675009b3b.md)

### 096 · The Gaussian propeller conjecture in every dimension

Which partition of Gaussian space maximizes a specified barycentric objective, and is the propeller-shaped partition optimal?

[Explanation pane](families/096/explanation.md) · [Mathematical source pane](families/096/mathematics.md)

- [The Gaussian propeller bound in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-Propeller-Bound-in-Every-Dimension-September-24-2026/main.pdf) · [individual note](papers/paper-d53eafe7e9ff96b2.md)

### 097 · The Euclidean Steinitz–Bergström bound

How tightly can vectors summing to zero be ordered so that every partial sum stays small?

[Explanation pane](families/097/explanation.md) · [Mathematical source pane](families/097/mathematics.md)

- [The Euclidean Steinitz–Bergström theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Euclidean-Steinitz-Bergstrom-theorem-September-24-2026/The-Euclidean-Steinitz-Bergstrom-theorem-September-24-2026.pdf) · [individual note](papers/paper-53028b12bb04f949.md)

### 098 · Compact counterexamples to bi-Lipschitz dimension reduction

Can some compact metric spaces resist every finite-dimensional distance-preserving representation with bounded distortion?

[Explanation pane](families/098/explanation.md) · [Mathematical source pane](families/098/mathematics.md)

- [A doubling Hilbert subset with no finite-dimensional bi-Lipschitz embedding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-doubling-Hilbert-subset-with-no-finite-dimensional-bi-Lipschitz-embedding-September-25-2026/main.pdf) · [individual note](papers/paper-25541d8e8df4a0b0.md)

### 099 · The sharp exponential scale of edit-distance distortion

How much distortion is unavoidable when edit distance is represented in simpler normed spaces?

[Explanation pane](families/099/explanation.md) · [Mathematical source pane](families/099/mathematics.md)

- [Edit Distance in l1: Matching Bounds up to Constants in the Exponent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Edit-Distance-in-l1-Matching-Bounds-up-to-Constants-in-the-Exponent-September-27-2026/paper.pdf) · [individual note](papers/paper-2acb38d51dc8e08b.md)
- [Finite-Circle Obstructions, Binary Codes, and Histogram Embeddings for Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Circle-Obstructions-Binary-Codes-and-Histogram-Embeddings-for-Edit-Distance-September-27-2026/paper.pdf) · [individual note](papers/paper-0e6d73d00d94857d.md)
- [Tree Constructions for the l1 Distortion of Binary Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tree-Constructions-for-the-l1-Distortion-of-Binary-Edit-Distance-September-27-2026/paper.pdf) · [individual note](papers/paper-861294c38061120b.md)

### 100 · Cylinder coverings below the half-area bound

How much total cross-sectional area is required for cylinders covering a convex body?

[Explanation pane](families/100/explanation.md) · [Mathematical source pane](families/100/mathematics.md)

- [Finite angular cylinder covers below the half-area bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-angular-cylinder-covers-below-the-half-area-bound-September-27-2026/main.pdf) · [individual note](papers/paper-263300816e2dff4c.md)
- [Finite cylinder approximation of ruled sets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-cylinder-approximation-of-ruled-sets-September-27-2026/main.pdf) · [individual note](papers/paper-7c02dfe822dd7473.md)
- [Slope-field perturbations of the two-cylinder covering](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Slope-field-perturbations-of-the-two-cylinder-covering-September-27-2026/main.pdf) · [individual note](papers/paper-1f99e8e106327336.md)
- [Finite triangular approximation of radial sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-triangular-approximation-of-radial-sweeps-September-27-2026/main.pdf) · [individual note](papers/paper-5d1bd9d0543ed713.md)

### 101 · The sharp simplex conjecture for isotropic constants

Among normalized convex bodies, does the simplex maximize the measure of spread called the isotropic constant?

[Explanation pane](families/101/explanation.md) · [Mathematical source pane](families/101/mathematics.md)

- [A sharp entropy bound and the simplex inequality for isotropic constants](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-sharp-entropy-bound-and-the-simplex-inequality-for-isotropic-constants-October-5-2026/isotropic-simplex.pdf) · [individual note](papers/paper-1cacde967efb6246.md)

## Theoretical computer science

### 102 · The Unique Games Conjecture and optimal approximation thresholds

Can nearly satisfiable constraint systems still be computationally hard enough to determine sharp approximation barriers?

[Explanation pane](families/102/explanation.md) · [Mathematical source pane](families/102/mathematics.md)

- [The Unique Games Theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Unique-Games-Theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-0122896e49cb8b79.md)
- [A Direct Proof of Optimal Max-Cut Hardness](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Direct-Proof-of-Optimal-Max-Cut-Hardness-September-23-2026/paper.pdf) · [individual note](papers/paper-e79e9ce01cf713cf.md)
- [The Factor-Two Hardness Threshold for Vertex Cover](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Factor-Two-Hardness-Threshold-for-Vertex-Cover-September-23-2026/paper.pdf) · [individual note](papers/paper-9d567de1c3765ee3.md)
- [Constant-factor hardness of Min-UnCut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-Min-UnCut-September-23-2026/paper.pdf) · [individual note](papers/paper-c5d4813f293dba75.md)
- [Constant-factor hardness of directed feedback vertex set](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-directed-feedback-vertex-set-September-23-2026/paper.pdf) · [individual note](papers/paper-aa17b35bdadfd457.md)

### 103 · Exact derandomization of logarithmic space: $\mathsf L=\mathsf{RL}=\mathsf{BPL}$

Can every randomized computation using logarithmic memory be replaced by a deterministic computation using the same order of memory?

[Explanation pane](families/103/explanation.md) · [Mathematical source pane](families/103/mathematics.md)

- [Exact derandomization of logarithmic space: L = RL = BPL](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Derandomization-of-Logarithmic-Space-L-equals-RL-equals-BPL-September-23-2026/paper.pdf) · [individual note](papers/paper-5e1afd211ac96849.md)

### 104 · Quasipolynomial algorithms for mean-payoff, stochastic and parity games

Can several infinite-duration graph games be solved substantially faster than general exponential search?

[Explanation pane](families/104/explanation.md) · [Mathematical source pane](families/104/mathematics.md)

- [Turn-Based Stochastic Mean-Payoff Games in Deterministic Quasipolynomial Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Turn-Based-Stochastic-Mean-Payoff-Games-in-Deterministic-Quasipolynomial-Time-October-5-2026/stochastic-mean-payoff-games.pdf) · [individual note](papers/paper-36669faf4e5b9e47.md)
- [Mean-payoff parity games in quasipolynomial time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mean-payoff-parity-games-in-quasipolynomial-time-October-5-2026/mean-payoff-parity.pdf) · [individual note](papers/paper-d1bf6ad8e419434a.md)
- [Deterministic quasipolynomial-time mean-payoff games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-quasipolynomial-time-mean-payoff-games-September-25-2026/paper.pdf) · [individual note](papers/paper-d65a80b5538b0a14.md)
- [Randomized quasipolynomial-time mean-payoff games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Randomized-quasipolynomial-time-mean-payoff-games-September-25-2026/paper.pdf) · [individual note](papers/paper-77ada06590d4f430.md)

### 105 · Perfect completeness for 2-to-1 games

Can a constraint game be hard to approximate even when all constraints in the favorable case are exactly satisfiable?

[Explanation pane](families/105/explanation.md) · [Mathematical source pane](families/105/mathematics.md)

- [Perfect completeness for 2-to-1 games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Perfect-completeness-for-2-to-1-games-September-23-2026/paper.pdf) · [individual note](papers/paper-c4e4969e26d43b50.md)

### 106 · Hardness of coloring three-colorable graphs

How many colors are efficiently achievable when a graph is guaranteed to need only three?

[Explanation pane](families/106/explanation.md) · [Mathematical source pane](families/106/mathematics.md)

- [Hardness of finding large independent sets in three-colorable graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hardness-of-finding-large-independent-sets-in-three-colorable-graphs-September-24-2026/Hardness-of-finding-large-independent-sets-in-three-colorable-graphs-September-24-2026.pdf) · [individual note](papers/paper-739714f8b0fb91d6.md)

### 107 · Matrix multiplication with exponent at most 9/4

Can two large matrices be multiplied using substantially fewer arithmetic operations than the familiar cubic algorithm?

[Explanation pane](families/107/explanation.md) · [Mathematical source pane](families/107/mathematics.md)

- [An Upper Bound of 9/4 for the Matrix Multiplication Exponent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Matrix-Multiplication-Nine-Fourths-October-2-2026/paper.pdf) · [individual note](papers/paper-90872dcda176342a.md)
- [Complex Matrix Multiplication Below 2.258 and Rectangular Bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Complex-Matrix-Multiplication-Below-2.258-and-Rectangular-Bounds-September-24-2026/Complex-Matrix-Multiplication-Below-2.258-and-Rectangular-Bounds-September-24-2026.pdf) · [individual note](papers/paper-ffeccf46b092aede.md)
- [Staggered extraction for exact matrix multiplication over every field](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026/Staggered-extraction-for-exact-matrix-multiplication-over-every-field-September-24-2026.pdf) · [individual note](papers/paper-e6b0ff629223aea4.md)

### 108 · A cubic permanent–determinant lower bound

How much larger must a determinant representation be to reproduce the permanent polynomial?

[Explanation pane](families/108/explanation.md) · [Mathematical source pane](families/108/mathematics.md)

- [A cubic lower bound for border determinantal complexity of the permanent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026/A-cubic-lower-bound-for-border-determinantal-complexity-of-the-permanent-September-24-2026.pdf) · [individual note](papers/paper-b4bb67ab3de819c9.md)

### 109 · Integer multiplication below $n\log n$

Can multiplying two n-bit integers asymptotically beat the n-log-n running-time scale?

[Explanation pane](families/109/explanation.md) · [Mathematical source pane](families/109/mathematics.md)

- [Integer multiplication below n log n](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integer-multiplication-below-n-log-n-September-23-2026/paper.pdf) · [individual note](papers/paper-0a12f9cb68425145.md)

### 110 · Optimal-order randomized k-server on arbitrary metrics

How well can an online algorithm move k servers to answer unknown future requests in an arbitrary metric space?

[Explanation pane](families/110/explanation.md) · [Mathematical source pane](families/110/mathematics.md)

- [Squared-logarithmic randomized k-server on arbitrary metrics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Squared-logarithmic-randomized-k-server-on-arbitrary-metrics-September-24-2026/Squared-logarithmic-randomized-k-server-on-arbitrary-metrics-September-24-2026.pdf) · [individual note](papers/paper-af80f27a0db66f71.md)
- [Uniform computation of the squared-logarithmic k-server bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-computation-of-the-squared-logarithmic-k-server-bound-September-24-2026/Uniform-computation-of-the-squared-logarithmic-k-server-bound-September-24-2026.pdf) · [individual note](papers/paper-30f6d4bbce1030c6.md)

### 111 · One-sample matroid prophet inequalities against an almighty adversary

Can a single sample of each uncertain reward guide near-optimal selection under matroid constraints against a powerful adversary?

[Explanation pane](families/111/explanation.md) · [Mathematical source pane](families/111/mathematics.md)

- [One Sample Suffices for Matroid Prophet Inequalities against an Almighty Adversary](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/One-Sample-Suffices-for-Matroid-Prophet-Inequalities-against-an-Almighty-Adversary-September-23-2026/final.pdf) · [individual note](papers/paper-d027c9ccbce3784d.md)

### 112 · Beyond the square-root exponent for depth-three circuits

How large must a shallow arithmetic circuit be to compute explicit difficult polynomials?

[Explanation pane](families/112/explanation.md) · [Mathematical source pane](families/112/mathematics.md)

- [Beyond the Square-Root Exponent for Depth-Three Boolean Circuits](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Beyond-the-Square-Root-Exponent-for-Depth-Three-Boolean-Circuits-September-23-2026/main.pdf) · [individual note](papers/paper-845f094d57cbb49b.md)

### 113 · Approximate counting and entropy of perfect matchings

Can we efficiently estimate how many perfect matchings a graph has and the associated uncertainty?

[Explanation pane](families/113/explanation.md) · [Mathematical source pane](families/113/mathematics.md)

- [A Fully Polynomial Randomized Approximation Scheme for Perfect Matchings in General Graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Fully-Polynomial-Randomized-Approximation-Scheme-for-Perfect-Matchings-in-General-Graphs-September-23-2026/main.pdf) · [individual note](papers/paper-a6b76a57e739fca3.md)
- [Entropy and Face Dimension of the Perfect-Matching Polytope](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Entropy-and-Face-Dimension-of-the-Perfect-Matching-Polytope-September-23-2026/main.pdf) · [individual note](papers/paper-9c9bb2a021e014c6.md)

### 114 · Approximate counting of common integer polymatroid bases

Can we efficiently count integer vectors that satisfy two polymatroid-base constraints simultaneously?

[Explanation pane](families/114/explanation.md) · [Mathematical source pane](families/114/mathematics.md)

- [An FPRAS for Common Integer Polymatroid Bases with Binary Capacities](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-FPRAS-for-Common-Integer-Polymatroid-Bases-with-Binary-Capacities-October-5-2026/polymatroid-fpras.pdf) · [individual note](papers/paper-a46100c82af7f163.md)
- [Approximate counting of common bases of two matroids](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Approximate-counting-of-common-bases-of-two-matroids-September-23-2026/main.pdf) · [individual note](papers/paper-37d510a7d91dc2f7.md)

### 115 · Sampling and counting contingency tables with arbitrary margins

Can tables with fixed row and column totals be sampled and counted efficiently even for arbitrary margins?

[Explanation pane](families/115/explanation.md) · [Mathematical source pane](families/115/mathematics.md)

- [Exact Uniform Sampling of Contingency Tables with Arbitrary Margins](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Uniform-Sampling-of-Contingency-Tables-with-Arbitrary-Margins-September-24-2026/main.pdf) · [individual note](papers/paper-4e6e42294d0e904c.md)
- [An FPRAS for Cell-Bounded Contingency Tables](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-FPRAS-for-Cell-Bounded-Contingency-Tables-September-24-2026/main.pdf) · [individual note](papers/paper-e4abe4c4ee7776cb.md)

### 116 · Uniform black-box noncommutative identity testing across characteristics

Can an algorithm detect whether a noncommutative polynomial is identically zero using only input-output access?

[Explanation pane](families/116/explanation.md) · [Mathematical source pane](families/116/mathematics.md)

- [Uniform Matrix Hitting Points in Every Positive Characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Matrix-Hitting-Points-in-Every-Positive-Characteristic-October-4-2026/uniform-matrix-hitting-points-positive-characteristic.pdf) · [individual note](papers/paper-bafcd17a1009229c.md)
- [One Rational Matrix Hitting Point for Noncommutative Formulas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/One-Rational-Matrix-Hitting-Point-for-Noncommutative-Formulas-September-24-2026/One-Rational-Matrix-Hitting-Point-for-Noncommutative-Formulas-September-24-2026.pdf) · [individual note](papers/paper-e8702eb3edf4cc7e.md)
- [Polynomial Hitting Lists for Noncommutative Rational Formulas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026/Polynomial-Hitting-Lists-for-Noncommutative-Rational-Formulas-September-24-2026.pdf) · [individual note](papers/paper-677471faece59b68.md)

### 117 · Uniform sparsest cut: hardness and semidefinite gaps

How well can a graph's sparsest balanced bottleneck be approximated, and where do semidefinite relaxations fail?

[Explanation pane](families/117/explanation.md) · [Mathematical source pane](families/117/mathematics.md)

- [Constant-factor hardness of uniform sparsest cut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Constant-factor-hardness-of-uniform-sparsest-cut-September-24-2026/Constant-factor-hardness-of-uniform-sparsest-cut-September-24-2026.pdf) · [individual note](papers/paper-669f1c1402a6992e.md)
- [Near-square-root logarithmic integrality gaps for uniform sparsest cut](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Near-square-root-logarithmic-integrality-gaps-for-uniform-sparsest-cut-September-24-2026/Near-square-root-logarithmic-integrality-gaps-for-uniform-sparsest-cut-September-24-2026.pdf) · [individual note](papers/paper-b26f379b6eb43f24.md)

### 118 · Bin packing and unbounded configuration-LP gaps

How far can fractional bin-packing solutions underestimate the true number of bins needed?

[Explanation pane](families/118/explanation.md) · [Mathematical source pane](families/118/mathematics.md)

- [Additive hardness and unbounded configuration gaps in bin packing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Additive-hardness-and-unbounded-configuration-gaps-in-bin-packing-September-24-2026/Additive-hardness-and-unbounded-configuration-gaps-in-bin-packing-September-24-2026.pdf) · [individual note](papers/paper-6bb0a2a62beebd99.md)

### 119 · The Courtade–Kumar and Hellinger conjectures

Which single Boolean summary of a noisy binary signal preserves the most information about the original signal?

[Explanation pane](families/119/explanation.md) · [Mathematical source pane](families/119/mathematics.md)

- [Sharp binary-information contraction on the discrete cube](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-binary-information-contraction-on-the-discrete-cube-September-24-2026/main.pdf) · [individual note](papers/paper-7b195817917cb11a.md)
- [Hellinger contraction with arbitrary Boolean output bias](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hellinger-contraction-with-arbitrary-Boolean-output-bias-September-24-2026/main.pdf) · [individual note](papers/paper-77c6b4075ae8a38d.md)

### 120 · Almost-linear-time exact matching and prescribed-degree factors in general graphs

Can exact matchings and more general prescribed-degree subgraphs be found in nearly linear time?

[Explanation pane](families/120/explanation.md) · [Mathematical source pane](families/120/mathematics.md)

- [Almost-Linear-Time Maximum-Cardinality Matching in General Graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Almost-Linear-Time-Maximum-Cardinality-Matching-in-Sparse-General-Graphs-September-24-2026/main.pdf) · [individual note](papers/paper-669239fdc7f9d479.md)

### 121 · Almost-linear approximation of edit distance

Can approximate edit distance be computed in nearly linear time with a useful approximation guarantee?

[Explanation pane](families/121/explanation.md) · [Mathematical source pane](families/121/mathematics.md)

- [An Almost-Linear Approximation Scheme for Edit Distance](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Almost-Linear-Approximation-Scheme-for-Edit-Distance-September-24-2026/paper.pdf) · [individual note](papers/paper-160a98fc23945564.md)

### 122 · Quantitative trace-reconstruction bounds with a uniform decoder

How many randomly deleted copies of a string are needed to reconstruct the original uniformly over inputs?

[Explanation pane](families/122/explanation.md) · [Mathematical source pane](families/122/mathematics.md)

- [Uniform quasipolynomial-time trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-quasipolynomial-time-trace-reconstruction-October-5-2026/uniform-trace-reconstruction.pdf) · [individual note](papers/paper-9a709de733cd50f5.md)
- [A latest-anchor induction with spectrally compact masks for worst-case trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-latest-anchor-induction-with-spectrally-compact-masks-for-worst-case-trace-reconstruction-October-5-2026/paper.pdf) · [individual note](papers/paper-02d4394a97f986d3.md)
- [Quantitative lower bounds for trace reconstruction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/quantitative-lower-bounds-for-trace-reconstruction-September-24-2026/paper.pdf) · [individual note](papers/paper-b81b5d62aea3024c.md)

### 124 · Polynomial-time scheduling on three identical machines

Can precedence-constrained jobs on three identical machines be scheduled optimally in polynomial time in the stated model?

[Explanation pane](families/124/explanation.md) · [Mathematical source pane](families/124/mathematics.md)

- [A Polynomial-Time Algorithm for Three-Machine Unit-Job Scheduling](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-polynomial-time-algorithm-for-three-machine-unit-job-scheduling-September-24-2026/paper.pdf) · [individual note](papers/paper-40a7d8e28e7ad4f5.md)

### 125 · The metric k-median approximation threshold and recovery

What is the best efficiently attainable approximation factor for choosing k centers under a sum-of-distances objective?

[Explanation pane](families/125/explanation.md) · [Mathematical source pane](families/125/mathematics.md)

- [Single-exponential recovery and bounded-price strictness for metric k-median](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Single-Exponential-Recovery-and-Bounded-Price-Strictness-for-Metric-k-Median-September-24-2026/paper.pdf) · [individual note](papers/paper-ce86ea9bfcf066c5.md)
- [The approximation threshold for metric k-median](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Approximation-Threshold-for-Metric-k-Median-September-24-2026/main.pdf) · [individual note](papers/paper-814bc4ceffe46642.md)

### 126 · Exponential semidefinite complexity of perfect matching

Must exact semidefinite descriptions of the perfect-matching polytope have exponential size?

[Explanation pane](families/126/explanation.md) · [Mathematical source pane](families/126/mathematics.md)

- [Exponential PSD rank of positively shifted matching matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-PSD-rank-of-positively-shifted-matching-matrices-October-5-2026/shifted-matching-psd.pdf) · [individual note](papers/paper-62ba08d788e1d793.md)

### 127 · Average sensitivity of polynomial threshold functions

How frequently can flipping one input bit change the sign of a low-degree polynomial on the Boolean cube?

[Explanation pane](families/127/explanation.md) · [Mathematical source pane](families/127/mathematics.md)

- [Average sensitivity of polynomial threshold functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Average-Sensitivity-of-Polynomial-Threshold-Functions-September-25-2026/main.pdf) · [individual note](papers/paper-8abf50c0b66d23a7.md)

### 128 · A factor-two approximation for shortest common superstring

Can we efficiently find a string containing every input string whose length is at most twice optimal?

[Explanation pane](families/128/explanation.md) · [Mathematical source pane](families/128/mathematics.md)

- [A Polynomial-Time 2-Approximation for Shortest Common Superstring](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Polynomial-Time-2-Approximation-for-Shortest-Common-Superstring-September-24-2026/paper.pdf) · [individual note](papers/paper-2d2585ddd6f73380.md)

### 129 · Exponential state costs for two-way automata

How many extra states are required when changing the directionality or determinism of finite automata?

[Explanation pane](families/129/explanation.md) · [Mathematical source pane](families/129/mathematics.md)

- [An exponential state lower bound for two-way nondeterministic complementation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exponential-state-lower-bound-for-two-way-nondeterministic-complementation-September-25-2026/paper.pdf) · [individual note](papers/paper-82afb926eadc0625.md)
- [An exponential two-way deterministic state lower bound for one-way liveness](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exponential-two-way-deterministic-state-lower-bound-for-one-way-liveness-September-25-2026/main.pdf) · [individual note](papers/paper-de8d403ec8d082ea.md)

### 130 · Exact Fourier transforms below $n\log n$

Can the exact discrete Fourier transform be computed using fewer than order n-log-n operations in the specified arithmetic model?

[Explanation pane](families/130/explanation.md) · [Mathematical source pane](families/130/mathematics.md)

- [An explicit power saving for the exact discrete Fourier transform](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-power-saving-for-the-exact-discrete-Fourier-transform-September-25-2026/main.pdf) · [individual note](papers/paper-e0dd6b6852eaffa8.md)
- [Finite tensor savings and exact Fourier circuits](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-tensor-savings-and-exact-Fourier-circuits-September-25-2026/main.pdf) · [individual note](papers/paper-141aacc64c4adada.md)

### 131 · Rapid mixing of graph switches for every degree sequence

Do local edge-switch moves efficiently randomize graphs with any fixed feasible degree sequence?

[Explanation pane](families/131/explanation.md) · [Mathematical source pane](families/131/mathematics.md)

- [Polynomial mixing of the switch chain for every graphical degree sequence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026/main.pdf) · [individual note](papers/paper-5c889f87b7686754.md)

### 132 · A superquadratic separation of sensitivity and block sensitivity

How far apart can the number of sensitive single bits and sensitive blocks of bits be?

[Explanation pane](families/132/explanation.md) · [Mathematical source pane](families/132/mathematics.md)

- [A superquadratic separation between sensitivity and block sensitivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-superquadratic-separation-between-sensitivity-and-block-sensitivity-September-25-2026/paper.pdf) · [individual note](papers/paper-a61daa8a7cad31d4.md)

### 133 · The computational complexity of Weisfeiler–Leman refinement

How much computational work does iterative Weisfeiler–Leman graph refinement actually require?

[Explanation pane](families/133/explanation.md) · [Mathematical source pane](families/133/mathematics.md)

- [Parity lifts and bounded-treewidth witnesses for Weisfeiler–Leman equivalence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Parity-lifts-and-bounded-treewidth-witnesses-for-Weisfeiler-Leman-equivalence-September-25-2026/paper.pdf) · [individual note](papers/paper-363a3d4723d50577.md)
- [The complexity of identifying a graph by Weisfeiler–Leman refinement](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-complexity-of-identifying-a-graph-by-Weisfeiler-Leman-refinement-September-25-2026/paper.pdf) · [individual note](papers/paper-6594217390655ed8.md)
- [Unconditional time lower bounds for Weisfeiler–Leman equivalence](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unconditional-time-lower-bounds-for-Weisfeiler-Leman-equivalence-September-25-2026/paper.pdf) · [individual note](papers/paper-29d6e91ab2b893b8.md)
- [Variable-dimension Weisfeiler–Leman equivalence on general and subcubic graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Variable-dimension-Weisfeiler-Leman-equivalence-on-general-and-subcubic-graphs-September-25-2026/paper.pdf) · [individual note](papers/paper-04af26066aee9c8c.md)

### 134 · Generalized star height at most three

How deeply must star operations nest in expressions describing regular languages when complement is available?

[Explanation pane](families/134/explanation.md) · [Mathematical source pane](families/134/mathematics.md)

- [Finite Monoid Computations and a Uniform Generalized Star-Height Bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Monoid-Computations-and-a-Uniform-Generalized-Star-Height-Bound-September-25-2026/Finite-Monoid-Computations-and-a-Uniform-Generalized-Star-Height-Bound-September-25-2026.pdf) · [individual note](papers/paper-2404f147f0b49202.md)
- [Generalized Star Height at Most Four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-Star-Height-at-Most-Four-September-25-2026/Generalized-Star-Height-at-Most-Four-September-25-2026.pdf) · [individual note](papers/paper-2e19fd6a8570160d.md)
- [Generalized Star Height at Most Three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-Star-Height-at-Most-Three-September-25-2026/article.pdf) · [individual note](papers/paper-2a7d1782ad7195cf.md)

### 135 · Homogeneous depth-five lower bounds for iterated matrix multiplication

Can explicit matrix-product polynomials force large homogeneous depth-five arithmetic circuits?

[Explanation pane](families/135/explanation.md) · [Mathematical source pane](families/135/mathematics.md)

- [Homogeneous depth-five lower bounds for iterated matrix multiplication](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Homogeneous-depth-five-lower-bounds-for-iterated-matrix-multiplication-September-25-2026/Homogeneous-depth-five-lower-bounds-for-iterated-matrix-multiplication-September-25-2026.pdf) · [individual note](papers/paper-15b46a0552dd4598.md)

### 136 · A quasilinear PCP theorem for PPAD

Can equilibrium-search problems be verified through very short probabilistically checkable constructions?

[Explanation pane](families/136/explanation.md) · [Mathematical source pane](families/136/mathematics.md)

- [The PCP-for-PPAD conjecture: a quasilinear reduction](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-PCP-for-PPAD-conjecture-a-quasilinear-reduction-September-25-2026/paper.pdf) · [individual note](papers/paper-709441a1e8cc1934.md)

### 137 · One-tape time simulation in two-fifths-power space

How much working memory is needed to simulate a time-bounded one-tape computation?

[Explanation pane](families/137/explanation.md) · [Mathematical source pane](families/137/mathematics.md)

- [Simulating One-Tape Time in Two-Fifths-Power Space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simulating-One-Tape-Time-in-Two-Fifths-Power-Space-September-25-2026/article.pdf) · [individual note](papers/paper-b293c9fc34d7ffce.md)

### 138 · Subset Sum in $O(2^{0.49n})$ time

Can subset sum be solved faster than the classic square-root-of-the-search-space exponential scale?

[Explanation pane](families/138/explanation.md) · [Mathematical source pane](families/138/mathematics.md)

- [Subset Sum in Time $O(2^{0.49n})$](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subset-Sum-in-Time-2-power-0-49n-October-4-2026/subset-sum.pdf) · [individual note](papers/paper-ebd91ba7507763dc.md)
- [A Low-Space Algorithm for Worst-Case Subset Sum](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Low-Space-Algorithm-for-Worst-Case-Subset-Sum-September-26-2026/paper.pdf) · [individual note](papers/paper-744dc527663d3c7f.md)

### 139 · Subpolynomial query complexity for log-concave sampling

How many oracle queries are fundamentally needed to sample from a log-concave distribution?

[Explanation pane](families/139/explanation.md) · [Mathematical source pane](families/139/mathematics.md)

- [Subpolynomial query complexity for well-conditioned log-concave sampling](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subpolynomial-query-complexity-for-well-conditioned-log-concave-sampling-September-26-2026/article.pdf) · [individual note](papers/paper-e54200c0718980f7.md)

### 140 · Memory–sample lower bounds for noiseless Gaussian regression

How does limited memory increase the number of samples needed to learn even noiseless Gaussian linear regression?

[Explanation pane](families/140/explanation.md) · [Mathematical source pane](families/140/mathematics.md)

- [Memory and precision in noiseless Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Memory-and-precision-in-noiseless-Gaussian-regression-September-27-2026/paper.pdf) · [individual note](papers/paper-6439eb3dd3429538.md)
- [Posterior replicas and conditional information in Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Posterior-replicas-and-conditional-information-in-Gaussian-regression-September-27-2026/paper.pdf) · [individual note](papers/paper-78317a39d1179b5d.md)
- [Localization costs and information growth for exact Gaussian observations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Localization-costs-and-information-growth-for-exact-Gaussian-observations-September-27-2026/paper.pdf) · [individual note](papers/paper-a5921432de007825.md)
- [Projection moments, positive cap domination, and Riesz estimates on the sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Projection-moments-positive-cap-domination-and-Riesz-estimates-on-the-sphere-September-27-2026/paper.pdf) · [individual note](papers/paper-2999ebb39d71ea49.md)
- [Replacing Gaussian observations in memory-constrained inference](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Replacing-Gaussian-observations-in-memory-constrained-inference-September-27-2026/paper.pdf) · [individual note](papers/paper-b4fd6b04daecaaec.md)
- [Subsphere methods for memory-sample lower bounds in noiseless Gaussian regression](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Subsphere-methods-for-memory-sample-lower-bounds-in-noiseless-Gaussian-regression-September-27-2026/paper.pdf) · [individual note](papers/paper-c2d31b0748a514bc.md)

### 141 · Existential–universal real sentences in the counting hierarchy

Where does deciding alternating quantified polynomial inequalities fit among counting-based complexity classes?

[Explanation pane](families/141/explanation.md) · [Mathematical source pane](families/141/mathematics.md)

- [Existential–universal real sentences in the counting hierarchy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Existential-universal-real-sentences-in-the-counting-hierarchy-October-4-2026/etr-counting-hierarchy.pdf) · [individual note](papers/paper-25f9db8c418d6934.md)

### 142 · Deterministic polynomial factorization over prime fields

Can a deterministic efficient algorithm factor polynomials over every prime field?

[Explanation pane](families/142/explanation.md) · [Mathematical source pane](families/142/mathematics.md)

- [Deterministic Polynomial Factorization over Prime Fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-Polynomial-Factorization-over-Prime-Fields-October-4-2026/Deterministic-Polynomial-Factorization-over-Prime-Fields.pdf) · [individual note](papers/paper-783e6a92fa7af25a.md)

## Dynamical systems and ergodic theory

### 143 · Hilbert's sixteenth problem: uniform bounds for limit cycles

Can polynomial planar vector fields of a fixed degree have arbitrarily many isolated periodic trajectories?

[Explanation pane](families/143/explanation.md) · [Mathematical source pane](families/143/mathematics.md)

- [Uniform bounds for planar polynomial limit cycles](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/uniform-bounds-for-planar-polynomial-limit-cycles-September-24-2026/uniform-bounds-for-planar-polynomial-limit-cycles-September-24-2026.pdf) · [individual note](papers/paper-ce34d06d03483055.md)
- [Two limit cycles for quintic Liénard systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/two-limit-cycles-for-quintic-lienard-systems-September-24-2026/two-limit-cycles-for-quintic-lienard-systems-September-24-2026.pdf) · [individual note](papers/paper-f2d96ea542ffa399.md)

### 144 · Banach’s simple Lebesgue-spectrum problem

Can a deterministic measure-preserving dynamical system have the simplest possible Lebesgue-type frequency spectrum?

[Explanation pane](families/144/explanation.md) · [Mathematical source pane](families/144/mathematics.md)

- [A smooth three-torus diffeomorphism with simple Lebesgue spectrum](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-smooth-three-torus-diffeomorphism-with-simple-Lebesgue-spectrum-September-23-2026/paper.pdf) · [individual note](papers/paper-c5f19387b436895f.md)

### 145 · Rokhlin’s multiple-mixing problem

If a system loses pairwise correlation, must all higher-order correlations also disappear?

[Explanation pane](families/145/explanation.md) · [Mathematical source pane](families/145/mathematics.md)

- [Rokhlin's multiple-mixing problem for one transformation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rokhlins-multiple-mixing-problem-for-one-transformation-September-23-2026/paper.pdf) · [individual note](papers/paper-209ef89b9c877b67.md)

### 146 · Positive metric entropy for the standard map

Can the familiar area-preserving standard map be proved to have a positive amount of chaotic behavior?

[Explanation pane](families/146/explanation.md) · [Mathematical source pane](families/146/mathematics.md)

- [Positive Metric Entropy for the Standard Map at Large Parameters](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-Metric-Entropy-for-the-Standard-Map-at-Large-Parameters-September-23-2026/paper.pdf) · [individual note](papers/paper-23dfbfdae1c08863.md)

### 147 · The near-boundary Birkhoff conjecture

If a billiard is smoothly integrable near its boundary, must its boundary be an ellipse?

[Explanation pane](families/147/explanation.md) · [Mathematical source pane](families/147/mathematics.md)

- [Continuous Phase Foliations Create Analytic Caustic Collars](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Continuous-Phase-Foliations-Create-Analytic-Caustic-Collars-September-24-2026/paper.pdf) · [individual note](papers/paper-a33520af93cb6e3e.md)
- [Rigidity of Smooth Billiards with a Continuous Caustic Collar](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rigidity-of-Smooth-Billiards-with-a-Continuous-Caustic-Collar-September-24-2026/paper.pdf) · [individual note](papers/paper-71a85ff50cd0b5dc.md)

### 148 · The entropy-rate dimension formula for self-similar measures

How does symbolic randomness translate into geometric dimension when self-similar pieces can overlap?

[Explanation pane](families/148/explanation.md) · [Mathematical source pane](families/148/mathematics.md)

- [The entropy-rate dimension formula for self-similar measures on the line](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-entropy-rate-dimension-formula-for-self-similar-measures-on-the-line-September-24-2026/main.pdf) · [individual note](papers/paper-65096e5482344316.md)

### 149 · Classwise permanence for weakly reversible mass-action systems

Can concentrations in a weakly reversible chemical reaction system stay uniformly away from extinction and infinity within each reaction class?

[Explanation pane](families/149/explanation.md) · [Mathematical source pane](families/149/mathematics.md)

- [Uniform Permanence in Weakly Reversible Mass-Action Systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Permanence-in-Weakly-Reversible-Mass-Action-Systems-October-5-2026/permanence.pdf) · [individual note](papers/paper-7b0760997a117bea.md)
- [Boundedness and persistence of weakly reversible mass-action systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Boundedness-and-persistence-of-weakly-reversible-mass-action-systems-September-25-2026/paper.pdf) · [individual note](papers/paper-cdb5a46fab141971.md)

### 150 · Weak mixing of triangular billiards with an irrational angle

Do triangular billiards with an irrational angle necessarily exhibit weak mixing?

[Explanation pane](families/150/explanation.md) · [Mathematical source pane](families/150/mathematics.md)

- [Weak mixing of triangular billiards with an irrational angle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-mixing-of-triangular-billiards-with-an-irrational-angle-October-5-2026/weak-mixing-triangular-billiards.pdf) · [individual note](papers/paper-9aadd9baa57acfe6.md)
- [Ergodicity of triangular billiards with an irrational angle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ergodicity-of-triangular-billiards-with-an-irrational-angle-September-25-2026/Ergodicity-of-triangular-billiards-with-an-irrational-angle-September-25-2026.pdf) · [individual note](papers/paper-e1d8affed60ec064.md)

### 151 · A C^{1} counterexample to the entropy conjecture

Must the topology-driven lower bound on entropy hold for every continuously differentiable dynamical system?

[Explanation pane](families/151/explanation.md) · [Mathematical source pane](families/151/mathematics.md)

- [A C^1 Counterexample to the Entropy Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-C1-Counterexample-to-the-Entropy-Conjecture-September-25-2026/article.pdf) · [individual note](papers/paper-688df3a87fafba92.md)

### 152 · Zero entropy does not guarantee a smooth positive-volume model

Can every zero-entropy measurable dynamical system be represented by a smooth system preserving positive volume?

[Explanation pane](families/152/explanation.md) · [Mathematical source pane](families/152/mathematics.md)

- [A zero-entropy system without a smooth positive-volume model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-entropy-system-without-a-smooth-positive-volume-model-September-25-2026/paper.pdf) · [individual note](papers/paper-d121740482c70f9a.md)

### 153 · Arithmetic classification and non-Pisot singularity for Bernoulli convolutions

When does a random sum of geometrically shrinking signs have a smooth distribution, and when does arithmetic force singularity?

[Explanation pane](families/153/explanation.md) · [Mathematical source pane](families/153/mathematics.md)

- [Arithmetic classification and non-Pisot singularity for Bernoulli convolutions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmetic-classification-and-non-Pisot-singularity-for-Bernoulli-convolutions-October-3-2026/paper.pdf) · [individual note](papers/paper-c180c88bf9e78a1a.md)

### 154 · Pointwise multiple ergodic averages for mixing transformations

Do averages following several related time scales converge pointwise for mixing systems?

[Explanation pane](families/154/explanation.md) · [Mathematical source pane](families/154/mathematics.md)

- [Pointwise Multiple Ergodic Averages for Mixing Transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-Multiple-Ergodic-Averages-for-Mixing-Transformations-October-4-2026/multiple-ergodic-averages.pdf) · [individual note](papers/paper-a1092fb3827f9565.md)
- [Pointwise convergence of fourfold ergodic averages for mixing transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-convergence-of-fourfold-ergodic-averages-for-mixing-transformations-October-4-2026/fourfold-ergodic-averages.pdf) · [individual note](papers/paper-ce51fc685631db38.md)
- [Triple ergodic averages with distinct integer slopes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Triple-ergodic-averages-with-distinct-integer-slopes-October-4-2026/triple-ergodic-distinct-slopes.pdf) · [individual note](papers/paper-1acea3e69861c084.md)
- [Pointwise convergence of triple ergodic averages for mixing transformations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pointwise-convergence-of-triple-ergodic-averages-for-mixing-transformations-October-4-2026/pointwise-triple-ergodic-averages-mixing-transformations.pdf) · [individual note](papers/paper-bb1dbf44dcfa27de.md)

## Combinatorics

### 155 · A counterexample to periodic tiling in dimension three

Can a single tile cover three-dimensional space while forbidding every periodic tiling?

[Explanation pane](families/155/explanation.md) · [Mathematical source pane](families/155/mathematics.md)

- [A translational tile with no fully periodic tiling in dimension three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-translational-tile-with-no-fully-periodic-tiling-in-dimension-three-September-23-2026/paper.pdf) · [individual note](papers/paper-34c30a7d57dacb63.md)

### 156 · Borsuk's conjecture fails in dimension nine

Can every bounded set in nine dimensions be partitioned into ten sets of strictly smaller diameter?

[Explanation pane](families/156/explanation.md) · [Mathematical source pane](families/156/mathematics.md)

- [A nine-dimensional counterexample to Borsuk's covering assertion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-nine-dimensional-counterexample-to-Borsuks-covering-assertion-September-23-2026/paper.pdf) · [individual note](papers/paper-81f27172430098ac.md)

### 157 · Graph coloring, clique minors, and Colin de Verdière invariants

How closely are graph colorability, complete-graph minors, and spectral graph invariants connected?

[Explanation pane](families/157/explanation.md) · [Mathematical source pane](families/157/mathematics.md)

- [A counterexample to Hadwiger's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Hadwigers-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-0ee12dde73281885.md)
- [A counterexample to the Colin de Verdière chromatic conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-the-Colin-de-Verdiere-chromatic-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-b25cd5f505bf81b5.md)
- [A linear list-coloring bound in terms of the Hadwiger number](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-linear-list-coloring-bound-in-terms-of-the-Hadwiger-number-September-23-2026/paper.pdf) · [individual note](papers/paper-8aaa0e2bce929557.md)

### 158 · The Euclidean plane cannot be colored with five colors

How many colors are needed to color every point of the plane so that unit-distance pairs always differ?

[Explanation pane](families/158/explanation.md) · [Mathematical source pane](families/158/mathematics.md)

- [The Euclidean plane is not five-colorable](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Euclidean-plane-is-not-five-colorable-September-23-2026/paper.pdf) · [individual note](papers/paper-df3c630d9c9bd2ae.md)

### 159 · Erdős’s reciprocal-sum conjecture and quasipolynomial Szemerédi bounds

If reciprocals of a set of integers have divergent sum, must the set contain arbitrarily long arithmetic progressions?

[Explanation pane](families/159/explanation.md) · [Mathematical source pane](families/159/mathematics.md)

- [Quasipolynomial Bounds for Arithmetic Progressions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quasipolynomial-Bounds-for-Arithmetic-Progressions-September-23-2026/paper.pdf) · [individual note](papers/paper-1131ab1d9b9ef7d4.md)

### 160 · Superexponential van der Waerden numbers

How fast does the interval length needed to force monochromatic arithmetic progressions grow?

[Explanation pane](families/160/explanation.md) · [Mathematical source pane](families/160/mathematics.md)

- [Quantitative Superexponential Bounds for van der Waerden Numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantitative-Superexponential-Bounds-for-van-der-Waerden-Numbers-September-23-2026/paper.pdf) · [individual note](papers/paper-81b18a4e8e665558.md)

### 161 · Counterexamples to Sidorenko’s conjecture and the forcing conjecture

Must a graph always appear at least as frequently as in a random graph of the same edge density?

[Explanation pane](families/161/explanation.md) · [Mathematical source pane](families/161/mathematics.md)

- [A counterexample to Sidorenko's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Sidorenkos-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-5e6ce4ba6e75683f.md)

### 162 · Counterexamples to Ryser’s covering conjecture

How many vertices are needed to meet every edge of an intersecting multipartite hypergraph?

[Explanation pane](families/162/explanation.md) · [Mathematical source pane](families/162/mathematics.md)

- [Balanced counterexamples to Ryser's conjecture at prime orders](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Balanced-Counterexamples-to-Rysers-Conjecture-at-Prime-Orders-September-27-2026/paper.pdf) · [individual note](papers/paper-1ac5642c24738b48.md)
- [A counterexample to Ryser's covering conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Rysers-Covering-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-dd14cd8c6a099634.md)

### 164 · Hindman’s finite sums and products conjecture

Does every finite coloring of the natural numbers contain an infinite set whose finite sums and products all have one color?

[Explanation pane](families/164/explanation.md) · [Mathematical source pane](families/164/mathematics.md)

- [Monochromatic finite sums and products in the positive integers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Monochromatic-finite-sums-and-products-in-the-positive-integers-September-23-2026/paper.pdf) · [individual note](papers/paper-f0e22ea0125d7f58.md)

### 165 · The Harary–Hill and Zarankiewicz crossing-number formulas

What is the minimum number of edge crossings needed to draw complete or complete bipartite graphs?

[Explanation pane](families/165/explanation.md) · [Mathematical source pane](families/165/mathematics.md)

- [The crossing number of complete graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-crossing-number-of-complete-graphs-September-23-2026/paper.pdf) · [individual note](papers/paper-077a49128e698aa5.md)
- [The crossing number of complete bipartite graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-crossing-number-of-complete-bipartite-graphs-September-23-2026/paper.pdf) · [individual note](papers/paper-b3a0451f0907bb67.md)

### 166 · The higher-dimensional Erdős distinct-distances conjecture

How few distinct pairwise distances can n points determine in a fixed higher-dimensional Euclidean space?

[Explanation pane](families/166/explanation.md) · [Mathematical source pane](families/166/mathematics.md)

- [The higher-dimensional Erdős distinct-distances conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-higher-dimensional-Erdos-distinct-distances-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-b016c6c67a7c9aa5.md)

### 167 · Planar distinct distances and unit-distance bounds

How few distinct distances, and how many equal-distance pairs, can a large planar point set have?

[Explanation pane](families/167/explanation.md) · [Mathematical source pane](families/167/mathematics.md)

- [The weak pinned planar distance theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-weak-pinned-planar-distance-theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-57aa9e22a0d59e9e.md)
- [A power saving for planar unit distances](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-planar-unit-distances-September-23-2026/paper.pdf) · [individual note](papers/paper-a50280244b598c59.md)

### 168 · Combinatorial invariance of Kazhdan–Lusztig polynomials

Are Kazhdan–Lusztig polynomials determined entirely by the combinatorics of their underlying order intervals?

[Explanation pane](families/168/explanation.md) · [Mathematical source pane](families/168/mathematics.md)

- [Combinatorial invariance of Kazhdan–Lusztig polynomials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Combinatorial-Invariance-of-Kazhdan-Lusztig-Polynomials-September-24-2026/paper.pdf) · [individual note](papers/paper-ff5b532b42178242.md)

### 169 · Shareshian–Wachs elementary positivity

Do certain graph-coloring symmetric functions expand with nonnegative coefficients in the elementary basis?

[Explanation pane](families/169/explanation.md) · [Mathematical source pane](families/169/mathematics.md)

- [Elementary positivity of chromatic quasisymmetric functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Elementary-Positivity-of-Chromatic-Quasisymmetric-Functions-September-24-2026/paper.pdf) · [individual note](papers/paper-9d0e411beb714fe4.md)

### 170 · Sharp logarithmic exponents for off-diagonal Ramsey numbers

How sharply can we estimate Ramsey numbers when one of the required monochromatic clique sizes is fixed?

[Explanation pane](families/170/explanation.md) · [Mathematical source pane](families/170/mathematics.md)

- [The sharp logarithmic exponent of r(5,t)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Sharp-Logarithmic-Exponent-of-r-5-t-September-24-2026/paper.pdf) · [individual note](papers/paper-18a63ab98aab5c73.md)
- [Sharp logarithmic exponents for fixed off-diagonal Ramsey numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-Logarithmic-Exponents-for-Fixed-Off-Diagonal-Ramsey-Numbers-September-24-2026/paper.pdf) · [individual note](papers/paper-3e6d3f180c806d78.md)

### 171 · The hypercube Ramsey conjecture

How large a complete graph forces a monochromatic copy of a high-dimensional hypercube?

[Explanation pane](families/171/explanation.md) · [Mathematical source pane](families/171/mathematics.md)

- [The hypercube Ramsey number has linear order](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-hypercube-Ramsey-number-has-linear-order-September-23-2026/paper.pdf) · [individual note](papers/paper-50aa1b3ee10eed4e.md)

### 172 · Classification of finite Euclidean Ramsey configurations

Which finite point patterns inevitably occur monochromatically in sufficiently high-dimensional Euclidean space?

[Explanation pane](families/172/explanation.md) · [Mathematical source pane](families/172/mathematics.md)

- [A classification of finite Euclidean Ramsey configurations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-classification-of-finite-Euclidean-Ramsey-configurations-September-23-2026/paper.pdf) · [individual note](papers/paper-55844238ba801f2e.md)

### 173 · Seymour’s second-neighborhood conjecture

Must every oriented graph contain a vertex with at least as many second neighbors as first neighbors?

[Explanation pane](families/173/explanation.md) · [Mathematical source pane](families/173/mathematics.md)

- [A proof of Seymour’s second-neighborhood conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-proof-of-Seymours-second-neighborhood-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-dc2fb20975a083ca.md)

### 174 · Deterministic construction of strong thin spanning trees

Can we efficiently construct a spanning tree that crosses every cut only a small fraction of the time?

[Explanation pane](families/174/explanation.md) · [Mathematical source pane](families/174/mathematics.md)

- [The strong thin tree conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-strong-thin-tree-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-402de1fcb7f04b26.md)
- [A polynomial-time construction of strong thin trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-polynomial-time-construction-of-strong-thin-trees-September-23-2026/paper.pdf) · [individual note](papers/paper-df23ae02b1b76555.md)

### 175 · Talagrand’s expectation thresholds, discrete convexity, and graph decompositions

Can local witness expectations predict global appearance thresholds and support strong decomposition results?

[Explanation pane](families/175/explanation.md) · [Mathematical source pane](families/175/mathematics.md)

- [Graph Decompositions at the Integral Expectation Threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Graph-Decompositions-at-the-Integral-Expectation-Threshold-October-5-2026/graph-threshold-decompositions.pdf) · [individual note](papers/paper-75ab7f2d7d717948.md)
- [Integral and fractional expectation thresholds are equivalent](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-and-fractional-expectation-thresholds-are-equivalent-September-23-2026/paper.pdf) · [individual note](papers/paper-0a3cd65e30e2efc7.md)
- [Talagrand’s discrete-convexity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Talagrands-discrete-convexity-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-97a18fbfcc9edc17.md)

### 176 · The second Kahn–Kalai conjecture with an edge-count bound

How close is a monotone graph property's expectation threshold to its actual random-graph threshold?

[Explanation pane](families/176/explanation.md) · [Mathematical source pane](families/176/mathematics.md)

- [The second Kahn–Kalai conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-second-Kahn-Kalai-conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-1baa84ed127f140c.md)

### 177 · Bounded-degree coboundary expanders

Can bounded-degree complexes have robust higher-dimensional expansion, analogous to well-connected sparse graphs?

[Explanation pane](families/177/explanation.md) · [Mathematical source pane](families/177/mathematics.md)

- [Bounded-degree coboundary expanders in every dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-degree-coboundary-expanders-in-every-dimension-September-24-2026/paper.pdf) · [individual note](papers/paper-1029f319b3e46860.md)

### 178 · Deterministic nonbipartite Ramanujan graphs in every fixed degree

Can optimal spectral expander graphs be explicitly constructed in every fixed degree without restricting to bipartite graphs?

[Explanation pane](families/178/explanation.md) · [Mathematical source pane](families/178/mathematics.md)

- [Deterministic nonbipartite Ramanujan graphs in every fixed degree](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deterministic-nonbipartite-Ramanujan-graphs-in-every-fixed-degree-September-23-2026/paper.pdf) · [individual note](papers/paper-c2e0035f6d20bb0c.md)

### 179 · The circulant Hadamard and Barker-sequence conjectures

Can highly symmetric plus/minus-one matrices or long binary sequences attain the conjectured perfect correlation patterns?

[Explanation pane](families/179/explanation.md) · [Mathematical source pane](families/179/mathematics.md)

- [The circulant Hadamard conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-circulant-Hadamard-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-25bab455cfc62825.md)

### 180 · Barnette’s Hamiltonian-cycle conjecture

Does every three-connected cubic bipartite planar graph have a cycle through every vertex?

[Explanation pane](families/180/explanation.md) · [Mathematical source pane](families/180/mathematics.md)

- [Paired states and Hamiltonian cycles in cubic bipartite planar graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Paired-states-and-Hamiltonian-cycles-in-cubic-bipartite-planar-graphs-September-24-2026/paper.pdf) · [individual note](papers/paper-ea3e29b3b62f3884.md)

### 181 · The Erdős–Gallai cycle-decomposition conjecture

Can the edges of every graph be decomposed into only linearly many cycles and single edges?

[Explanation pane](families/181/explanation.md) · [Mathematical source pane](families/181/mathematics.md)

- [A linear cycle-and-edge decomposition of every graph](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-linear-cycle-and-edge-decomposition-of-every-graph-September-24-2026/main.pdf) · [individual note](papers/paper-aa4a9f7b64d5fc71.md)

### 182 · Power savings for intersective polynomial differences and prime arguments

How strongly does avoiding differences given by polynomial values or primes limit the density of an integer set?

[Explanation pane](families/182/explanation.md) · [Mathematical source pane](families/182/mathematics.md)

- [A power saving for intersective polynomial differences with an exponent depending only on the degree](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-intersective-polynomial-differences-with-an-exponent-depending-only-on-the-degree-October-5-2026/power-saving-intersective-polynomial-differences.pdf) · [individual note](papers/paper-68fa5487b279ffb0.md)
- [A Power Saving for Polynomial Differences at Prime Arguments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Power-Saving-for-Polynomial-Differences-at-Prime-Arguments-October-5-2026/prime-argument-polynomial-differences.pdf) · [individual note](papers/paper-587f6de1195133cc.md)
- [A power saving for square-difference-free sets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-square-difference-free-sets-September-24-2026/paper.pdf) · [individual note](papers/paper-9c985fd7ca410900.md)

### 183 · Power savings for planar halving lines and k-sets

How many lines can nearly bisect a planar point set, or isolate exactly k points on one side?

[Explanation pane](families/183/explanation.md) · [Mathematical source pane](families/183/mathematics.md)

- [A power saving for planar halving lines](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-saving-for-planar-halving-lines-September-25-2026/main.pdf) · [individual note](papers/paper-b336bf8ad16e5436.md)

### 184 · Correspondence coloring with a fixed forbidden subgraph

How does forbidding one subgraph improve graph colorability when colors at neighboring vertices are linked by arbitrary correspondences?

[Explanation pane](families/184/explanation.md) · [Mathematical source pane](families/184/mathematics.md)

- [Correspondence coloring graphs with a forbidden clique](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Correspondence-Coloring-Graphs-with-a-Forbidden-Clique-October-5-2026/correspondence-coloring-forbidden-clique.pdf) · [individual note](papers/paper-39a104c4bd137a9a.md)
- [A logarithmic independence bound for clique-free graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Logarithmic-Independence-Bound-for-Clique-Free-Graphs-September-25-2026/paper.pdf) · [individual note](papers/paper-54f59aabd3bdaeb3.md)

### 185 · Counterexamples to infinite matroid intersection and packing/covering

Do familiar intersection and packing-covering principles for finite matroids remain valid for infinite matroids?

[Explanation pane](families/185/explanation.md) · [Mathematical source pane](families/185/mathematics.md)

- [A Counterexample to the Infinite Matroid Packing/Covering Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-the-Infinite-Matroid-Packing-Covering-Conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-8948bbcce83ba7e9.md)

### 186 · Uniform influence and sharp thresholds for graph and hypergraph properties

How strongly must at least one coordinate influence a symmetric graph property, and how narrow is its threshold window?

[Explanation pane](families/186/explanation.md) · [Mathematical source pane](families/186/mathematics.md)

- [A uniform influence bound for hypergraph properties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-uniform-influence-bound-for-hypergraph-properties-October-5-2026/hypergraph-influences.pdf) · [individual note](papers/paper-cb5d8113ca07381e.md)
- [A Sharp Threshold Bound for Monotone Graph Properties](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Sharp-Threshold-Bound-for-Monotone-Graph-Properties-September-25-2026/paper.pdf) · [individual note](papers/paper-f7e2f0a385b06707.md)

### 187 · Snaky in 21 Maker moves

How quickly can the first player force the Snaky pattern in the specified placement game?

[Explanation pane](families/187/explanation.md) · [Mathematical source pane](families/187/mathematics.md)

- [Snaky in 21 Maker moves](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Snaky-in-21-Maker-moves-September-25-2026/article.pdf) · [individual note](papers/paper-c7480306b38301a6.md)

### 188 · The sharp terminal leave in random triangle removal

When triangles are repeatedly deleted at random, how many edges remain when no triangle survives?

[Explanation pane](families/188/explanation.md) · [Mathematical source pane](families/188/mathematics.md)

- [The sharp terminal leave in random triangle removal](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Sharp-Terminal-Leave-in-Random-Triangle-Removal-September-25-2026/The-Sharp-Terminal-Leave-in-Random-Triangle-Removal-September-25-2026.pdf) · [individual note](papers/paper-3d59f13f48c769b7.md)

### 189 · Cycle–clique Ramsey numbers

How large a complete graph forces either a monochromatic cycle or a monochromatic clique?

[Explanation pane](families/189/explanation.md) · [Mathematical source pane](families/189/mathematics.md)

- [Cycle--clique Ramsey numbers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cycle-clique-Ramsey-numbers-September-25-2026/Cycle-clique-Ramsey-numbers-September-25-2026.pdf) · [individual note](papers/paper-4da79009900807be.md)

### 190 · Polynomial removal fails for ordered binary matrices

Can removing every forbidden pattern from an ordered binary matrix require more than polynomial dependence on pattern density?

[Explanation pane](families/190/explanation.md) · [Mathematical source pane](families/190/mathematics.md)

- [Polynomial removal fails for ordered binary matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-removal-fails-for-ordered-binary-matrices-September-25-2026/paper.pdf) · [individual note](papers/paper-6456af5a1db59e32.md)

### 191 · A power improvement in the Heilbronn triangle lower bound

How can n points in a unit region be arranged so that their smallest triangle has as large an area as possible?

[Explanation pane](families/191/explanation.md) · [Mathematical source pane](families/191/mathematics.md)

- [A power improvement in the Heilbronn triangle lower bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-power-improvement-in-the-Heilbronn-triangle-lower-bound-September-25-2026/main.pdf) · [individual note](papers/paper-0f76d582cea5b698.md)

### 192 · Boolean functions violate the square-root degree bound by arbitrary factors

How far can Boolean-function sensitivity exceed a bound suggested by the square root of polynomial degree?

[Explanation pane](families/192/explanation.md) · [Mathematical source pane](families/192/mathematics.md)

- [Unbounded Violations of the Square-Root Degree Bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unbounded-Violations-of-the-Square-Root-Degree-Bound-September-26-2026/Unbounded-Violations-of-the-Square-Root-Degree-Bound-September-26-2026.pdf) · [individual note](papers/paper-2d51b23708e7ed92.md)

## Algebra

### 193 · Serre’s intersection-multiplicity conjecture

Are local intersection multiplicities positive whenever two algebraic objects meet in complementary dimensions?

[Explanation pane](families/193/explanation.md) · [Mathematical source pane](families/193/mathematics.md)

- [Positivity of Serre's Intersection Multiplicity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positivity-of-Serres-Intersection-Multiplicity-September-23-2026/paper.pdf) · [individual note](papers/paper-46e74710c1076053.md)

### 194 · Lech’s multiplicity conjecture

How does the multiplicity of a local algebra change under a flat extension?

[Explanation pane](families/194/explanation.md) · [Mathematical source pane](families/194/mathematics.md)

- [Lech's multiplicity conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lechs-multiplicity-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-18bb880a24f980dc.md)

### 195 · A counterexample to the small Cohen–Macaulay module conjecture

Must every suitable local ring admit a small module with the strongest expected depth properties?

[Explanation pane](families/195/explanation.md) · [Mathematical source pane](families/195/mathematics.md)

- [A Complete Local Domain without a Small Cohen–Macaulay Module](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Complete-Local-Domain-Without-a-Small-Cohen-Macaulay-Module-September-23-2026/paper.pdf) · [individual note](papers/paper-72b09de8e10f8ce3.md)

### 196 · A counterexample to Kaplansky’s zero-divisor conjecture

Can the group algebra of a torsion-free group contain nonzero elements whose product is zero?

[Explanation pane](families/196/explanation.md) · [Mathematical source pane](families/196/mathematics.md)

- [A Torsion-Free Group Algebra with Zero Divisors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Group-Algebra-with-Zero-Divisors-September-23-2026/paper.pdf) · [individual note](papers/paper-3d6fa1dbaf31b181.md)

### 197 · A torsion-free group algebra that is not directly finite

In a torsion-free group algebra, must a one-sided inverse automatically be a two-sided inverse?

[Explanation pane](families/197/explanation.md) · [Mathematical source pane](families/197/mathematics.md)

- [A Torsion-Free Group Algebra That Is Not Directly Finite](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Group-Algebra-That-Is-Not-Directly-Finite-October-4-2026/direct-finiteness.pdf) · [individual note](papers/paper-345f7e9b9150755c.md)
- [A Counterexample to Kaplansky's Direct-Finiteness Conjecture in Characteristic Two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Kaplanskys-Direct-Finiteness-Conjecture-in-Characteristic-Two-September-23-2026/paper.pdf) · [individual note](papers/paper-34b2f8e35027379e.md)
- [A Counterexample to the Group-Ring Determinant Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-the-Group-Ring-Determinant-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-c7046a24a22e252a.md)
- [A Counterexample to Kaplansky's Direct-Finiteness Conjecture in Odd Characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Kaplanskys-Direct-Finiteness-Conjecture-in-Odd-Characteristic-September-26-2026/paper.pdf) · [individual note](papers/paper-38f71c7af6b006e9.md)

### 198 · A counterexample to finitistic-dimension finiteness

Must finite projective resolutions over a finite-dimensional algebra have a uniformly bounded maximum length?

[Explanation pane](families/198/explanation.md) · [Mathematical source pane](families/198/mathematics.md)

- [An algebra of infinite little finitistic dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-algebra-of-infinite-little-finitistic-dimension-September-23-2026/paper.pdf) · [individual note](papers/paper-315560cf0726c894.md)

### 199 · Counterexamples to Auslander–Reiten, Tachikawa and related homological conjectures

Do vanishing self-extension conditions force a module or algebra to have the predicted projective or injective structure?

[Explanation pane](families/199/explanation.md) · [Mathematical source pane](families/199/mathematics.md)

- [An explicit counterexample to the Auslander-Reiten conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-counterexample-to-the-Auslander-Reiten-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-79581b711f50a64d.md)
- [A counterexample to Tachikawa's second conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Tachikawas-second-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-ba058fe207bc26ec.md)

### 200 · Eisenbud–Green–Harris and lex-plus-powers

Can Hilbert functions of ideals containing regular sequences always be matched by specially ordered monomial ideals?

[Explanation pane](families/200/explanation.md) · [Mathematical source pane](families/200/mathematics.md)

- [The Artinian Lex-Plus-Powers Betti Theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Artinian-Lex-Plus-Powers-Betti-Theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-0752e6125087fff2.md)
- [Commuting Division-Coefficient Forms and the Artinian Eisenbud--Green--Harris Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Commuting-Division-Coefficient-Forms-and-the-Artinian-Eisenbud-Green-Harris-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-38092584f7c33b6a.md)

### 201 · A counterexample to Kurosh’s division-ring problem

Must a finitely generated algebraic division ring be finite-dimensional over its center?

[Explanation pane](families/201/explanation.md) · [Mathematical source pane](families/201/mathematics.md)

- [A Counterexample to Kurosh’s Division-Ring Problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Kuroshs-Division-Ring-Problem-September-23-2026/paper.pdf) · [individual note](papers/paper-1f62bc13ebf9e745.md)

### 202 · The blockwise Alperin weight conjecture

Can irreducible representations in modular blocks be counted through the appropriate local weight data?

[Explanation pane](families/202/explanation.md) · [Mathematical source pane](families/202/mathematics.md)

- [The Blockwise Alperin Weight Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Blockwise-Alperin-Weight-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-838b0669ed0f6a89.md)

### 203 · Donovan's conjecture over fields and complete mixed-characteristic DVRs

For a fixed defect group, are there only finitely many essential types of modular representation blocks?

[Explanation pane](families/203/explanation.md) · [Mathematical source pane](families/203/mathematics.md)

- [Donovan's Conjecture over Algebraically Closed Fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Donovans-Conjecture-over-Algebraic-Closures-of-Prime-Fields-September-24-2026/main.pdf) · [individual note](papers/paper-f3253c6ba2a6d7d5.md)
- [Integral Donovan Finiteness over Witt Vectors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Integral-Donovan-Finiteness-over-Witt-Vectors-September-25-2026/main.pdf) · [individual note](papers/paper-6dd4e927f0310535.md)

### 204 · Tensor saturation for even spin groups

If a representation occurs after stretching all highest weights, when must it already occur before stretching?

[Explanation pane](families/204/explanation.md) · [Mathematical source pane](families/204/mathematics.md)

- [Tensor saturation for even spin groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026/Tensor-Saturation-for-Even-Spin-Groups-September-24-2026.pdf) · [individual note](papers/paper-3f8d6dbdc1108af3.md)

### 205 · Saxl’s conjecture and universal tensor squares

Does the tensor square of a staircase representation contain every irreducible representation of the relevant symmetric group?

[Explanation pane](families/205/explanation.md) · [Mathematical source pane](families/205/mathematics.md)

- [Universal Tensor Squares for Symmetric Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-Tensor-Squares-for-Symmetric-Groups-September-24-2026/main.pdf) · [individual note](papers/paper-b50343a2ec8d5fb9.md)
- [A Cyclic Polytabloid Proof of Saxl's Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Cyclic-Polytabloid-Proof-of-Saxls-Conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-1ae49d454fec628f.md)

### 206 · Finite lattice representation and undecidability

Can every finite lattice arise from congruences of a finite algebra, and can that realization question be decided algorithmically?

[Explanation pane](families/206/explanation.md) · [Mathematical source pane](families/206/mathematics.md)

- [Finite congruence lattices: characterization and undecidability](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Congruence-Lattices-Characterization-and-Undecidability-September-24-2026/paper.pdf) · [individual note](papers/paper-815639a1968248ca.md)
- [A negative solution to the finite lattice representation problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Negative-Solution-to-the-Finite-Lattice-Representation-Problem-September-24-2026/paper.pdf) · [individual note](papers/paper-c3c2c749a8b85b08.md)

### 207 · The ℓ¹-Bass conjecture for all discrete groups

Do traces associated with group-ring projective modules vanish outside the predicted conjugacy classes?

[Explanation pane](families/207/explanation.md) · [Mathematical source pane](families/207/mathematics.md)

- [The ℓ¹-Bass Conjecture for Discrete Groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-l1-Bass-Conjecture-for-Discrete-Groups-October-5-2026/l1-bass-conjecture.pdf) · [individual note](papers/paper-a3fd00f07c325ccc.md)
- [The Bass trace conjecture and the characteristic-zero Kaplansky idempotent conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Bass-trace-conjecture-for-complex-group-rings-September-24-2026/The-Bass-trace-conjecture-for-complex-group-rings-September-24-2026.pdf) · [individual note](papers/paper-6207799c710c8652.md)

### 208 · Finite symmetric tensor categories and the Verlinde tower

How can finite symmetric tensor categories in positive characteristic be classified using Verlinde-type structures?

[Explanation pane](families/208/explanation.md) · [Mathematical source pane](families/208/mathematics.md)

- [Fiber functors for finite symmetric tensor categories in positive characteristic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fiber-functors-for-finite-symmetric-tensor-categories-in-positive-characteristic-September-24-2026/paper.pdf) · [individual note](papers/paper-ced36e9f9f1df495.md)

### 209 · Integral counterexamples to Gersten’s conjecture

Does the expected exactness of algebraic K-theory along a regular local space always survive integrally?

[Explanation pane](families/209/explanation.md) · [Mathematical source pane](families/209/mathematics.md)

- [An integral counterexample to Gersten's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026/An-Integral-Counterexample-to-Gerstens-Conjecture-September-25-2026.pdf) · [individual note](papers/paper-c0b9fdf6093b01fe.md)
- [An integral degree-three Gersten counterexample](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Integral-Degree-Three-Gersten-Counterexample-September-26-2026/paper.pdf) · [individual note](papers/paper-2f448c5a4c2a25ac.md)

### 210 · Foulkes' conjecture for sixth powers and quadratic stabilization

Which way do multiplicities compare when two symmetric-power operations are applied in opposite orders?

[Explanation pane](families/210/explanation.md) · [Mathematical source pane](families/210/mathematics.md)

- [Foulkes' conjecture for the sixth symmetric power](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Foulkes-Conjecture-for-the-Sixth-Symmetric-Power-September-25-2026/main.pdf) · [individual note](papers/paper-9f896285de4d3e8c.md)
- [Quadratic stabilization of the canonical Foulkes--Howe map](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quadratic-Stabilization-of-the-Canonical-Foulkes-Howe-Map-September-25-2026/paper.pdf) · [individual note](papers/paper-9116fddf103144d4.md)

## Probability and statistical mechanics

### 211 · The geometric phase diagram, diffusion, and spectra of random planar maps

What large-scale geometry, diffusion, and spectral behavior emerges from a randomly generated planar map?

[Explanation pane](families/211/explanation.md) · [Mathematical source pane](families/211/mathematics.md)

- [Random Walks on Critical FK–Ising Maps and Liouville Brownian Motion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-Walks-on-Critical-FK-Ising-Maps-and-Liouville-Brownian-Motion-October-5-2026/fk-ising-walk-limit.pdf) · [individual note](papers/paper-54124ba8a3aa7f14.md)
- [Spectral convergence for critical FK–Ising planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spectral-convergence-for-critical-FK-Ising-planar-maps-October-5-2026/spectral-convergence-critical-fk-ising-planar-maps.pdf) · [individual note](papers/paper-7b019d8a67510f29.md)
- [A Linear Clock for Random Walk on Tree-Weighted Planar Maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Linear-Clock-for-Random-Walk-on-Tree-Weighted-Planar-Maps-October-5-2026/linear-clock-random-walk-tree-weighted-planar-maps.pdf) · [individual note](papers/paper-69d43feceb95984a.md)
- [Canonical conformal limits of subcritical FK planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Canonical-conformal-limits-of-subcritical-FK-planar-maps-September-24-2026/main.pdf) · [individual note](papers/paper-6b60070a1f1264f1.md)
- [The critical Liouville quantum sphere and geometric limits of FK maps at q=4](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-Liouville-quantum-sphere-and-geometric-limits-of-FK-maps-at-q-equals-4-September-24-2026/main.pdf) · [individual note](papers/paper-d48dbb2784c3b335.md)
- [Metric-measure limits of subcritical FK and spanning-tree planar maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-measure-limits-of-subcritical-FK-and-spanning-tree-planar-maps-September-24-2026/main.pdf) · [individual note](papers/paper-b64da66738135f38.md)
- [Brownian continuum random tree limits of finite Fortuin–Kasteleyn maps above four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Brownian-continuum-random-tree-limits-of-finite-Fortuin-Kasteleyn-maps-above-four-September-24-2026/main.pdf) · [individual note](papers/paper-6cd400ca66893442.md)

### 212 · Planar first-passage geometry and the absence of bigeodesics

In a random travel-time landscape, how do optimal routes behave, and can an optimal route extend infinitely in both directions?

[Explanation pane](families/212/explanation.md) · [Mathematical source pane](families/212/mathematics.md)

- [No bigeodesics in planar first-passage percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/No-bigeodesics-in-planar-first-passage-percolation-September-24-2026/main.pdf) · [individual note](papers/paper-851efc97fc7a0a30.md)
- [Strict convexity and differentiability of the planar exponential first-passage limit shape](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strict-convexity-and-differentiability-of-the-planar-exponential-first-passage-limit-shape-September-24-2026/main.pdf) · [individual note](papers/paper-4caff5b90a9e86e5.md)

### 213 · Critical percolation on every quasi-transitive graph

What happens exactly at the percolation threshold on every graph with finitely many vertex types?

[Explanation pane](families/213/explanation.md) · [Mathematical source pane](families/213/mathematics.md)

- [Critical bond and site percolation on the cubic lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-bond-and-site-percolation-on-the-cubic-lattice-September-24-2026/paper.pdf) · [individual note](papers/paper-e39276f15ac5f938.md)
- [No percolation at criticality on quasi-transitive graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/No-percolation-at-criticality-on-quasi-transitive-graphs-September-24-2026/paper.pdf) · [individual note](papers/paper-f82b2664889e4ea4.md)

### 214 · The Benjamini–Schramm nonuniqueness conjecture

On nonamenable graphs, must there be a regime with infinitely many infinite percolation clusters?

[Explanation pane](families/214/explanation.md) · [Mathematical source pane](families/214/mathematics.md)

- [Nonuniqueness of percolation on nonamenable quasi-transitive graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonuniqueness-of-percolation-on-nonamenable-quasi-transitive-graphs-September-24-2026/paper.pdf) · [individual note](papers/paper-18e943ed19efd895.md)

### 215 · Canonical $O(3)$ continuum limit and exact $O(4)$ mass asymptotics

How do lattice spin models with rotational symmetry approach a continuum field theory, and how precisely does their mass scale behave?

[Explanation pane](families/215/explanation.md) · [Mathematical source pane](families/215/mathematics.md)

- [The canonical massive continuum limit of the two-dimensional O(3) model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-canonical-massive-continuum-limit-of-the-two-dimensional-O3-model-October-4-2026/massive-continuum-o3.pdf) · [individual note](papers/paper-0d60466ce4e43fdf.md)
- [An Isolated Particle Pole for the Two-Dimensional O(3) Spin Field](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Isolated-Particle-Pole-for-the-Two-Dimensional-O3-Spin-Field-October-4-2026/o3-particle-pole.pdf) · [individual note](papers/paper-e46fa1bf299d3419.md)
- [Exact mass asymptotics for the two-dimensional O(4) lattice model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-mass-asymptotics-for-the-two-dimensional-O4-lattice-model-October-5-2026/exact-mass-o4.pdf) · [individual note](papers/paper-609796b35407dd28.md)
- [Sharp mass bounds for the two-dimensional O(4) model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-mass-bounds-for-the-two-dimensional-O4-model-September-23-2026/paper.pdf) · [individual note](papers/paper-f43e04e25b034592.md)
- [Exponential decay in two-dimensional classical O(n) models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exponential-decay-in-two-dimensional-classical-On-models-September-23-2026/paper.pdf) · [individual note](papers/paper-97174ff47fee09c3.md)

### 216 · Critical and near-critical XY scaling and BKT universality

Do XY-type spin systems share the same critical and near-critical scaling laws across the BKT transition?

[Explanation pane](families/216/explanation.md) · [Mathematical source pane](families/216/mathematics.md)

- [The critical logarithmic correction for the planar XY model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-logarithmic-correction-for-the-planar-XY-model-October-5-2026/paper.pdf) · [individual note](papers/paper-318a07a53719b3a5.md)
- [Critical Center Magnetization in the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-Center-Magnetization-in-the-Planar-XY-Model-October-5-2026/paper.pdf) · [individual note](papers/paper-6b00b1a0e376ebcf.md)
- [The Critical Spin Field of the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Critical-Spin-Field-of-the-Planar-XY-Model-October-5-2026/paper.pdf) · [individual note](papers/paper-483a06ae4d3057dc.md)
- [Essential Singularity of the Correlation Length in the Planar XY Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Essential-Singularity-of-the-Correlation-Length-in-the-Planar-XY-Model-October-5-2026/paper.pdf) · [individual note](papers/paper-962f604458daf1ec.md)
- [The critical correlation exponent of the planar XY model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-correlation-exponent-of-the-planar-XY-model-September-24-2026/paper.pdf) · [individual note](papers/paper-a34c8660383ba2f6.md)
- [BKT universality for height and planar spin fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/BKT-universality-for-height-and-planar-spin-fields-September-24-2026/paper.pdf) · [individual note](papers/paper-2bb16506fb56b312.md)

### 217 · The low-temperature Sherrington–Kirkpatrick fluctuation law

What is the limiting distribution of free-energy fluctuations in a low-temperature mean-field spin glass?

[Explanation pane](families/217/explanation.md) · [Mathematical source pane](families/217/mathematics.md)

- [The low-temperature Sherrington–Kirkpatrick free-energy limiting law](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-low-temperature-Sherrington-Kirkpatrick-free-energy-limiting-law-September-24-2026/The-low-temperature-Sherrington-Kirkpatrick-free-energy-limiting-law-September-24-2026.pdf) · [individual note](papers/paper-5f785902249adfa9.md)
- [The low-temperature Sherrington–Kirkpatrick fluctuation scale](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-low-temperature-Sherrington-Kirkpatrick-fluctuation-scale-September-24-2026/The-low-temperature-Sherrington-Kirkpatrick-fluctuation-scale-September-24-2026.pdf) · [individual note](papers/paper-d80587de7e1d2ca7.md)

### 218 · Conformal universality for weakly interacting and random-bond Ising models

Does the critical Ising scaling limit remain conformally universal when weak interactions or random bonds are added?

[Explanation pane](families/218/explanation.md) · [Mathematical source pane](families/218/mathematics.md)

- [Quenched SLE₃ limits for general weak random-bond Ising models](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE3-limits-for-general-weak-random-bond-Ising-models-October-5-2026/general-weak-random-bond-ising.pdf) · [individual note](papers/paper-f6b2768105c15b7b.md)
- [Quenched SLE₃ Universality for the Weak Random-Bond Ising Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE3-Universality-for-the-Weak-Random-Bond-Ising-Model-October-5-2026/quenched-sle3-weak-random-bond-ising.pdf) · [individual note](papers/paper-9b924b24ced69e92.md)
- [Logarithmic Relative Fluctuations in the Weakly Disordered Planar Ising Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Logarithmic-Relative-Fluctuations-in-the-Weakly-Disordered-Planar-Ising-Model-October-5-2026/critical-relative-second-moment-weak-random-bond-ising.pdf) · [individual note](papers/paper-55ccdb521eb4808b.md)
- [Conformal universality of bulk Ising correlations under weak interactions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-universality-of-bulk-Ising-correlations-under-weak-interactions-September-23-2026/paper.pdf) · [individual note](papers/paper-526dfb9118d25ec2.md)
- [SLE3 universality for weak finite-range Ising interactions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/SLE3-universality-for-weak-finite-range-Ising-interactions-September-23-2026/paper.pdf) · [individual note](papers/paper-2b234feb92a2c9ca.md)
- [Buffered comparison and stopping-band resolution in critical Ising](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Buffered-comparison-and-stopping-band-resolution-in-critical-Ising-September-23-2026/paper.pdf) · [individual note](papers/paper-2af5567ba4041e1e.md)

### 219 · GOE bulk universality for regular graphs with weak Anderson disorder

Do disordered regular-graph Hamiltonians have the universal local eigenvalue statistics predicted by random-matrix theory?

[Explanation pane](families/219/explanation.md) · [Mathematical source pane](families/219/mathematics.md)

- [Fixed-energy universality for weak Anderson disorder on random regular graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fixed-energy-universality-for-weak-Anderson-disorder-on-random-regular-graphs-October-5-2026/fixed-energy-universality-weak-anderson-disorder-random-regular-graphs.pdf) · [individual note](papers/paper-0730226000ea3fe5.md)
- [GOE bulk universality for fixed-degree random regular graphs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/GOE-bulk-universality-for-fixed-degree-random-regular-graphs-September-23-2026/paper.pdf) · [individual note](papers/paper-ed95e96eb1dd9550.md)

### 220 · Directional zero–one laws beyond iid environments and iid ballisticity

Must a random walk in a random environment eventually choose a direction, and when does it acquire positive speed?

[Explanation pane](families/220/explanation.md) · [Mathematical source pane](families/220/mathematics.md)

- [A directional zero–one law for finite-range-dependent random environments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-directional-zero-one-law-for-finite-range-dependent-random-environments-October-5-2026/directional-zero-one-finite-range.pdf) · [individual note](papers/paper-7f151483b202acc9.md)
- [A directional zero–one law under strict ellipticity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-directional-zero-one-law-under-strict-ellipticity-September-23-2026/paper.pdf) · [individual note](papers/paper-b641f210bbf49e8d.md)
- [Directional transience implies ballisticity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Directional-transience-implies-ballisticity-September-23-2026/paper.pdf) · [individual note](papers/paper-e372ffc986a23c4a.md)

### 221 · The Mézard–Parisi formula for diluted spin glasses

Can the free energy of a sparse spin glass be computed from the predicted hierarchical statistical-mechanical formula?

[Explanation pane](families/221/explanation.md) · [Mathematical source pane](families/221/mathematics.md)

- [The Mézard–Parisi formula for diluted spin glasses](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Mezard-Parisi-formula-for-diluted-spin-glasses-September-23-2026/paper.pdf) · [individual note](papers/paper-a551af11ad89fbac.md)

### 222 · Perceptron free energies and microscopic jamming exponents

What is the exact thermodynamics of a random perceptron, and how do configurations behave near jamming?

[Explanation pane](families/222/explanation.md) · [Mathematical source pane](families/222/mathematics.md)

- [The free energy of the Ising random perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-energy-of-the-Ising-random-perceptron-September-24-2026/The-free-energy-of-the-Ising-random-perceptron-September-24-2026.pdf) · [individual note](papers/paper-e866f9588a041b7a.md)
- [Microscopic jamming in the negative spherical perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Microscopic-jamming-in-the-negative-spherical-perceptron-September-24-2026/Microscopic-jamming-in-the-negative-spherical-perceptron-September-24-2026.pdf) · [individual note](papers/paper-8b82a915c4c2088c.md)
- [The spherical perceptron with bi-orthogonally invariant disorder](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-spherical-perceptron-with-bi-orthogonally-invariant-disorder-September-24-2026/The-spherical-perceptron-with-bi-orthogonally-invariant-disorder-September-24-2026.pdf) · [individual note](papers/paper-16aec61f81be576e.md)
- [The free energy of the spherical random perceptron](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-energy-of-the-spherical-random-perceptron-September-24-2026/The-free-energy-of-the-spherical-random-perceptron-September-24-2026.pdf) · [individual note](papers/paper-09751fc7a74572be.md)

### 223 · Random-cluster interfaces: critical, disordered, thermal, and natural-time scaling

How do cluster boundaries converge to continuum random curves under criticality, disorder, and temperature perturbations?

[Explanation pane](families/223/explanation.md) · [Mathematical source pane](families/223/mathematics.md)

- [Square-lattice FK interfaces and nested loops for 1 <= q < 4](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Square-lattice-FK-interfaces-and-nested-loops-for-1-leq-q-lt-4-September-23-2026/paper.pdf) · [individual note](papers/paper-686250730b568ad0.md)
- [Self-dual random-cluster interfaces below one](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Self-dual-random-cluster-interfaces-below-one-September-23-2026/paper.pdf) · [individual note](papers/paper-79dbe4d2f6e63e7f.md)
- [Quenched SLE Universality for Weakly Disordered FK–Ising Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quenched-SLE-Universality-for-Weakly-Disordered-FK-Ising-Interfaces-October-5-2026/quenched-fk-ising.pdf) · [individual note](papers/paper-9b38b1f771e99826.md)
- [Thermal FK–Ising interfaces and massive SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thermal-FK-Ising-interfaces-and-massive-SLE-October-5-2026/paper.pdf) · [individual note](papers/paper-37e973b9fd918be1.md)
- [Natural Occupation Measures for Critical Square-Lattice FK Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Natural-Occupation-Measures-for-Critical-Square-Lattice-FK-Interfaces-October-5-2026/natural-occupation-measures-critical-square-lattice-fk-interfaces.pdf) · [individual note](papers/paper-4a539d16cc366897.md)
- [Conformal Limits of Critical Square-Lattice Random-Cluster Interfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-Limits-of-Critical-Square-Lattice-Random-Cluster-Interfaces-October-5-2026/paper.pdf) · [individual note](papers/paper-e14c444fd0ddcbd8.md)

### 224 · Critical and quenched near-critical universality for Poisson–Voronoi percolation

Does random Voronoi percolation have the same universal continuum behavior as standard planar percolation, even near criticality?

[Explanation pane](families/224/explanation.md) · [Mathematical source pane](families/224/mathematics.md)

- [From critical crossings to quenched near-critical universality in Voronoi percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-critical-crossings-to-quenched-near-critical-universality-in-Voronoi-percolation-October-5-2026/critical-crossings-quenched-near-critical-universality-voronoi-percolation.pdf) · [individual note](papers/paper-b0b29e21115b0472.md)
- [A Pivotal Amplitude for Voronoi Percolation from Cardy's Formula](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Pivotal-Amplitude-for-Voronoi-Percolation-from-Cardys-Formula-October-5-2026/voronoi-pivotal-amplitude.pdf) · [individual note](papers/paper-3ec0af99e46668cc.md)
- [Cardy’s formula for critical Poisson–Voronoi percolation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cardys-formula-for-critical-Poisson-Voronoi-percolation-September-23-2026/paper.pdf) · [individual note](papers/paper-6df5f15a9d19a90c.md)

### 225 · Gaussian free field limits throughout the balanced six-vertex regime

When does the large-scale height field of a six-vertex lattice model become a Gaussian free field?

[Explanation pane](families/225/explanation.md) · [Mathematical source pane](families/225/mathematics.md)

- [The Gaussian free field limit of the balanced six-vertex model with variance multiplier 1/arcsin(c/2)](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026/The-Gaussian-free-field-limit-of-the-balanced-six-vertex-model-with-variance-multiplier-1-over-arcsin-c-over-2-September-23-2026.pdf) · [individual note](papers/paper-d4093b0a57d654c1.md)

### 226 · The double-dimer loop ensemble converges to CLE_{4}

Do loops formed by superposing two random dimer coverings converge to the conformal loop ensemble CLE4?

[Explanation pane](families/226/explanation.md) · [Mathematical source pane](families/226/mathematics.md)

- [The curve scaling limit of half-plane double dimers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-curve-scaling-limit-of-half-plane-double-dimers-September-23-2026/paper.pdf) · [individual note](papers/paper-1c505cc4d7be22bd.md)

### 227 · Critical SK autocorrelation processes and dynamics across the temperature transition

How does spin autocorrelation evolve at and across the critical temperature of a mean-field spin glass?

[Explanation pane](families/227/explanation.md) · [Mathematical source pane](families/227/mathematics.md)

- [Universality of critical quench autocorrelations in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universality-of-critical-quench-autocorrelations-in-the-Sherrington-Kirkpatrick-model-October-5-2026/main.pdf) · [individual note](papers/paper-99d1b2540dbd7300.md)
- [Functional universality of critical SK autocorrelations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Functional-universality-of-critical-SK-autocorrelations-October-5-2026/critical-sk-autocorrelations.pdf) · [individual note](papers/paper-82d889f640f732c5.md)
- [A spectral gap throughout the high-temperature Sherrington–Kirkpatrick phase](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-spectral-gap-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/main.pdf) · [individual note](papers/paper-c5a80d7e80833383.md)
- [Cutoff throughout the high-temperature Sherrington–Kirkpatrick phase](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cutoff-throughout-the-high-temperature-Sherrington-Kirkpatrick-phase-September-24-2026/paper.pdf) · [individual note](papers/paper-5a1b81f875948a0f.md)
- [Critical slowing down in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-slowing-down-in-the-Sherrington-Kirkpatrick-model-September-24-2026/paper.pdf) · [individual note](papers/paper-616b3348b753182b.md)
- [Stretched-exponential barriers for typical SK initial states](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stretched-exponential-barriers-for-typical-SK-initial-states-September-24-2026/paper.pdf) · [individual note](papers/paper-ae9d6f4731a499b2.md)
- [A typical-start upper bound for low-temperature SK Glauber dynamics](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-typical-start-upper-bound-for-low-temperature-SK-Glauber-dynamics-September-24-2026/paper.pdf) · [individual note](papers/paper-5a30fcdc25b27faa.md)
- [Critical mixing in the Sherrington–Kirkpatrick model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-mixing-in-the-Sherrington-Kirkpatrick-model-September-25-2026/paper.pdf) · [individual note](papers/paper-ae7b730a28a3b97b.md)

### 228 · Continuum phase transitions for radial pair potentials

Which radial particle interactions produce genuine continuum phase transitions?

[Explanation pane](families/228/explanation.md) · [Mathematical source pane](families/228/mathematics.md)

- [A continuum temperature singularity for a radial pair potential](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-continuum-temperature-singularity-for-a-radial-pair-potential-September-24-2026/paper.pdf) · [individual note](papers/paper-51c7ee2f0a2eb0e6.md)
- [A radial continuum phase transition with algebraic decay](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-radial-continuum-phase-transition-with-algebraic-decay-September-24-2026/paper.pdf) · [individual note](papers/paper-602393349a821743.md)

### 229 · Exact three- and four-state reconstruction thresholds and four-state tree capacity

When can information sent down a noisy branching tree still be reconstructed at the root?

[Explanation pane](families/229/explanation.md) · [Mathematical source pane](families/229/mathematics.md)

- [The Reconstruction Threshold for the Ferromagnetic Four-State Potts Model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Reconstruction-Threshold-for-the-Ferromagnetic-Four-State-Potts-Model-October-5-2026/four-state-potts.pdf) · [individual note](papers/paper-6f02d37a7ba80c5f.md)
- [A Capacity Criterion for Four-State Potts Reconstruction on Trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Capacity-Criterion-for-Four-State-Potts-Reconstruction-on-Trees-October-5-2026/four-state-capacity.pdf) · [individual note](papers/paper-487751468997efee.md)
- [The exact reconstruction threshold for the three-state symmetric channel](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-exact-reconstruction-threshold-for-the-three-state-symmetric-channel-September-25-2026/paper.pdf) · [individual note](papers/paper-678d3715cd69b71c.md)

### 230 · Exact Hausdorff gauges for SLE

What is the exact small-scale measure needed to assign finite nonzero size to an SLE random curve?

[Explanation pane](families/230/explanation.md) · [Mathematical source pane](families/230/mathematics.md)

- [An exact Hausdorff gauge for SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-exact-Hausdorff-gauge-for-SLE-September-25-2026/An-exact-Hausdorff-gauge-for-SLE-September-25-2026.pdf) · [individual note](papers/paper-595b167a5f0195a9.md)
- [An explicit exact Hausdorff gauge for SLE](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-exact-Hausdorff-gauge-for-SLE-September-26-2026/An-explicit-exact-Hausdorff-gauge-for-SLE-September-26-2026.pdf) · [individual note](papers/paper-74027cb9996b8ae9.md)

### 231 · The free uniform spanning forest is a factor of IID

Can a random spanning forest be generated from independent random labels by a symmetry-respecting local rule?

[Explanation pane](families/231/explanation.md) · [Mathematical source pane](families/231/mathematics.md)

- [The free uniform spanning forest is a factor of IID](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-free-uniform-spanning-forest-is-a-factor-of-IID-September-25-2026/The-free-uniform-spanning-forest-is-a-factor-of-IID-September-25-2026.pdf) · [individual note](papers/paper-d7fb1e01136d8684.md)

### 232 · Gaussian fields and interfaces for triangular-lattice Lipschitz heights

Do constrained lattice height surfaces and their boundaries converge to Gaussian fields and conformal random curves?

[Explanation pane](families/232/explanation.md) · [Mathematical source pane](families/232/mathematics.md)

- [Gaussian free-field limits of weighted integer Lipschitz heights](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Gaussian-free-field-limits-of-weighted-integer-Lipschitz-heights-October-6-2026/paper.pdf) · [individual note](papers/paper-189e926318245c9b.md)
- [The Gaussian free field limit of integer Lipschitz heights with two-arc boundary data](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Gaussian-free-field-limit-of-integer-Lipschitz-heights-with-two-arc-boundary-data-October-6-2026/paper.pdf) · [individual note](papers/paper-e1e49bdf24ad73ed.md)
- [Uniform real Lipschitz surfaces on the triangular lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-real-Lipschitz-surfaces-on-the-triangular-lattice-October-6-2026/paper.pdf) · [individual note](papers/paper-5f4afcf42c4ee82a.md)

### 233 · The joint critical Ashkin–Teller current limit

What joint continuum random field is produced by critical currents in the coupled Ashkin–Teller model?

[Explanation pane](families/233/explanation.md) · [Mathematical source pane](families/233/mathematics.md)

- [The joint scaling limit of critical Ashkin-Teller currents](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-joint-scaling-limit-of-critical-Ashkin-Teller-currents-October-6-2026/main.pdf) · [individual note](papers/paper-c4b96c96c5f07cf2.md)

### 234 · All-temperature pressure of orthogonally invariant Ising spin glasses

Can the limiting free energy of an orthogonally invariant spin glass be determined at every temperature?

[Explanation pane](families/234/explanation.md) · [Mathematical source pane](families/234/mathematics.md)

- [All-temperature pressure for orthogonally invariant Ising spin glasses](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/All-temperature-pressure-for-orthogonally-invariant-Ising-spin-glasses-September-25-2026/paper.pdf) · [individual note](papers/paper-77ee128d02a349f1.md)

### 235 · Limiting random SAT thresholds, sharp variance and computability

At what density do random logical clauses cease to be satisfiable, and how sharply and computably does this threshold emerge?

[Explanation pane](families/235/explanation.md) · [Mathematical source pane](families/235/mathematics.md)

- [A Limiting Satisfiability Threshold for Every Fixed Clause Size](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Limiting-Satisfiability-Threshold-for-Every-Fixed-Clause-Size-September-25-2026/article.pdf) · [individual note](papers/paper-0c2d60b5ad8399b2.md)
- [Linear Variance of the Random 3-SAT Hitting Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Linear-Variance-of-the-Random-3-SAT-Hitting-Time-October-5-2026/linear-variance-of-the-random-3-sat-hitting-time.pdf) · [individual note](papers/paper-54be7a75dcfeebdb.md)
- [Variance of the Random k-SAT Hitting Time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Variance-of-the-Random-k-SAT-Hitting-Time-September-27-2026/article.pdf) · [individual note](papers/paper-85813da1afdaac6b.md)
- [Computing the Random 3-SAT Threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Computing-the-Random-3-SAT-Threshold-September-27-2026/article.pdf) · [individual note](papers/paper-558249bc91fec857.md)

### 236 · The exact factor-of-IID threshold for free Ising spins on trees

When can free-boundary Ising spins on a tree be generated as a factor of independent randomness?

[Explanation pane](families/236/explanation.md) · [Mathematical source pane](families/236/mathematics.md)

- [The sharp factor-of-IID threshold for the free Ising model on regular trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-factor-of-IID-threshold-for-the-free-Ising-model-on-regular-trees-September-26-2026/article.pdf) · [individual note](papers/paper-d211d21be87dafc6.md)

### 237 · The three-quarter exponent for honeycomb self-avoiding walk

How does the typical spatial extent of a long self-avoiding walk grow with its length on the honeycomb lattice?

[Explanation pane](families/237/explanation.md) · [Mathematical source pane](families/237/mathematics.md)

- [Radial transfer estimates and polygon length laws for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Radial-transfer-estimates-and-polygon-length-laws-for-honeycomb-walks-September-26-2026/main.pdf) · [individual note](papers/paper-c4ca973623b6665b.md)
- [Critical honeycomb chords with prescribed boundary endpoints](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-honeycomb-chords-with-prescribed-boundary-endpoints-September-26-2026/main.pdf) · [individual note](papers/paper-1623bdbccc2a2701.md)
- [Cylinder loop weights and planar nesting](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-loop-weights-and-planar-nesting-September-26-2026/main.pdf) · [individual note](papers/paper-27978ff68108bb0f.md)
- [Mass and covering exponents for fixed-length honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Mass-and-covering-exponents-for-fixed-length-honeycomb-walks-September-26-2026/main.pdf) · [individual note](papers/paper-2b2060590067f4cc.md)
- [Signed cylinder propagation and marked polygons on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-cylinder-propagation-and-marked-polygons-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [individual note](papers/paper-4609154dd5780e4d.md)
- [Cylinder amplitudes and logarithmic bridge-length windows on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cylinder-amplitudes-and-logarithmic-bridge-length-windows-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [individual note](papers/paper-16d0f105b651fc4a.md)
- [Marked polygon correlations and one-arc bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Marked-polygon-correlations-and-one-arc-bounds-September-26-2026/main.pdf) · [individual note](papers/paper-7c8d8c156d0831e1.md)
- [Disk transfer representations and confined bridge mass](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Disk-transfer-representations-and-confined-bridge-mass-September-26-2026/main.pdf) · [individual note](papers/paper-3a5149b0a5380c41.md)
- [Polynomial vacuum representations and bridge mass for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-vacuum-representations-and-bridge-mass-for-honeycomb-walks-September-26-2026/main.pdf) · [individual note](papers/paper-5757305667c1206f.md)
- [Renewal and changes of law for critical honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Renewal-and-changes-of-law-for-critical-honeycomb-walks-September-26-2026/main.pdf) · [individual note](papers/paper-8632c2fa3c9adfcf.md)
- [Critical strip-crossing mass on the honeycomb lattice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Critical-strip-crossing-mass-on-the-honeycomb-lattice-September-26-2026/main.pdf) · [individual note](papers/paper-ee954b0db73049fb.md)
- [Uniform marked-polygon estimates and sharp finite bridge moments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-marked-polygon-estimates-and-sharp-finite-bridge-moments-September-26-2026/main.pdf) · [individual note](papers/paper-f0fb1035bae11b12.md)
- [Cap-selected amplitudes and triangle chords for honeycomb walks](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cap-selected-amplitudes-and-triangle-chords-for-honeycomb-walks-September-26-2026/main.pdf) · [individual note](papers/paper-46a375ad32855920.md)

### 238 · Optimal logarithmic mixing of the Thorp shuffle

How many rounds of the Thorp card shuffle are needed to approach a uniformly random permutation?

[Explanation pane](families/238/explanation.md) · [Mathematical source pane](families/238/mathematics.md)

- [Optimal-order mixing of the Thorp shuffle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Optimal-order-mixing-of-the-Thorp-shuffle-September-26-2026/paper.pdf) · [individual note](papers/paper-025591fd075b13f8.md)
- [Random coordinate frames and partial permutation laws](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-coordinate-frames-and-partial-permutation-laws-September-26-2026/main.pdf) · [individual note](papers/paper-33d1bc7e07c70610.md)
- [From partial permutation information to Fourier bounds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/From-partial-permutation-information-to-Fourier-bounds-September-26-2026/main.pdf) · [individual note](papers/paper-d7bc9b13ce9fc85f.md)
- [Conditional information under deterministic coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-information-under-deterministic-coordinate-sweeps-September-26-2026/main.pdf) · [individual note](papers/paper-494bf6af76754487.md)
- [Conditional permutations in a revealed switching environment](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-permutations-in-a-revealed-switching-environment-September-26-2026/paper.pdf) · [individual note](papers/paper-ce6a8a7cfdd51cf0.md)
- [Routing densities and representation contraction for Thorp sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Routing-densities-and-representation-contraction-for-Thorp-sweeps-September-26-2026/paper.pdf) · [individual note](papers/paper-d4649633f45577f3.md)
- [Row–column symmetry and contraction of coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Row-column-symmetry-and-contraction-of-coordinate-sweeps-September-26-2026/paper.pdf) · [individual note](papers/paper-4cd1b43908669d25.md)
- [Random-subspace tests and trace smoothing for coordinate sweeps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Random-subspace-tests-and-trace-smoothing-for-coordinate-sweeps-September-26-2026/paper.pdf) · [individual note](papers/paper-23352c559ca6130f.md)
- [Compatibility entropy and the spectrum of a Thorp sweep](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Compatibility-entropy-and-the-spectrum-of-a-Thorp-sweep-September-26-2026/paper.pdf) · [individual note](papers/paper-066bd17e20c91725.md)
- [Signed tensor densities and diagram budgets for the Thorp shuffle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Signed-tensor-densities-and-diagram-budgets-for-coordinate-sweeps-September-26-2026/paper.pdf) · [individual note](papers/paper-5677e8662d3a064d.md)
- [Conditional coordinate sweeps and analytic transfer](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conditional-coordinate-sweeps-and-analytic-transfer-September-26-2026/main.pdf) · [individual note](papers/paper-2a0250a8d5ca112d.md)
- [A strict four-row permanent inequality and permutation moments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-strict-four-row-permanent-inequality-and-permutation-moments-September-26-2026/main.pdf) · [individual note](papers/paper-cfd3197691c1cfa4.md)

### 239 · Sharp singularity rates for symmetric random sign matrices

How quickly does the probability that a symmetric random plus/minus-one matrix is singular decay with matrix size?

[Explanation pane](families/239/explanation.md) · [Mathematical source pane](families/239/mathematics.md)

- [The sharp exponential rate of singularity for symmetric Bernoulli matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-exponential-rate-of-singularity-for-symmetric-Bernoulli-matrices-October-3-2026/symmetric-bernoulli-singularity.pdf) · [individual note](papers/paper-a12e95803a6ff0ff.md)
- [The sharp singularity rate for biased symmetric sign matrices](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-sharp-singularity-rate-for-biased-symmetric-sign-matrices-October-4-2026/biased-symmetric-sign-singularity.pdf) · [individual note](papers/paper-88bbfa0056a7bec9.md)

## Mathematical logic

### 240 · Shelah's eventual categoricity and the prescribed-threshold obstruction

When does having a unique model at one large cardinality force uniqueness at every sufficiently large cardinality?

[Explanation pane](families/240/explanation.md) · [Mathematical source pane](families/240/mathematics.md)

- [A CH obstruction to a prescribed categoricity threshold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-CH-Obstruction-to-a-Prescribed-Categoricity-Threshold-September-24-2026/paper.pdf) · [individual note](papers/paper-84beafdd9fce9805.md)
- [Eventual categoricity for abstract elementary classes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Eventual-Categoricity-for-Abstract-Elementary-Classes-September-24-2026/paper.pdf) · [individual note](papers/paper-5ca05aedac5e06f3.md)

### 241 · Rigidity of the Turing degrees

Can the partial order of Turing degrees have any nontrivial symmetry?

[Explanation pane](families/241/explanation.md) · [Mathematical source pane](families/241/mathematics.md)

- [Rigidity of the Turing degrees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rigidity-of-the-Turing-degrees-September-24-2026/paper.pdf) · [individual note](papers/paper-8500f0916b3b9d79.md)

### 242 · Single-fold Diophantine representations and undecidability under an at-most-one-solution promise

Can recursively enumerable sets be encoded by polynomial equations with at most one auxiliary solution for each input?

[Explanation pane](families/242/explanation.md) · [Mathematical source pane](families/242/mathematics.md)

- [Single-fold Diophantine representations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Single-fold-Diophantine-representations-September-24-2026/paper.pdf) · [individual note](papers/paper-d4cd188fb2cb316e.md)

### 243 · Separating choiceless counting from polynomial time and witnessed choice

Can polynomial-time computation be captured by a logic that counts but cannot arbitrarily choose individual elements?

[Explanation pane](families/243/explanation.md) · [Mathematical source pane](families/243/mathematics.md)

- [Choiceless polynomial time with counting does not capture polynomial time](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Choiceless-polynomial-time-with-counting-does-not-capture-polynomial-time-September-23-2026/paper.pdf) · [individual note](papers/paper-e6e04202257f8911.md)
- [Witnessed symmetric choice is strictly stronger than choiceless polynomial time with counting](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Witnessed-symmetric-choice-is-strictly-stronger-than-choiceless-polynomial-time-with-counting-September-24-2026/paper.pdf) · [individual note](papers/paper-3f60c73829f39973.md)

### 244 · The Partition Principle does not imply Choice

Does a weak principle comparing partitions already imply the full axiom of choice?

[Explanation pane](families/244/explanation.md) · [Mathematical source pane](families/244/mathematics.md)

- [The Partition Principle does not imply Choice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Partition-Principle-does-not-imply-Choice-September-24-2026/partition-principle-without-choice.pdf) · [individual note](papers/paper-f47c7d5f8539f9a7.md)

### 245 · Weak normalization implies strong normalization in pure type systems

If a typed expression has some terminating reduction path, must every reduction path terminate?

[Explanation pane](families/245/explanation.md) · [Mathematical source pane](families/245/mathematics.md)

- [Weak and strong normalization in pure type systems](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-and-strong-normalization-in-pure-type-systems-September-25-2026/paper.pdf) · [individual note](papers/paper-2bf179f044c6efa0.md)

## Group theory

### 246 · Cannon's conjecture

Must a hyperbolic group whose boundary is a two-sphere act geometrically on hyperbolic three-space?

[Explanation pane](families/246/explanation.md) · [Mathematical source pane](families/246/mathematics.md)

- [A Modulus Proof of Cannon’s Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Modulus-Proof-of-Cannons-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-4d998a62655613b4.md)

### 247 · An infinite finitely presented residually finite 2-group and a finitely presented nil algebra

Can an infinite group with only power-of-two torsion be finitely presented and still distinguished by finite quotients?

[Explanation pane](families/247/explanation.md) · [Mathematical source pane](families/247/mathematics.md)

- [An infinite finitely presented residually finite 2-group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-infinite-finitely-presented-residually-finite-2-group-October-5-2026/residually-finite-torsion.pdf) · [individual note](papers/paper-4e295cb76423504c.md)
- [An infinite finitely presented periodic group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-infinite-finitely-presented-periodic-group-September-23-2026/paper.pdf) · [individual note](papers/paper-f109d87e3a42937d.md)

### 248 · Thompson's group F is nonamenable

Does Thompson's group F admit an invariant notion of averaging over all of its elements?

[Explanation pane](families/248/explanation.md) · [Mathematical source pane](families/248/mathematics.md)

- [Thompson's group F is nonamenable](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thompsons-group-F-is-nonamenable-September-23-2026/paper.pdf) · [individual note](papers/paper-f19833c96eb43ea6.md)

### 249 · A finitely generated Eilenberg–Ganea counterexample

Can the algebraic dimension of a group be two while every geometric classifying space requires three dimensions?

[Explanation pane](families/249/explanation.md) · [Mathematical source pane](families/249/mathematics.md)

- [A finitely generated counterexample to the Eilenberg–Ganea conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finitely-generated-counterexample-to-the-Eilenberg-Ganea-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-a5f52ea092052dbd.md)

### 250 · Boone–Higman embeddings with higher finiteness

Can every group with a solvable word problem embed into a finitely presented simple group with stronger finiteness properties?

[Explanation pane](families/250/explanation.md) · [Mathematical source pane](families/250/mathematics.md)

- [Finite algebraic envelopes and the Boone–Higman conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-algebraic-envelopes-and-the-Boone-Higman-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-e09f76f13ae23ca4.md)
- [Simple F∞ overgroups of groups with decidable word problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Simple-F-infinity-overgroups-of-groups-with-decidable-word-problem-September-23-2026/paper.pdf) · [individual note](papers/paper-68b55ce6c8e1e715.md)
- [A universal group of type F∞](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-universal-group-of-type-F-infinity-September-23-2026/paper.pdf) · [individual note](papers/paper-842b94f8578e9472.md)

### 251 · Amenability, unitarizability, and strong Ulam stability

How closely are invariant averaging, unitary realizations, and stability of approximate group representations related?

[Explanation pane](families/251/explanation.md) · [Mathematical source pane](families/251/mathematics.md)

- [Unitarizability implies amenability for discrete groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Unitarizability-Implies-Amenability-for-Countable-Groups-September-23-2026/paper.pdf) · [individual note](papers/paper-023df749e3e23b54.md)
- [Strong Ulam Stability Characterizes Amenability](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strong-Ulam-Stability-Characterizes-Amenability-October-5-2026/strong-ulam-stability.pdf) · [individual note](papers/paper-3150e8d1bee4abae.md)

### 252 · A torsion-free hyperbolic group that is neither residually finite nor linear over any field

Can a torsion-free hyperbolic group fail both finite-quotient detection and every faithful matrix representation?

[Explanation pane](families/252/explanation.md) · [Mathematical source pane](families/252/mathematics.md)

- [A torsion-free hyperbolic group that is not residually finite](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/a-torsion-free-hyperbolic-group-that-is-not-residually-finite-September-23-2026/paper.pdf) · [individual note](papers/paper-01b64f9ea4a8dbca.md)

### 253 · An infinite finitely presented simple amenable group

Can an infinite simple group be finitely presented while still admitting invariant averaging?

[Explanation pane](families/253/explanation.md) · [Mathematical source pane](families/253/mathematics.md)

- [An infinite finitely presented simple amenable group](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Infinite-Finitely-Presented-Simple-Amenable-Group-September-23-2026/paper.pdf) · [individual note](papers/paper-f8decb4ced2a4b24.md)

### 254 · Classifying spaces and geometric obstructions for Artin groups

Which Artin groups admit the expected classifying spaces, and what geometric obstructions prevent simpler models?

[Explanation pane](families/254/explanation.md) · [Mathematical source pane](families/254/mathematics.md)

- [Harmonic heights and the Artin K(pi,1) conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Harmonic-heights-and-the-Artin-K-pi-1-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-dfc905d0fe1fe5cf.md)
- [An Artin group with no geometric CAT(0) action](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Artin-group-with-no-geometric-CAT-0-action-September-23-2026/paper.pdf) · [individual note](papers/paper-3e04b32c30c9e822.md)
- [Parabolic intersections in Artin groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Parabolic-intersections-in-Artin-groups-September-23-2026/paper.pdf) · [individual note](papers/paper-a1e320bcc69fc458.md)

### 255 · Quasi-isometric recognition of virtually polycyclic groups

Can large-scale distance geometry recognize groups that are virtually polycyclic?

[Explanation pane](families/255/explanation.md) · [Mathematical source pane](families/255/mathematics.md)

- [Quasi-isometric recognition of virtually polycyclic groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/quasi-isometric-recognition-of-virtually-polycyclic-groups-September-24-2026/paper.pdf) · [individual note](papers/paper-74953d3ef5eb2a4d.md)

### 256 · Nonsingular systems of equations over arbitrary groups

Do nonsingular systems of group equations always become solvable in an overgroup?

[Explanation pane](families/256/explanation.md) · [Mathematical source pane](families/256/mathematics.md)

- [Nonsingular systems of equations over arbitrary groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonsingular-systems-of-equations-over-arbitrary-groups-October-5-2026/nonsingular-systems-over-arbitrary-groups.pdf) · [individual note](papers/paper-96f3844b49d3a0f7.md)
- [The Kervaire theorem for groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kervaire-Theorem-for-Groups-September-24-2026/The-Kervaire-Theorem-for-Groups-September-24-2026.pdf) · [individual note](papers/paper-63f4b2af9a574825.md)

### 257 · A hyperbolic group without a geometric CAT(0) action

Can a hyperbolic group fail to admit any proper cocompact action on a nonpositively curved CAT(0) space?

[Explanation pane](families/257/explanation.md) · [Mathematical source pane](families/257/mathematics.md)

- [A hyperbolic group with no geometric CAT(0) action](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-hyperbolic-group-with-no-geometric-CAT0-action-September-25-2026/paper.pdf) · [individual note](papers/paper-95ab6ed79b4ec13d.md)

### 258 · Gersten’s conjecture and virtual compact specialness of one-relator groups

Which one-relator groups possess the predicted finiteness and nonpositively curved cubical structures?

[Explanation pane](families/258/explanation.md) · [Mathematical source pane](families/258/mathematics.md)

- [Baumslag-Solitar-free one-relator groups are hyperbolic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Baumslag-Solitar-free-one-relator-groups-are-hyperbolic-September-25-2026/paper.pdf) · [individual note](papers/paper-ac4977a1a76e832b.md)
- [Virtual compact specialness of hyperbolic one-relator groups](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Virtual-compact-specialness-of-hyperbolic-one-relator-groups-September-25-2026/paper.pdf) · [individual note](papers/paper-1b88b3d8be89ed59.md)

### 259 · A group without fixed price

Must every free probability-preserving action of a group have the same measured cost?

[Explanation pane](families/259/explanation.md) · [Mathematical source pane](families/259/mathematics.md)

- [A group without fixed price](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-group-without-fixed-price-October-5-2026/unequal-costs-rank-100-amalgam.pdf) · [individual note](papers/paper-f3f277c6891f794a.md)

## Mathematical physics

### 260 · Spacetime Penrose inequalities: enclosing area, charge, rotation, and anti-de Sitter extensions

Does the size of a black-hole horizon impose the predicted lower bound on total spacetime mass, including charge and rotation?

[Explanation pane](families/260/explanation.md) · [Mathematical source pane](families/260/mathematics.md)

- [The spacetime Penrose inequality with charge and original-data rigidity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-spacetime-Penrose-inequality-with-charge-and-original-data-rigidity-October-5-2026/paper.pdf) · [individual note](papers/paper-c9d50e428088d246.md)
- [A Charged Reduction of the Spacetime Penrose Inequality in Spatial Dimensions at Least Four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Charged-Reduction-of-the-Spacetime-Penrose-Inequality-in-Spatial-Dimensions-at-Least-Four-October-5-2026/paper.pdf) · [individual note](papers/paper-f1f90b5b68c930d3.md)
- [Spacetime Penrose inequalities: enclosing area, charge, and rigidity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spacetime-Penrose-inequalities-enclosing-area-charge-and-rigidity-October-5-2026/paper.pdf) · [individual note](papers/paper-4fc24c3e7a7f772d.md)
- [The Kerr–Newman Penrose Inequality for Axisymmetric Electrovacuum Exteriors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kerr-Newman-Penrose-Inequality-for-Axisymmetric-Electrovacuum-Exteriors-October-5-2026/paper.pdf) · [individual note](papers/paper-3a78fc37408d5c49.md)
- [Electromagnetic tails and the Kerr–Newman Penrose inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Electromagnetic-tails-and-the-Kerr-Newman-Penrose-inequality-October-5-2026/paper.pdf) · [individual note](papers/paper-63f7bfe52b2d1a50.md)
- [The nonmaximal anti-de Sitter Penrose Inequality and original-data rigidity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-nonmaximal-anti-de-Sitter-Penrose-Inequality-and-original-data-rigidity-October-5-2026/paper.pdf) · [individual note](papers/paper-9e1a5a1e35993683.md)
- [The Penrose inequality for maximal asymptotically hyperbolic initial data](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Penrose-inequality-for-maximal-asymptotically-hyperbolic-initial-data-October-5-2026/paper.pdf) · [individual note](papers/paper-5d4976d06c96a1b4.md)
- [A local Penrose inequality for conformal perturbations of Schwarzschild–anti-de Sitter data](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-local-Penrose-inequality-for-conformal-perturbations-of-Schwarzschild-anti-de-Sitter-data-October-5-2026/paper.pdf) · [individual note](papers/paper-39788d94ebb5c776.md)
- [The spacetime Penrose inequality and enclosing area](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-spacetime-Penrose-inequality-and-enclosing-area-September-27-2026/paper.pdf) · [individual note](papers/paper-d413001fc7030959.md)
- [Conformal flow and the Riemannian Penrose inequality with minimizing frontiers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Conformal-flow-and-the-Riemannian-Penrose-inequality-with-minimizing-frontiers-September-27-2026/paper.pdf) · [individual note](papers/paper-99aff5b377bf8945.md)
- [Equality and rigidity in the spacetime Penrose inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equality-and-rigidity-in-the-spacetime-Penrose-inequality-September-27-2026/paper.pdf) · [individual note](papers/paper-97aeb16052f216e1.md)
- [Boundary graph deformations for the spacetime Penrose inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Boundary-graph-deformations-for-the-spacetime-Penrose-inequality-September-27-2026/paper.pdf) · [individual note](papers/paper-94b4848c5a41e33d.md)
- [Area-controlled end replacement and the Bondi Penrose inequality in the CKS class](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Area-controlled-end-replacement-and-the-Bondi-Penrose-inequality-in-the-CKS-class-September-27-2026/paper.pdf) · [individual note](papers/paper-e11daebd5a7977da.md)

### 261 · Localization and delocalization in the Anderson model

When does disorder trap quantum waves, and when can waves travel through the medium?

[Explanation pane](families/261/explanation.md) · [Mathematical source pane](families/261/mathematics.md)

- [Absolutely Continuous Spectrum for Weak-Disorder Anderson Models in Dimensions at Least Three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Absolutely-Continuous-Spectrum-for-Weak-Disorder-Anderson-Models-in-Dimensions-at-Least-Three-September-23-2026/paper.pdf) · [individual note](papers/paper-5509e3263d7e7ef9.md)
- [Pure-Point Spectrum for the Two-Dimensional Anderson Model at Every Positive Disorder](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Pure-Point-Spectrum-for-the-Two-Dimensional-Anderson-Model-at-Every-Positive-Disorder-September-23-2026/paper.pdf) · [individual note](papers/paper-2f3f436e1606c6b1.md)

### 262 · Sharp finite-matrix Lieb–Thirring inequalities and all equality cases

What is the sharp relationship between the negative eigenvalues of a matrix-valued Hamiltonian and the strength of its potential?

[Explanation pane](families/262/explanation.md) · [Mathematical source pane](families/262/mathematics.md)

- [Equality cases in the sharp one-dimensional matrix Lieb–Thirring inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equality-cases-in-the-sharp-one-dimensional-matrix-Lieb-Thirring-inequality-October-5-2026/sharp-one-dimensional-lieb-thirring-inequalities-matrix-potentials.pdf) · [individual note](papers/paper-5bf2f618b4e7fd26.md)
- [Sharp one-dimensional Lieb–Thirring inequalities for matrix potentials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-one-dimensional-Lieb-Thirring-inequalities-for-matrix-potentials-October-5-2026/sharp-matrix-lieb-thirring.pdf) · [individual note](papers/paper-f667c4cb31984c1b.md)
- [Sharp one-dimensional Lieb–Thirring constants](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-One-Dimensional-Lieb-Thirring-Constants-September-23-2026/paper.pdf) · [individual note](papers/paper-a1aa8e17be727f9b.md)

### 263 · The ionization and generalized ionization conjectures

How many extra electrons can an atom bind beyond its nuclear charge?

[Explanation pane](families/263/explanation.md) · [Mathematical source pane](families/263/mathematics.md)

- [Uniform excess charge for Coulomb molecules and the outer radius of neutral atoms](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-excess-charge-for-Coulomb-molecules-and-the-outer-radius-of-neutral-atoms-September-24-2026/paper.pdf) · [individual note](papers/paper-2331ea9cf17b9d10.md)
- [Generalized ionization energies for full Coulomb atoms](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-ionization-energies-for-full-Coulomb-atoms-September-24-2026/paper.pdf) · [individual note](papers/paper-40b327717c5bebde.md)
- [Generalized outer-electron radii of neutral Coulomb atoms](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-outer-electron-radii-of-neutral-Coulomb-atoms-September-24-2026/paper.pdf) · [individual note](papers/paper-685af7aa0ce8b85a.md)

### 264 · Strong cosmic censorship near two-ended Kerr data

For perturbed rotating-black-hole data, do generic spacetimes become singular enough to prevent deterministic extension?

[Explanation pane](families/264/explanation.md) · [Mathematical source pane](families/264/mathematics.md)

- [Generic Future Inextendibility with Square-Integrable Connection Near a Fixed Kerr Spacetime](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generic-Future-Inextendibility-with-Square-Integrable-Connection-Near-a-Fixed-Kerr-Spacetime-September-23-2026/paper.pdf) · [individual note](papers/paper-1080853e040c927a.md)
- [Generic C1 Future Inextendibility Near Rotating Subextremal Kerr Spacetimes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generic-C1-Future-Inextendibility-Near-Rotating-Subextremal-Kerr-Spacetimes-September-23-2026/paper.pdf) · [individual note](papers/paper-2f2b86de05419a86.md)
- [Quantitative Near-Kerr Evolution and Generic C2 Future Inextendibility](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantitative-Near-Kerr-Evolution-and-Generic-C2-Future-Inextendibility-September-23-2026/paper.pdf) · [individual note](papers/paper-b341fd15a02a68be.md)

### 265 · Area laws and tensor networks for two-dimensional gapped systems

Do gapped two-dimensional quantum systems have entanglement controlled by boundary size and efficient tensor-network descriptions?

[Explanation pane](families/265/explanation.md) · [Mathematical source pane](families/265/mathematics.md)

- [A two-dimensional area law from a global spectral gap](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-two-dimensional-area-law-from-a-global-spectral-gap-September-24-2026/paper.pdf) · [individual note](papers/paper-9f31065b53232980.md)
- [Polynomial PEPS approximation of gapped square-grid ground states](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-PEPS-approximation-of-gapped-square-grid-ground-states-September-24-2026/paper.pdf) · [individual note](papers/paper-ec1f6e4a5111025c.md)

### 266 · Exactly three mutually unbiased bases in dimension six

How many orthonormal measurement bases in six-dimensional quantum space can be pairwise maximally incompatible?

[Explanation pane](families/266/explanation.md) · [Mathematical source pane](families/266/mathematics.md)

- [The maximum number of mutually unbiased bases in dimension six](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-maximum-number-of-mutually-unbiased-bases-in-dimension-six-September-24-2026/The-maximum-number-of-mutually-unbiased-bases-in-dimension-six-September-24-2026.pdf) · [individual note](papers/paper-de1771f84ca4e64b.md)
- [Exact Fourier certificates for complex Hadamard matrices of order six](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-Fourier-certificates-for-complex-Hadamard-matrices-of-order-six-September-24-2026/Exact-Fourier-certificates-for-complex-Hadamard-matrices-of-order-six-September-24-2026.pdf) · [individual note](papers/paper-b5fb6ecf9f4e2b77.md)

### 267 · Positive-temperature Bose–Einstein condensation and exact quantum depletion

Can interacting bosons condense at positive temperature, and how many particles remain outside the condensate?

[Explanation pane](families/267/explanation.md) · [Mathematical source pane](families/267/mathematics.md)

- [Bose–Einstein condensation at positive temperature in the dilute hard-sphere gas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bose-Einstein-condensation-at-positive-temperature-in-the-dilute-hard-sphere-gas-October-5-2026/positive-temperature-hard-spheres.pdf) · [individual note](papers/paper-801072ac1fae715e.md)
- [Quantum Depletion and Momentum Distribution in the Dilute Hard-Sphere Bose Gas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantum-Depletion-and-Momentum-Distribution-in-the-Dilute-Hard-Sphere-Bose-Gas-October-5-2026/Quantum-Depletion-in-the-Dilute-Hard-Sphere-Bose-Gas.pdf) · [individual note](papers/paper-4b1d3b2c2068a557.md)
- [Quantum Depletion for Fixed Bounded Repulsive Potentials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quantum-Depletion-for-Fixed-Bounded-Repulsive-Potentials-October-5-2026/fixed-repulsion-quantum-depletion.pdf) · [individual note](papers/paper-4a2162991459eb3f.md)
- [A density-uniform condensate bound for dilute Bose gases](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-density-uniform-condensate-bound-for-dilute-Bose-gases-September-27-2026/paper.pdf) · [individual note](papers/paper-0bf67eeec97af4e8.md)
- [Ground-state condensation in the dilute hard-sphere gas](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Ground-state-condensation-in-the-dilute-hard-sphere-gas-September-24-2026/paper.pdf) · [individual note](papers/paper-6d96b083c74f4076.md)

### 268 · The spin-one Haldane gap

Does an antiferromagnetic spin-one chain have a strictly positive energy gap above its ground state?

[Explanation pane](families/268/explanation.md) · [Mathematical source pane](families/268/mathematics.md)

- [The periodic spin-one Haldane gap](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-periodic-spin-one-Haldane-gap-September-24-2026/paper.pdf) · [individual note](papers/paper-d65e90dd701647ca.md)
- [A boundary-field gap for the spin-one Heisenberg chain](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-boundary-field-gap-for-the-spin-one-Heisenberg-chain-September-24-2026/paper.pdf) · [individual note](papers/paper-3165969dd92e79bb.md)

### 269 · Uniform Laughlin gap and stability under bounded scalar disorder

Does the Laughlin fractional-quantum-Hall state retain a uniform energy gap, including under suitable disorder?

[Explanation pane](families/269/explanation.md) · [Mathematical source pane](families/269/mathematics.md)

- [Uniform Stability of the Spherical Laughlin Gap](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Stability-of-the-Spherical-Laughlin-Gap-October-5-2026/uniform-stability-spherical-laughlin-gap.pdf) · [individual note](papers/paper-fd6c2cbbfad1f459.md)
- [A Fock-space inequality and the Laughlin spectral gap](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Fock-space-inequality-and-the-Laughlin-spectral-gap-September-24-2026/A-Fock-space-inequality-and-the-Laughlin-spectral-gap-September-24-2026.pdf) · [individual note](papers/paper-197b798dcbf07bcf.md)

### 270 · Threshold and positive-energy bound states of the BFSS matrix model

Does the supersymmetric BFSS matrix model possess a bound state at threshold, and what happens at positive energy?

[Explanation pane](families/270/explanation.md) · [Mathematical source pane](families/270/mathematics.md)

- [The unique threshold bound state of the SU(N) BFSS model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-unique-threshold-bound-state-of-the-SU-N-BFSS-model-September-24-2026/paper.pdf) · [individual note](papers/paper-2db1e6506c965eb8.md)
- [Positive eigenvalues of the relative SU(2) BFSS Hamiltonian](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-eigenvalues-of-the-relative-SU-2-BFSS-Hamiltonian-October-5-2026/positive-eigenvalues-relative-su2-bfss.pdf) · [individual note](papers/paper-f090fd60271446e0.md)

### 271 · Bloch's law, its lattice correction, and the spherical magnetization law

How does spontaneous magnetization decrease at low temperature, including lattice corrections to Bloch's law?

[Explanation pane](families/271/explanation.md) · [Mathematical source pane](families/271/mathematics.md)

- [Bloch's Law for Finite-Range Heisenberg Ferromagnets in Three Dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Blochs-Law-for-Finite-Range-Heisenberg-Ferromagnets-in-Three-Dimensions-October-5-2026/bloch-law-heisenberg.pdf) · [individual note](papers/paper-9669b6997ff4be58.md)
- [The first lattice correction to Bloch's law](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-first-lattice-correction-to-Blochs-law-October-5-2026/first-lattice-correction-bloch-law.pdf) · [individual note](papers/paper-e4168cfdc9df4b3b.md)
- [The spherical magnetization law for the three-dimensional quantum Heisenberg ferromagnet](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-spherical-magnetization-law-for-the-three-dimensional-quantum-Heisenberg-ferromagnet-October-5-2026/spherical-magnetization.pdf) · [individual note](papers/paper-580339d5b914b270.md)
- [Spontaneous magnetization in the quantum Heisenberg ferromagnet](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spontaneous-magnetization-in-the-quantum-Heisenberg-ferromagnet-September-24-2026/paper.pdf) · [individual note](papers/paper-addb934e37307c35.md)

### 272 · Entanglement without distillable secret key

Can an entangled quantum state contain no secret key that separated parties can distill?

[Explanation pane](families/272/explanation.md) · [Mathematical source pane](families/272/mathematics.md)

- [Entanglement with zero distillable secret key in local dimension ten](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Entanglement-with-zero-distillable-secret-key-in-local-dimension-ten-September-27-2026/paper.pdf) · [individual note](papers/paper-c663b6e48ceebe25.md)

### 273 · The entropy photon-number inequality

How does the effective photon-number entropy change when quantum optical signals are mixed?

[Explanation pane](families/273/explanation.md) · [Mathematical source pane](families/273/mathematics.md)

- [The entropy photon-number inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-entropy-photon-number-inequality-September-24-2026/paper.pdf) · [individual note](papers/paper-041c637d0e96ad7a.md)

### 274 · Parity is not in QAC^{0}

Can constant-depth quantum circuits with the specified unbounded gates compute parity?

[Explanation pane](families/274/explanation.md) · [Mathematical source pane](families/274/mathematics.md)

- [Product-projection localization and the QAC0 parity lower bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Product-projection-localization-and-the-QAC0-parity-lower-bound-September-24-2026/paper.pdf) · [individual note](papers/paper-8528bb31b98eb6a8.md)
- [Regular trajectories, pruning and quantum parity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Regular-trajectories-pruning-and-quantum-parity-September-24-2026/paper.pdf) · [individual note](papers/paper-d193b1366644c9e0.md)

### 275 · QMA-hardness of continuum Coulomb energy

Is determining the ground energy of continuum electrons with Coulomb interactions as hard as general quantum verification?

[Explanation pane](families/275/explanation.md) · [Mathematical source pane](families/275/mathematics.md)

- [Continuum Coulomb hardness with binary nuclear charges](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Continuum-Coulomb-hardness-with-binary-nuclear-charges-September-24-2026/Continuum-Coulomb-hardness-with-binary-nuclear-charges-September-24-2026.pdf) · [individual note](papers/paper-7d26e5d3bd1745c8.md)
- [QMA-hardness of continuum Coulomb energy with unit nuclear charges](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/QMA-hardness-of-continuum-Coulomb-energy-with-unit-nuclear-charges-September-24-2026/QMA-hardness-of-continuum-Coulomb-energy-with-unit-nuclear-charges-September-24-2026.pdf) · [individual note](papers/paper-3650cd09ac78b078.md)

### 276 · Classical capacity of generalized amplitude damping

How much classical information can reliably pass through a thermal amplitude-damping quantum channel?

[Explanation pane](families/276/explanation.md) · [Mathematical source pane](families/276/mathematics.md)

- [Classical capacity and entropy inequalities for generalized amplitude damping](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Classical-capacity-and-entropy-inequalities-for-generalized-amplitude-damping-September-24-2026/paper.pdf) · [individual note](papers/paper-9fa995332c4f85cc.md)

### 277 · Threshold repetition for entangled games

When an entangled game is repeated, how quickly does the chance of exceeding a winning threshold decay?

[Explanation pane](families/277/explanation.md) · [Mathematical source pane](families/277/mathematics.md)

- [Threshold parallel repetition for finite-dimensional entangled games](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Threshold-parallel-repetition-for-finite-dimensional-entangled-games-September-25-2026/paper.pdf) · [individual note](papers/paper-f51a317ba01a477d.md)

### 278 · Failure of Kohn–Sham ensemble representation

Can every relevant interacting electron density be represented by a noninteracting Kohn–Sham ensemble?

[Explanation pane](families/278/explanation.md) · [Mathematical source pane](families/278/mathematics.md)

- [A Coulomb ground-state density without Kohn-Sham ensemble representation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Coulomb-Ground-State-Density-without-Kohn-Sham-Ensemble-Representation-September-25-2026/paper.pdf) · [individual note](papers/paper-ca2011bde2c6ec36.md)

### 279 · Exact quantum factoring over a fixed finite gate set

Can integer factoring be performed exactly using a fixed finite universal quantum gate set?

[Explanation pane](families/279/explanation.md) · [Mathematical source pane](families/279/mathematics.md)

- [Exact quantum factoring over a fixed finite gate set](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-quantum-factoring-over-a-fixed-finite-gate-set-September-25-2026/main.pdf) · [individual note](papers/paper-6bbfd91532a4c3c5.md)

### 280 · Unitary vertex operator algebras and conformal nets

Can algebraic and operator-theoretic constructions of unitary conformal field theories be connected rigorously?

[Explanation pane](families/280/explanation.md) · [Mathematical source pane](families/280/mathematics.md)

- [Strongly rational unitary vertex operator algebras and conformal nets](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strongly-rational-unitary-vertex-operator-algebras-and-conformal-nets-September-25-2026/paper.pdf) · [individual note](papers/paper-3ca87c88dd6d6adb.md)

### 281 · QAOA attains the SK optimum in the thermodynamic-first limit

Can sufficiently deep QAOA attain the optimal mean-field spin-glass energy when the system-size limit is taken first?

[Explanation pane](families/281/explanation.md) · [Mathematical source pane](families/281/mathematics.md)

- [QAOA attains the SK ground-state energy in the thermodynamic-first limit](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/QAOA-attains-the-SK-ground-state-energy-in-the-thermodynamic-first-limit-September-25-2026/QAOA-attains-the-SK-ground-state-energy-in-the-thermodynamic-first-limit-September-25-2026.pdf) · [individual note](papers/paper-6b91a1f278c84cb2.md)
- [Full support of the zero-temperature Sherrington-Kirkpatrick order parameter](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Full-support-of-the-zero-temperature-Sherrington-Kirkpatrick-order-parameter-September-27-2026/main.pdf) · [individual note](papers/paper-e4eaac5524348a6b.md)

### 282 · From scale symmetry to local conformal symmetry in four-dimensional QFT

Under what hypotheses does scale invariance in four-dimensional quantum field theory imply the richer conformal symmetry?

[Explanation pane](families/282/explanation.md) · [Mathematical source pane](families/282/mathematics.md)

- [Scale and conformal symmetry in four-dimensional operational quantum field theory](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Scale-and-conformal-symmetry-in-four-dimensional-operational-quantum-field-theory-September-26-2026/main.pdf) · [individual note](papers/paper-0bea907d8a9a47a0.md)

### 283 · Polynomial-time unitary synthesis from a Boolean oracle

How efficiently can a quantum unitary be synthesized when its information is supplied through a Boolean oracle?

[Explanation pane](families/283/explanation.md) · [Mathematical source pane](families/283/mathematics.md)

- [Polynomial-Time Unitary Synthesis from a Boolean Oracle](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Polynomial-Time-Unitary-Synthesis-from-a-Boolean-Oracle-October-5-2026/paper.pdf) · [individual note](papers/paper-29911f3350cef93e.md)

### 284 · The optimal quartic separation between randomized and quantum queries

How much better can a quantum query algorithm be than every randomized classical query algorithm?

[Explanation pane](families/284/explanation.md) · [Mathematical source pane](families/284/mathematics.md)

- [A Nearly Quartic Separation Between Randomized and Quantum Query Complexity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Nearly-Quartic-Separation-Between-Randomized-and-Quantum-Query-Complexity-October-5-2026/quartic-query-separation.pdf) · [individual note](papers/paper-42626a7cbc8542af.md)

## Operator algebras

### 285 · Counterexamples to Baum–Connes and Kadison–Kaplansky

Can group/operator-algebra examples violate predicted K-theory correspondences or the absence of nontrivial projections?

[Explanation pane](families/285/explanation.md) · [Mathematical source pane](families/285/mathematics.md)

- [A torsion-free counterexample to reduced Baum–Connes injectivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Counterexample-to-Reduced-Baum-Connes-Injectivity-September-23-2026/paper.pdf) · [individual note](papers/paper-ed186ef9c24ddd19.md)
- [A torsion-free counterexample to the Kadison–Kaplansky projection conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Torsion-Free-Counterexample-to-the-Kadison-Kaplansky-Projection-Conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-f05d2a712ecbaf8c.md)
- [An irrational-trace counterexample to reduced Baum–Connes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-Irrational-Trace-Counterexample-to-Reduced-Baum-Connes-September-23-2026/paper.pdf) · [individual note](papers/paper-f2838fa803952980.md)

### 286 · Rigidity and arithmetic of lattice von Neumann algebras

How much of an arithmetic lattice can be recovered from its von Neumann algebra?

[Explanation pane](families/286/explanation.md) · [Mathematical source pane](families/286/mathematics.md)

- [Arithmeticity of twisted finite correspondences for lattices over local fields](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Arithmeticity-of-twisted-finite-correspondences-for-lattices-over-local-fields-September-23-2026/paper.pdf) · [individual note](papers/paper-06b6d9d310991843.md)
- [The arithmetic category and stable recovery of lattice factors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-arithmetic-category-and-stable-recovery-of-lattice-factors-September-23-2026/paper.pdf) · [individual note](papers/paper-8d1ce208f01282c1.md)

### 287 · Isomorphism of the free group factors

Are the von Neumann algebras of free groups with different numbers of generators actually isomorphic?

[Explanation pane](families/287/explanation.md) · [Mathematical source pane](families/287/mathematics.md)

- [An isomorphism of the free group factors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-isomorphism-of-the-free-group-factors-September-23-2026/An-isomorphism-of-the-free-group-factors-September-23-2026.pdf) · [individual note](papers/paper-263636be99093c79.md)

### 288 · Kadison's similarity conjecture

Can every bounded operator-algebra representation be made to respect adjoints after a change of coordinates?

[Explanation pane](families/288/explanation.md) · [Mathematical source pane](families/288/mathematics.md)

- [Kadison's similarity theorem through uniform derivation estimates](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Kadisons-similarity-theorem-through-uniform-derivation-estimates-September-23-2026/paper.pdf) · [individual note](papers/paper-c6f25d0e5f45c465.md)

### 289 · Strong Kadison–Kastler stability and its spatial boundaries

If two operator algebras are close as sets of operators, must they be isomorphic through a controlled spatial transformation?

[Explanation pane](families/289/explanation.md) · [Mathematical source pane](families/289/mathematics.md)

- [Universal strong Kadison–Kastler stability](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-strong-Kadison-Kastler-stability-September-23-2026/paper.pdf) · [individual note](papers/paper-124e944e4fe96fe8.md)
- [Near Inclusions of von Neumann Algebras Without Small Spatial Embeddings](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Near-Inclusions-of-von-Neumann-Algebras-Without-Small-Spatial-Embeddings-October-5-2026/near-inclusions.pdf) · [individual note](papers/paper-99d6660d6ae08833.md)
- [Close Separable C*-Algebras Without Spatial Conjugacy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Close-Separable-Cstar-Algebras-Without-Spatial-Conjugacy-October-5-2026/paper.pdf) · [individual note](papers/paper-0fd84ead49bc417e.md)

### 290 · Relative bicentralizers and modular spectral recovery

Can modular spectral information determine the relative bicentralizer structure of an operator algebra?

[Explanation pane](families/290/explanation.md) · [Mathematical source pane](families/290/mathematics.md)

- [Expected amenable subalgebras preserving core commutants](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Expected-amenable-subalgebras-preserving-core-commutants-September-23-2026/Expected-amenable-subalgebras-preserving-core-commutants-September-23-2026.pdf) · [individual note](papers/paper-f8034a5e3d4fb703.md)
- [Bounded recovery for modular spectral averages](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-recovery-for-modular-spectral-averages-September-23-2026/Bounded-recovery-for-modular-spectral-averages-September-23-2026.pdf) · [individual note](papers/paper-81c64b315fd238ea.md)

### 291 · Cuntz comparison, nuclear dimension, and equivariant Jiang–Su stability

When do comparison of positive operators and finite-dimensional approximation force absorption of a regularizing algebra?

[Explanation pane](families/291/explanation.md) · [Mathematical source pane](families/291/mathematics.md)

- [Equivariant Jiang–Su Stability for Amenable Actions in the Unital Stably Finite Case](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Equivariant-Jiang-Su-Stability-for-Amenable-Actions-in-the-Unital-Stably-Finite-Case-October-5-2026/paper.pdf) · [individual note](papers/paper-cbb61a6c74b4e941.md)
- [Cuntz comparison and Jiang–Su absorption](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cuntz-comparison-and-Jiang-Su-absorption-September-23-2026/paper.pdf) · [individual note](papers/paper-cc2f431e1d29e5c5.md)
- [Nuclear dimension and Jiang–Su stability without elementary subquotients](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nuclear-dimension-and-Jiang-Su-stability-without-elementary-subquotients-September-23-2026/paper.pdf) · [individual note](papers/paper-46c4d1aefbc8308d.md)
- [Tracial projection methods and uniform property Gamma](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tracial-projection-methods-and-uniform-property-Gamma-September-23-2026/paper.pdf) · [individual note](papers/paper-0ad67ef84178fcbb.md)

### 292 · Kirchberg's $\mathcal O_2$ norm-ultrapower embedding problem

Can every specified operator algebra embed into the norm ultrapower of the Cuntz algebra O2?

[Explanation pane](families/292/explanation.md) · [Mathematical source pane](families/292/mathematics.md)

- [An explicit obstruction to nuclear norm-ultrapower embeddings](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-explicit-obstruction-to-nuclear-norm-ultrapower-embeddings-September-23-2026/paper.pdf) · [individual note](papers/paper-dab7f33402e67db8.md)

### 293 · Invariant projections, hyperinvariant subspaces, and transitive algebras

When must an operator possess a nontrivial invariant or hyperinvariant subspace?

[Explanation pane](families/293/explanation.md) · [Mathematical source pane](families/293/mathematics.md)

- [Invariant-projection counterexamples for every irrational rotation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Invariant-projection-counterexamples-for-every-irrational-rotation-September-27-2026/paper.pdf) · [individual note](papers/paper-84a4ab6a552be38a.md)
- [Backward intertwiners and a transitive commutant](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Backward-intertwiners-and-a-transitive-commutant-September-27-2026/paper.pdf) · [individual note](papers/paper-0a8581ff210bc2a1.md)

### 294 · Kaplansky's quasitrace conjecture and failure of tensor-product stable finiteness

Do quasitraces always become ordinary traces, and can tensor products destroy stable finiteness?

[Explanation pane](families/294/explanation.md) · [Mathematical source pane](families/294/mathematics.md)

- [A counterexample to Kaplansky's quasitrace conjecture and failure of tensor-product stable finiteness](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Kaplanskys-quasitrace-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-3f8b107901550989.md)

### 295 · The Kadison–Ringrose cohomology conjecture

Must continuous cohomological obstructions of von Neumann algebras vanish in the predicted way?

[Explanation pane](families/295/explanation.md) · [Mathematical source pane](families/295/mathematics.md)

- [Vanishing of higher bounded Hochschild cohomology](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Vanishing-of-higher-bounded-Hochschild-cohomology-September-23-2026/paper.pdf) · [individual note](papers/paper-27130b403630ceac.md)

### 296 · The generator problem for finite factors

Can every finite factor be generated by a single suitably chosen operator?

[Explanation pane](families/296/explanation.md) · [Mathematical source pane](families/296/mathematics.md)

- [Relative generation and the generator problem for finite factors](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-generation-and-the-generator-problem-for-finite-factors-September-23-2026/paper.pdf) · [individual note](papers/paper-908f214b57da368d.md)

### 297 · A ZFC counterexample to Naimark's problem

If an operator algebra has only one irreducible representation up to equivalence, must it be the algebra of compact operators?

[Explanation pane](families/297/explanation.md) · [Mathematical source pane](families/297/mathematics.md)

- [A counterexample to Naimark's problem in ZFC](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-Naimarks-problem-in-ZFC-September-24-2026/naimark-counterexample-zfc.pdf) · [individual note](papers/paper-a663d143530c9d48.md)

### 298 · Two notions of free entropy differ even when both are finite

Do two different constructions of free entropy always assign the same value?

[Explanation pane](families/298/explanation.md) · [Mathematical source pane](families/298/mathematics.md)

- [A finite-entropy separation of microstates and nonmicrostates free entropy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-entropy-separation-of-microstates-and-nonmicrostates-free-entropy-September-25-2026/paper.pdf) · [individual note](papers/paper-31caeb26c04d83e3.md)

### 299 · The Kirchberg–Rørdam character criterion and infinite tensor-power Jiang–Su stability

Does absence of scalar characters force regularity after taking infinitely many tensor factors?

[Explanation pane](families/299/explanation.md) · [Mathematical source pane](families/299/mathematics.md)

- [The Kirchberg–Rørdam character criterion](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kirchberg-Rordam-character-criterion-September-25-2026/paper.pdf) · [individual note](papers/paper-4efc2ec4d479b184.md)

### 300 · Approximation and quadratic strong-operator paving

Can operators be well approximated and partitioned into blocks that suppress unwanted off-block behavior?

[Explanation pane](families/300/explanation.md) · [Mathematical source pane](families/300/mathematics.md)

- [Approximation Paving over Arbitrary Maximal Abelian Subalgebras](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Approximation-Paving-over-Arbitrary-Maximal-Abelian-Subalgebras-September-25-2026/Approximation-Paving-over-Arbitrary-Maximal-Abelian-Subalgebras-September-25-2026.pdf) · [individual note](papers/paper-095dcf7bab0be0ae.md)
- [Quadratic Strong-Operator Paving over Arbitrary Maximal Abelian Subalgebras](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Quadratic-Strong-Operator-Paving-over-Arbitrary-Maximal-Abelian-Subalgebras-September-25-2026/Quadratic-Strong-Operator-Paving-over-Arbitrary-Maximal-Abelian-Subalgebras-September-25-2026.pdf) · [individual note](papers/paper-8a687a97b053c803.md)

### 301 · Trace cones and Razak–Jacelon stabilization

Can stably projectionless algebras be classified and regularized through their cones of traces?

[Explanation pane](families/301/explanation.md) · [Mathematical source pane](families/301/mathematics.md)

- [The trace cone classifies Razak–Jacelon stabilizations](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-trace-cone-classifies-Razak-Jacelon-stabilizations-September-25-2026/The-trace-cone-classifies-Razak-Jacelon-stabilizations-September-25-2026.pdf) · [individual note](papers/paper-a0942ef290d494e9.md)

### 302 · Radius of comparison equals half the mean dimension

Is the failure of comparison in a dynamical operator algebra measured exactly by half the system's mean dimension?

[Explanation pane](families/302/explanation.md) · [Mathematical source pane](families/302/mathematics.md)

- [Filtered products and boundary-preserving compression in complex cobordism](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Filtered-products-and-boundary-preserving-compression-in-complex-cobordism-September-25-2026/paper.pdf) · [individual note](papers/paper-e58a8a38a37e4980.md)
- [Radius of comparison equals half the mean dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Radius-of-comparison-equals-half-the-mean-dimension-September-25-2026/paper.pdf) · [individual note](papers/paper-8c5208a6b7eea347.md)

### 303 · Weak pure infiniteness and Cuntz-algebra absorption

Does a weaker form of purely infinite behavior force absorption of a Cuntz algebra?

[Explanation pane](families/303/explanation.md) · [Mathematical source pane](families/303/mathematics.md)

- [Weak pure infiniteness and O-infinity absorption](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-pure-infiniteness-and-O-infinity-absorption-September-25-2026/paper.pdf) · [individual note](papers/paper-a1fb6160a4b8b92d.md)

## Topology

### 304 · The Hilbert–Smith conjecture in every dimension

Must every locally compact group acting effectively on a manifold be a Lie group?

[Explanation pane](families/304/explanation.md) · [Mathematical source pane](families/304/mathematics.md)

- [The Hilbert–Smith conjecture in every finite dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Hilbert-Smith-conjecture-in-every-finite-dimension-September-23-2026/paper.pdf) · [individual note](papers/paper-d5b8bdf01fefba04.md)

### 305 · Four-dimensional disk embedding and Wall's conjecture

Can immersed disks in four-dimensional topology be replaced by embedded disks under the predicted hypotheses?

[Explanation pane](families/305/explanation.md) · [Mathematical source pane](families/305/mathematics.md)

- [A boundary-only obstruction to four-dimensional disk embedding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-boundary-only-obstruction-to-four-dimensional-disk-embedding-September-24-2026/paper.pdf) · [individual note](papers/paper-e1295c77b3c0c68f.md)
- [A marked tensor obstruction to four-dimensional disk embedding](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-marked-tensor-obstruction-to-four-dimensional-disk-embedding-September-24-2026/paper.pdf) · [individual note](papers/paper-4301af957eb9f970.md)
- [A PD4 group without an aspherical manifold model](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-PD4-group-without-an-aspherical-manifold-model-September-24-2026/paper.pdf) · [individual note](papers/paper-cd4a4c3412d8b01d.md)

### 306 · The purely cosmetic surgery conjecture

Can two genuinely different Dehn surgeries on the same knot produce the same oriented three-manifold?

[Explanation pane](families/306/explanation.md) · [Mathematical source pane](families/306/mathematics.md)

- [Purely cosmetic surgery on knots in the three-sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Purely-Cosmetic-Surgery-on-Knots-in-the-Three-Sphere-September-23-2026/paper.pdf) · [individual note](papers/paper-41bca65a02037554.md)

### 307 · Failure of rational injectivity for maximal coarse assembly

Can large-scale topological K-theory information disappear under the maximal coarse assembly map?

[Explanation pane](families/307/explanation.md) · [Mathematical source pane](families/307/mathematics.md)

- [Failure of rational injectivity for maximal coarse assembly](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Failure-of-rational-injectivity-for-maximal-coarse-assembly-October-5-2026/paper.pdf) · [individual note](papers/paper-5a25eb51a4f7f15a.md)
- [A counterexample to the coarse Novikov conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-the-coarse-Novikov-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-4d6b72540609a1ff.md)

### 308 · Finite Smith–Toda complexes at every height

Do finite complexes realizing prescribed periodic homotopy patterns exist at every chromatic height?

[Explanation pane](families/308/explanation.md) · [Mathematical source pane](families/308/mathematics.md)

- [Finite Smith–Toda Complexes at Varying Primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Smith-Toda-Complexes-at-Varying-Primes-September-23-2026/paper.pdf) · [individual note](papers/paper-856e79ae2ece513a.md)
- [A finite Smith–Toda complex V(4) at the prime 1009](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-Smith-Toda-complex-V4-at-the-prime-1009-September-23-2026/paper.pdf) · [individual note](papers/paper-4ef8d9a5d99c47c7.md)

### 309 · The Kervaire invariant problem at the prime three

Is the proposed analogue of a special framed-manifold invariant possible at the prime three?

[Explanation pane](families/309/explanation.md) · [Mathematical source pane](families/309/mathematics.md)

- [The Kervaire invariant problem at the prime three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Kervaire-Invariant-Problem-at-the-Prime-Three-September-24-2026/paper.pdf) · [individual note](papers/paper-f7be26ff0756e3d0.md)

### 310 · Quillen's conjecture in rational homology

Does the topology of elementary-abelian-subgroup data detect the expected group-theoretic obstruction?

[Explanation pane](families/310/explanation.md) · [Mathematical source pane](families/310/mathematics.md)

- [Rational homology and Quillen's conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Rational-homology-and-Quillens-conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-408bf5fa78be5db5.md)

### 311 · The Hovey–Strickland and Chai conjectures

How rigid are invariant prime ideals and thick subcategories in higher chromatic homotopy theory?

[Explanation pane](families/311/explanation.md) · [Mathematical source pane](families/311/mathematics.md)

- [Stabilizer orbits and thick tensor ideals of dualizable K(n)-local spectra](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stabilizer-Orbits-and-Thick-Tensor-Ideals-of-Dualizable-Kn-Local-Spectra-September-24-2026/paper.pdf) · [individual note](papers/paper-adc161a81e95787c.md)

### 312 · The Grothendieck homotopy hypothesis

Can higher groupoid structures describe exactly the same objects as homotopy types of spaces?

[Explanation pane](families/312/explanation.md) · [Mathematical source pane](families/312/mathematics.md)

- [The Grothendieck homotopy hypothesis via elementary expansions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Grothendieck-homotopy-hypothesis-via-elementary-expansions-September-24-2026/paper.pdf) · [individual note](papers/paper-c6dfdbb531ac61fa.md)

### 313 · Finite generation for the $K(n)$-local sphere

Are the relevant homotopy groups of the K(n)-local sphere finitely generated over the predicted coefficient rings?

[Explanation pane](families/313/explanation.md) · [Mathematical source pane](families/313/mathematics.md)

- [Finite generation for the K(n)-local sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-generation-for-the-Kn-local-sphere-September-24-2026/Finite-generation-for-the-Kn-local-sphere-September-24-2026.pdf) · [individual note](papers/paper-a9ca7e181a564aad.md)

### 314 · Cyclic length and chromatic fixed-point loss

How much chromatic homotopy information is lost when taking fixed points under cyclic-group actions?

[Explanation pane](families/314/explanation.md) · [Mathematical source pane](families/314/mathematics.md)

- [Cyclic length and chromatic fixed-point loss](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Cyclic-Length-and-Chromatic-Fixed-Point-Loss-September-24-2026/Cyclic-Length-and-Chromatic-Fixed-Point-Loss-September-24-2026.pdf) · [individual note](papers/paper-66e658bd95e99419.md)

### 315 · The four-dimensional Singer conjecture

Must the square-integrable homology of an aspherical four-manifold vanish outside the middle dimension?

[Explanation pane](families/315/explanation.md) · [Mathematical source pane](families/315/mathematics.md)

- [The Singer conjecture in dimension four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Singer-conjecture-in-dimension-four-September-25-2026/paper.pdf) · [individual note](papers/paper-85cf8649a205f874.md)

### 316 · Curtis’s conjecture

Which stable homotopy classes survive in the homology of infinite loop spaces of spheres?

[Explanation pane](families/316/explanation.md) · [Mathematical source pane](families/316/mathematics.md)

- [The Stable Hurewicz Image of the Sphere at Two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Stable-Hurewicz-Image-of-the-Sphere-at-Two-September-25-2026/paper.pdf) · [individual note](papers/paper-777ce598e06053cd.md)

### 317 · Thomason model structures in all strict higher dimensions

Can strict higher categories carry model structures that reproduce ordinary homotopy theory in every dimension?

[Explanation pane](families/317/explanation.md) · [Mathematical source pane](families/317/mathematics.md)

- [Thomason Model Structures in Every Strict Higher Dimension](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Thomason-Model-Structures-in-Every-Strict-Higher-Dimension-September-25-2026/paper.pdf) · [individual note](papers/paper-191b5f67a246d151.md)

### 318 · Chromatic splitting: filtrations and counterexamples

How do successive chromatic layers of stable homotopy split, and where does the proposed splitting fail?

[Explanation pane](families/318/explanation.md) · [Mathematical source pane](families/318/mathematics.md)

- [Filtered chromatic splitting at generic primes](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Filtered-chromatic-splitting-at-generic-primes-September-25-2026/paper.pdf) · [individual note](papers/paper-afb117082c686a88.md)
- [The height-three chromatic overlap: an explicit filtration and its attachments](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-height-three-chromatic-overlap-an-explicit-filtration-and-its-attachments-September-27-2026/paper.pdf) · [individual note](papers/paper-25c059651a53f3a2.md)
- [A rational obstruction to strong chromatic splitting at height three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-rational-obstruction-to-strong-chromatic-splitting-at-height-three-September-25-2026/paper.pdf) · [individual note](papers/paper-38c1dbd2ed2d2e40.md)
- [Failure of finite assembly for a chromatic overlap at the prime three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Failure-of-finite-assembly-for-a-chromatic-overlap-at-the-prime-three-September-25-2026/paper.pdf) · [individual note](papers/paper-7498f13747e9c122.md)
- [Counterexamples to weak chromatic splitting: sphere kernels and descent exponents](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Counterexamples-to-weak-chromatic-splitting-sphere-kernels-and-descent-exponents-September-27-2026/paper.pdf) · [individual note](papers/paper-01f8301089b5184c.md)

### 319 · Counterexamples to finite generation at chromatic height two

Can chromatic-height-two homotopy constructions violate expected finite-generation properties?

[Explanation pane](families/319/explanation.md) · [Mathematical source pane](families/319/mathematics.md)

- [Counterexamples to the Hahn-Wilson conjecture at height two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Counterexamples-to-the-Hahn-Wilson-conjecture-at-height-two-September-26-2026/paper.pdf) · [individual note](papers/paper-826d0071f95c8c27.md)

### 320 · Nonhomeomorphic closed aspherical four-manifolds

How much can closed aspherical four-manifolds differ despite sharing the specified algebraic or homotopical data?

[Explanation pane](families/320/explanation.md) · [Mathematical source pane](families/320/mathematics.md)

- [Nonhomeomorphic closed aspherical four-manifolds with the same homotopy type](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonhomeomorphic-closed-aspherical-four-manifolds-with-the-same-homotopy-type-October-4-2026/paper.pdf) · [individual note](papers/paper-12e002896491840f.md)

### 321 · A counterexample to Wall's finite D(2) problem

Can a finite complex with effectively two-dimensional homological data require more than a two-dimensional finite model?

[Explanation pane](families/321/explanation.md) · [Mathematical source pane](families/321/mathematics.md)

- [A Counterexample to Wall's D(2) Problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Counterexample-to-Walls-D2-Problem-October-6-2026/wall-d2-counterexample.pdf) · [individual note](papers/paper-8a885cbec0341abc.md)

## Functional analysis

### 322 · Tingley’s sphere-isometry problem

Does every distance-preserving map between unit spheres of Banach spaces extend to a linear isometry of the spaces?

[Explanation pane](families/322/explanation.md) · [Mathematical source pane](families/322/mathematics.md)

- [A positive solution to Tingley’s problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-positive-solution-to-Tingleys-problem-September-23-2026/paper.pdf) · [individual note](papers/paper-de3ea17e6f2bad23.md)

### 323 · Independence of the separable quotient problem

Must every infinite-dimensional Banach space have an infinite-dimensional separable quotient, or can this depend on set theory?

[Explanation pane](families/323/explanation.md) · [Mathematical source pane](families/323/mathematics.md)

- [Relative independence of the separable quotient problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Relative-independence-of-the-separable-quotient-problem-September-23-2026/paper.pdf) · [individual note](papers/paper-0ec9faa3192c96bf.md)

### 324 · Lipschitz equivalent Banach spaces need not be linearly isomorphic

If two Banach spaces have the same geometry up to Lipschitz distortion, must their linear structures also agree?

[Explanation pane](families/324/explanation.md) · [Mathematical source pane](families/324/mathematics.md)

- [Lipschitz Equivalent Separable Banach Spaces Need Not Be Linearly Isomorphic](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Lipschitz-Equivalent-Separable-Banach-Spaces-Need-Not-Be-Linearly-Isomorphic-September-24-2026/paper.pdf) · [individual note](papers/paper-b388059c652bc865.md)
- [Bi-Lipschitz Absorption of c0 Without a Linear Copy of c0](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bi-Lipschitz-Absorption-of-c0-Without-a-Linear-Copy-of-c0-September-26-2026/paper.pdf) · [individual note](papers/paper-85b415e1d64e4c2f.md)

### 325 · The complete Crouzeix conjecture

How tightly can a matrix function's operator norm be bounded by its largest scalar value on the matrix's numerical range?

[Explanation pane](families/325/explanation.md) · [Mathematical source pane](families/325/mathematics.md)

- [A direct proof of the complete Crouzeix inequality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-direct-proof-of-the-complete-Crouzeix-inequality-September-26-2026/paper.pdf) · [individual note](papers/paper-1958c29c3a9288b3.md)
- [The complete Crouzeix theorem: optimal similarity and a common positive boundary representation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-complete-Crouzeix-theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-67565fa07c798e75.md)

### 326 · The cotype–cotype conjecture under the approximation property

How do cotype estimates behave under the relevant Banach-space operations when approximation is available?

[Explanation pane](families/326/explanation.md) · [Mathematical source pane](families/326/mathematics.md)

- [The cotype–cotype conjecture under the approximation property](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-cotype-cotype-conjecture-under-the-approximation-property-September-23-2026/paper.pdf) · [individual note](papers/paper-a349e2ccd7849158.md)

### 327 · Markov type characterizes superreflexivity

Can the behavior of random walks in a Banach space characterize whether it admits a uniformly convex equivalent norm?

[Explanation pane](families/327/explanation.md) · [Mathematical source pane](families/327/mathematics.md)

- [Nontrivial Markov Type Forces Superreflexivity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nontrivial-Markov-Type-Forces-Superreflexivity-September-23-2026/paper.pdf) · [individual note](papers/paper-c8dfd12cc5f584aa.md)

### 328 · Nonexpansive fixed points in reflexive Banach spaces

Must every distance-nonincreasing self-map of a bounded closed convex subset of a reflexive Banach space have a fixed point?

[Explanation pane](families/328/explanation.md) · [Mathematical source pane](families/328/mathematics.md)

- [Fixed Points of Nonexpansive Maps in Reflexive Banach Spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Fixed-Points-of-Nonexpansive-Maps-in-Reflexive-Banach-Spaces-September-24-2026/paper.pdf) · [individual note](papers/paper-a197f071849b21e1.md)

### 329 · A counterexample to metric-entropy duality

Are the covering complexities of a linear operator and its adjoint always comparable in the predicted manner?

[Explanation pane](families/329/explanation.md) · [Mathematical source pane](families/329/mathematics.md)

- [Counterexamples to the duality conjecture for metric entropy](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Counterexamples-to-the-duality-conjecture-for-metric-entropy-September-24-2026/main.pdf) · [individual note](papers/paper-5ffc4ea55241235d.md)

### 330 · A uniformly discrete counterexample to bounded approximation in Lipschitz-free spaces

Can a discrete metric space's associated Lipschitz-free Banach space fail bounded finite-rank approximation?

[Explanation pane](families/330/explanation.md) · [Mathematical source pane](families/330/mathematics.md)

- [A uniformly discrete counterexample to bounded approximation in Lipschitz-free spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Failure-of-Bounded-Approximation-in-a-Lipschitz-Free-Space-over-a-Uniformly-Discrete-Metric-Space-September-26-2026/main.pdf) · [individual note](papers/paper-eeff8513d74af1ff.md)

### 331 · Reflexive midpoint convexity and diamond distortion

How do convexity properties of Banach spaces control distortion of diamond-shaped metric graphs?

[Explanation pane](families/331/explanation.md) · [Mathematical source pane](families/331/mathematics.md)

- [Asymptotic midpoint uniform convexity and unbounded diamond distortion in a reflexive tree space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Asymptotic-midpoint-uniform-convexity-and-unbounded-diamond-distortion-in-a-reflexive-tree-space-September-27-2026/manuscript.pdf) · [individual note](papers/paper-ac2fc679b256a964.md)
- [Midpoint lenses in segment spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Midpoint-lenses-in-segment-spaces-September-27-2026/manuscript.pdf) · [individual note](papers/paper-9c490b1b2dd84591.md)
- [Distortion of countably branching diamonds from midpoint and tree energies](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Diamond-distortion-from-midpoint-and-tree-energies-September-27-2026/manuscript.pdf) · [individual note](papers/paper-75b77f9a83cb8486.md)
- [Exact asymptotic moduli in a Daugavet subspace of L1](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Exact-asymptotic-moduli-in-a-Daugavet-subspace-of-L1-September-27-2026/manuscript.pdf) · [individual note](papers/paper-4780f8d66ef625df.md)
- [Midpoint convexity from bounded tree potentials and path costs](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Midpoint-convexity-from-bounded-tree-potentials-and-path-costs-September-27-2026/manuscript.pdf) · [individual note](papers/paper-89d1de750a18c96c.md)
- [Independent products in real L1: asymptotic midpoint convexity without AUC renormings](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Independent-products-in-real-L1-asymptotic-midpoint-convexity-without-AUC-renormings-September-27-2026/manuscript.pdf) · [individual note](papers/paper-f06c7317d46b0bd0.md)
- [Midpoint convexity from two recursive potentials](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Midpoint-convexity-from-two-recursive-potentials-September-27-2026/manuscript.pdf) · [individual note](papers/paper-af1f68c8e3f95ea6.md)

### 332 · Metric Markov cotype of ℓ_{1} and Hilbert-space Lipschitz extension

Can Markov-chain geometry explain sharp Lipschitz-extension bounds from subsets into Hilbert space?

[Explanation pane](families/332/explanation.md) · [Mathematical source pane](families/332/mathematics.md)

- [Metric Markov Cotype Two of ℓ_{1}](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Metric-Markov-Cotype-Two-of-l1-October-5-2026/l1-markov-cotype.pdf) · [individual note](papers/paper-fc6738ad200ddb0c.md)

## Differential geometry

### 333 · Smooth isometric immersions of surfaces into ℝ^{4}

Can every smooth surface geometry be realized inside four-dimensional Euclidean space without changing intrinsic distances?

[Explanation pane](families/333/explanation.md) · [Mathematical source pane](families/333/mathematics.md)

- [Smooth isometric immersions of closed surfaces into Euclidean four-space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Smooth-isometric-immersions-of-closed-surfaces-into-Euclidean-four-space-September-23-2026/paper.pdf) · [individual note](papers/paper-b06c15d15d1f2bec.md)

### 334 · A smooth surface metric with no local isometric immersion in ℝ^{3}

Can a smooth surface metric resist every local distance-preserving realization in ordinary three-dimensional space?

[Explanation pane](families/334/explanation.md) · [Mathematical source pane](families/334/mathematics.md)

- [A Smooth Metric with No Local Isometric Immersion into Three-Space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Smooth-Metric-with-No-Local-Isometric-Immersion-into-Three-Space-September-24-2026/paper.pdf) · [individual note](papers/paper-a63b076de1a02aaa.md)

### 335 · Gromov’s integral scalar-curvature bound for simplicial volume

Can integrated scalar curvature be bounded by the topological complexity measured by simplicial volume?

[Explanation pane](families/335/explanation.md) · [Mathematical source pane](families/335/mathematics.md)

- [An integral scalar curvature bound for real simplicial volume](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-integral-scalar-curvature-bound-for-real-simplicial-volume-October-5-2026/v126-proof.pdf) · [individual note](papers/paper-d70ea1fa615d9ee5.md)
- [Positive scalar curvature forces rational inessentiality](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-scalar-curvature-forces-rational-inessentiality-September-23-2026/paper.pdf) · [individual note](papers/paper-e13146f0a1d57e20.md)

### 336 · Spectral scalar curvature, Urysohn width, and macroscopic dimension

How do spectral versions of positive scalar curvature limit a manifold's effective large-scale dimension?

[Explanation pane](families/336/explanation.md) · [Mathematical source pane](families/336/mathematics.md)

- [Spectral scalar curvature and uniform Urysohn width](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spectral-scalar-curvature-and-uniform-Urysohn-width-October-5-2026/main.pdf) · [individual note](papers/paper-dffe57f7044d1422.md)
- [Spectral scalar curvature and Urysohn width in dimension three](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Spectral-scalar-curvature-and-Urysohn-width-in-dimension-three-October-5-2026/spectral-urysohn-three-manifolds.pdf) · [individual note](papers/paper-435072f8fa3d9da2.md)
- [Positive scalar curvature and uniform codimension-two width](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positive-scalar-curvature-and-uniform-codimension-two-width-September-23-2026/paper.pdf) · [individual note](papers/paper-119262425903b8d9.md)

### 337 · Sharp Cartan–Hadamard isoperimetry and rigidity

Do simply connected nonpositively curved spaces obey the sharp Euclidean volume-boundary inequality?

[Explanation pane](families/337/explanation.md) · [Mathematical source pane](families/337/mathematics.md)

- [Generalized Cartan–Hadamard isoperimetry and Euclidean equality rigidity](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Generalized-Cartan-Hadamard-isoperimetry-and-Euclidean-equality-rigidity-September-23-2026/paper.pdf) · [individual note](papers/paper-9808a190babfbe20.md)
- [Sharp integral fillings in CAT(0) spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-integral-fillings-in-CAT(0) · [individual note](papers/paper-2d4cd77a24cc3cc5.md)

### 338 · Yau's uniformization conjecture

Must a complete noncompact Kähler manifold with positive holomorphic bisectional curvature have the predicted standard complex structure?

[Explanation pane](families/338/explanation.md) · [Mathematical source pane](families/338/mathematics.md)

- [Uniformization of complete Kähler manifolds with positive bisectional curvature](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniformization-of-complete-Kahler-manifolds-with-positive-bisectional-curvature-September-23-2026/paper.pdf) · [individual note](papers/paper-6b05c05905ae61e7.md)

### 339 · Katok's entropy rigidity conjecture

If a metric has the special entropy-minimizing property, must it come from locally symmetric geometry?

[Explanation pane](families/339/explanation.md) · [Mathematical source pane](families/339/mathematics.md)

- [Entropy equality and local symmetry in negative curvature](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Entropy-equality-and-local-symmetry-in-negative-curvature-September-23-2026/paper.pdf) · [individual note](papers/paper-8a5e3613110c708b.md)

### 340 · A counterexample to the nearby Lagrangian conjecture

Must a closed exact Lagrangian near a cotangent zero section be related to it by Hamiltonian deformation?

[Explanation pane](families/340/explanation.md) · [Mathematical source pane](families/340/mathematics.md)

- [A counterexample to the nearby Lagrangian conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-the-nearby-Lagrangian-conjecture-September-23-2026/paper.pdf) · [individual note](papers/paper-9d56d86939bafe3f.md)

### 341 · Donaldson's hypersymplectic deformation conjecture

Can every hypersymplectic triple be deformed into a hyperkähler triple under the stated assumptions?

[Explanation pane](families/341/explanation.md) · [Mathematical source pane](families/341/mathematics.md)

- [Deforming hypersymplectic four-manifolds to hyperkähler triples](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Deforming-hypersymplectic-four-manifolds-to-hyperkahler-triples-October-7-2026/paper.pdf) · [individual note](papers/paper-775ce49953e7f64d.md)

### 342 · Donaldson's tamed-to-compatible conjecture

If a symplectic form tames an almost complex structure, does some symplectic form actually become compatible with it?

[Explanation pane](families/342/explanation.md) · [Mathematical source pane](families/342/mathematics.md)

- [Taming implies compatibility on four-manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Taming-implies-compatibility-on-four-manifolds-October-6-2026/paper.pdf) · [individual note](papers/paper-9f2cd7732ae4753d.md)

### 343 · Symplectic ball packing in higher dimensions

How efficiently can symplectic balls be packed in higher-dimensional symplectic manifolds?

[Explanation pane](families/343/explanation.md) · [Mathematical source pane](families/343/mathematics.md)

- [Symplectic Ball Packings in Higher Dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Symplectic-Ball-Packings-in-Higher-Dimensions-September-23-2026/paper.pdf) · [individual note](papers/paper-99ba31491534ca13.md)

### 344 · The metric Blaschke conjecture

If every point has matching injectivity radius and diameter, must the manifold be one of the standard symmetric models?

[Explanation pane](families/344/explanation.md) · [Mathematical source pane](families/344/mathematics.md)

- [The metric Blaschke theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-metric-Blaschke-theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-92985a3f67cee9a3.md)

### 345 · Infinitely many closed geodesics on Riemannian spheres and closed three-manifolds

Must the stated closed manifolds carry infinitely many distinct closed geodesics?

[Explanation pane](families/345/explanation.md) · [Mathematical source pane](families/345/mathematics.md)

- [Infinitely many closed geodesic images on every Riemannian sphere](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Infinitely-many-closed-geodesic-images-on-every-Riemannian-sphere-September-24-2026/paper.pdf) · [individual note](papers/paper-a6e8868be3ba834e.md)

### 346 · Sharp singular-set bounds for stationary integral varifolds

How large can the singular part of a stationary generalized minimal surface be?

[Explanation pane](families/346/explanation.md) · [Mathematical source pane](families/346/mathematics.md)

- [A Codimension-One Bound for the Singular Set of a Stationary Integral Varifold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Codimension-One-Bound-for-the-Singular-Set-of-a-Stationary-Integral-Varifold-October-5-2026/varifold-singular-dimension.pdf) · [individual note](papers/paper-ced45e363dd65fa9.md)
- [Almost-everywhere regularity of stationary integral varifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Almost-everywhere-regularity-of-stationary-integral-varifolds-September-23-2026/paper.pdf) · [individual note](papers/paper-f42a6256d2f83fcc.md)

### 347 · Counterexamples to stable-Morse and strong Arnold fixed-point bounds

How many fixed points must a Hamiltonian system have, and can the strongest proposed Morse-theoretic bounds fail?

[Explanation pane](families/347/explanation.md) · [Mathematical source pane](families/347/mathematics.md)

- [Hamiltonian Fixed Points Below the Stable Morse Number in Dimension Twenty-Two](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hamiltonian-Fixed-Points-Below-the-Stable-Morse-Number-in-Dimension-Twenty-Two-October-5-2026/hamiltonian-fixed-points-below-stable-morse-number.pdf) · [individual note](papers/paper-ceac3ebde5cc26e3.md)
- [Sharpness of the Cyclic Integral Floer Bound Below the Stable Morse Number](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharpness-of-the-Cyclic-Integral-Floer-Bound-Below-the-Stable-Morse-Number-October-5-2026/sharp-cyclic-integral-floer-bound-below-stable-morse-number.pdf) · [individual note](papers/paper-4cd601c0e073f665.md)
- [Hamiltonian Fixed Points Below the Stable Morse Number](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hamiltonian-Fixed-Points-Below-the-Stable-Morse-Number-October-5-2026/paper.pdf) · [individual note](papers/paper-2452720029833a9f.md)
- [A nondegenerate counterexample to the Morse-number Arnold bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-nondegenerate-counterexample-to-the-Morse-number-Arnold-bound-September-23-2026/paper.pdf) · [individual note](papers/paper-1ac29174c951bdd3.md)
- [Three fixed points on the symplectic quadric threefold](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-degenerate-counterexample-to-the-critical-number-Arnold-bound-September-23-2026/paper.pdf) · [individual note](papers/paper-0265201c4a50cdcf.md)

### 348 · Nonnegative-curvature Einstein classification and an L^{2} topological gap

How rigid are Einstein manifolds with nonnegative curvature, and can curvature energy enforce a topological gap?

[Explanation pane](families/348/explanation.md) · [Mathematical source pane](families/348/mathematics.md)

- [Zero-Plane Rigidity for Einstein Four-Manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Zero-Plane-Rigidity-for-Einstein-Four-Manifolds-October-4-2026/einstein-boundary.pdf) · [individual note](papers/paper-72573bdb6e4c42a6.md)
- [An L² Einstein Gap for Nonnegatively Curved Four-Manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/An-L2-Einstein-Gap-for-Nonnegatively-Curved-Four-Manifolds-October-5-2026/einstein-gap.pdf) · [individual note](papers/paper-673428cc92030ec0.md)
- [Positively curved Einstein four-manifolds](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Positively-curved-Einstein-four-manifolds-September-23-2026/paper.pdf) · [individual note](papers/paper-d75a3a38ab451d5d.md)

### 349 · The Solomon–Yau least-volume conjecture

Which minimal hypersurfaces in a sphere have the smallest possible volume?

[Explanation pane](families/349/explanation.md) · [Mathematical source pane](families/349/mathematics.md)

- [The Solomon–Yau least-volume theorem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Solomon-Yau-least-volume-theorem-September-23-2026/paper.pdf) · [individual note](papers/paper-822b36fc5bd88be9.md)

### 350 · Yau’s nodal bounds: surfaces and higher dimensions

How does the size of an eigenfunction's zero set scale with its frequency?

[Explanation pane](families/350/explanation.md) · [Mathematical source pane](families/350/mathematics.md)

- [Sharp nodal length on smooth surfaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-nodal-length-on-smooth-surfaces-September-23-2026/paper.pdf) · [individual note](papers/paper-52ed8a3816433db0.md)
- [Smooth counterexamples to Yau's nodal upper bound in dimensions three and four](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Smooth-counterexamples-to-Yaus-nodal-upper-bound-in-dimensions-three-and-four-September-23-2026/paper.pdf) · [individual note](papers/paper-a74de7c8580896d3.md)
- [Power-law violations of Yau's nodal upper bound](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Power-law-violations-of-Yaus-nodal-upper-bound-September-23-2026/paper.pdf) · [individual note](papers/paper-b593f382a6c70e25.md)

### 351 · Scalar curvature and finite-time Ricci-flow singularities

What role does scalar curvature play in the geometry of finite-time Ricci-flow singularities?

[Explanation pane](families/351/explanation.md) · [Mathematical source pane](families/351/mathematics.md)

- [A closed Ricci flow with bounded scalar curvature and finite-time curvature blowup](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-closed-Ricci-flow-with-bounded-scalar-curvature-and-finite-time-curvature-blowup-September-24-2026/paper.pdf) · [individual note](papers/paper-a1506b279695da05.md)
- [Bounded scalar curvature and smooth extension of four-dimensional Ricci flow](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bounded-scalar-curvature-and-smooth-extension-of-four-dimensional-Ricci-flow-September-24-2026/paper.pdf) · [individual note](papers/paper-e74d425656ff1bb2.md)
- [Path selection and an elliptic inequality on degenerating Ricci-flat trees](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Path-selection-and-an-elliptic-inequality-on-degenerating-Ricci-flat-trees-September-24-2026/paper.pdf) · [individual note](papers/paper-e191b5476d032de1.md)

### 352 · A finite-time singularity of Calabi flow

Can a smooth Calabi-flow evolution develop a singularity after finite time?

[Explanation pane](families/352/explanation.md) · [Mathematical source pane](families/352/mathematics.md)

- [A finite-time singularity of Calabi flow on projective space](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-finite-time-singularity-of-Calabi-flow-on-projective-space-September-24-2026/paper.pdf) · [individual note](papers/paper-ec1ea47bdadbc513.md)

### 353 · Affine Bernstein rigidity through dimension nine and a smooth dimension-ten counterexample

In which dimensions must an entire solution of the affine minimal-surface equation be a flat graph?

[Explanation pane](families/353/explanation.md) · [Mathematical source pane](families/353/mathematics.md)

- [A Smooth Nonquadratic Entire Affine Maximal Graph in Dimension Ten](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Smooth-Nonquadratic-Affine-Maximal-Graph-in-Dimension-Ten-October-5-2026/affine-maximal-dimension-ten.pdf) · [individual note](papers/paper-dcd67918c437e5b4.md)
- [The affine Bernstein theorem in dimensions three through nine](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-affine-Bernstein-theorem-in-dimensions-three-through-nine-September-24-2026/main.pdf) · [individual note](papers/paper-5c8c8fdab0579bb6.md)

### 354 · The isoperimetric profile of the cubic three-torus

What shapes enclose a given volume with least boundary area inside a flat cubic three-torus?

[Explanation pane](families/354/explanation.md) · [Mathematical source pane](families/354/mathematics.md)

- [The Isoperimetric Conjecture for the Cubic Flat Three-Torus](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Isoperimetric-Conjecture-for-the-Cubic-Flat-Three-Torus-September-24-2026/article.pdf) · [individual note](papers/paper-d9e3783b8640ae3e.md)

### 355 · Unique tangent flows at the first surface singularity

When a surface first becomes singular under mean-curvature flow, is its rescaled limiting flow unique?

[Explanation pane](families/355/explanation.md) · [Mathematical source pane](families/355/mathematics.md)

- [Uniqueness of tangent flows at the first singular time of embedded surface mean-curvature flow](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Tangent-flow-uniqueness-2026-09-24/paper.pdf) · [individual note](papers/paper-dd8495b736eaeca6.md)

### 356 · Gigli’s characterization of Alexandrov curvature

Can an analytic curvature criterion identify exactly those metric spaces with Alexandrov lower curvature bounds?

[Explanation pane](families/356/explanation.md) · [Mathematical source pane](families/356/mathematics.md)

- [Gigli’s distributional curvature characterization of Alexandrov spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Giglis-distributional-curvature-characterization-of-Alexandrov-spaces-September-24-2026/main.pdf) · [individual note](papers/paper-89aaa979e36fa485.md)
- [Weak Hessian bounds along every geodesic in RCD spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Weak-Hessian-bounds-along-every-geodesic-in-RCD-spaces-September-24-2026/weak-hessian-geodesics.pdf) · [individual note](papers/paper-be56fe3043316bfc.md)

### 357 · Bi-Lipschitz coordinates at every regular RCD point

Does every regular point of an RCD metric-measure space admit coordinates preserving distances up to fixed multiplicative bounds?

[Explanation pane](families/357/explanation.md) · [Mathematical source pane](families/357/mathematics.md)

- [Bi-Lipschitz Coordinates at Regular Points of Noncollapsed RCD Spaces](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Bi-Lipschitz-Coordinates-at-Regular-Points-of-Noncollapsed-RCD-Spaces-September-25-2026/paper.pdf) · [individual note](papers/paper-eef694b570ce63c1.md)

### 358 · A three-manifold without conjugate points or nonpositive curvature

Can a manifold have no conjugate points while admitting no nonpositively curved metric?

[Explanation pane](families/358/explanation.md) · [Mathematical source pane](families/358/mathematics.md)

- [A Three-Manifold Without Conjugate Points and Without a Nonpositively Curved Metric](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Manifold-Without-Conjugate-Points-and-Without-a-Nonpositively-Curved-Metric-September-24-2026/paper.pdf) · [individual note](papers/paper-845ae3c4390beb45.md)

### 359 · Negative Kähler curvature without bounded holomorphic coordinates

Can negatively curved Kähler geometry still fail to admit uniformly controlled holomorphic coordinates?

[Explanation pane](families/359/explanation.md) · [Mathematical source pane](families/359/mathematics.md)

- [A negatively pinched Kähler threefold without bounded holomorphic coordinates](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-negatively-pinched-Kahler-threefold-without-bounded-holomorphic-coordinates-September-25-2026/paper.pdf) · [individual note](papers/paper-7d6aa7245a58f539.md)
- [One-sided negative sectional curvature and the holomorphic Liouville property](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/One-sided-negative-sectional-curvature-and-the-holomorphic-Liouville-property-September-25-2026/paper.pdf) · [individual note](papers/paper-077f7067ac0c1441.md)

### 360 · Weak MTW curvature gives convexity and regular optimal transport

Which curvature condition on a transport cost guarantees convexity and regularity of optimal transport maps?

[Explanation pane](families/360/explanation.md) · [Mathematical source pane](families/360/mathematics.md)

- [Global Support and Convex Injectivity Domains under Weak MTW](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Support-and-Convex-Injectivity-Domains-under-Weak-MTW-September-25-2026/paper.pdf) · [individual note](papers/paper-ce31113d2b428321.md)
- [Uniform Bi-Holder Transport from Weak MTW](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Bi-Holder-Transport-from-Weak-MTW-September-25-2026/paper.pdf) · [individual note](papers/paper-d34a3e42980b2ea6.md)

### 361 · Failure of integer-degree harmonic dimension comparison

Can a manifold have more polynomial-growth harmonic functions than the expected Euclidean comparison permits?

[Explanation pane](families/361/explanation.md) · [Mathematical source pane](families/361/mathematics.md)

- [A counterexample to integer-degree harmonic dimension comparison](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-integer-degree-harmonic-dimension-comparison-September-25-2026/paper.pdf) · [individual note](papers/paper-fe75e5c7cee9a2c2.md)
- [A Three-Dimensional Counterexample to Integer-Degree Harmonic Dimension Comparison](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Three-Dimensional-Counterexample-to-Integer-Degree-Harmonic-Dimension-Comparison-September-26-2026/paper.pdf) · [individual note](papers/paper-bf776b4ffa632c01.md)

## Partial differential equations

### 362 · Global smoothness for relativistic Vlasov–Maxwell

Can the relativistic equations coupling particle motion and electromagnetic fields remain smooth for all time?

[Explanation pane](families/362/explanation.md) · [Mathematical source pane](families/362/mathematics.md)

- [Global classical solutions of the three-dimensional relativistic Vlasov–Maxwell system](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-classical-solutions-of-the-three-dimensional-relativistic-Vlasov-Maxwell-system-September-23-2026/paper.pdf) · [individual note](papers/paper-8d5f9c2ed90564ce.md)

### 363 · Nonuniqueness with local conservation for the hard-sphere Boltzmann equation

Can the hard-sphere kinetic equation have distinct solutions even when local conservation laws are enforced?

[Explanation pane](families/363/explanation.md) · [Mathematical source pane](families/363/mathematics.md)

- [Nonuniqueness with local conservation for the hard-sphere Boltzmann equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonuniqueness-with-local-conservation-for-the-hard-sphere-Boltzmann-equation-October-5-2026/paper.pdf) · [individual note](papers/paper-809cf921ecb7dfcd.md)
- [Nonuniqueness for the periodic hard-sphere Boltzmann equation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonuniqueness-for-the-periodic-hard-sphere-Boltzmann-equation-September-23-2026/paper.pdf) · [individual note](papers/paper-6743b76228532153.md)

### 364 · Kinetic limits and fluctuations over the Boltzmann lifespan

How do particle systems converge to Boltzmann dynamics, including fluctuations, throughout its smooth lifespan?

[Explanation pane](families/364/explanation.md) · [Mathematical source pane](families/364/mathematics.md)

- [The Boltzmann–Grad limit for stable radial potentials on regular kinetic intervals](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Boltzmann-Grad-limit-for-stable-radial-potentials-on-regular-kinetic-intervals-September-23-2026/paper.pdf) · [individual note](papers/paper-0af8084bb6abd1cb.md)
- [Hard-sphere fluctuations on the regular Boltzmann lifespan](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Hard-sphere-fluctuations-on-the-regular-Boltzmann-lifespan-September-23-2026/paper.pdf) · [individual note](papers/paper-5d4c98d2f1aceae6.md)

### 365 · Joint metric and connection recovery from one boundary patch

Can measurements on one small boundary region reconstruct both a hidden metric and a hidden connection?

[Explanation pane](families/365/explanation.md) · [Mathematical source pane](families/365/mathematics.md)

- [Determination of a metric and a unitary connection from one boundary patch](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Determination-of-a-metric-and-a-unitary-connection-from-one-boundary-patch-October-5-2026/paper.pdf) · [individual note](papers/paper-115323e965bfea43.md)
- [Smooth anisotropic uniqueness in the Calderón problem from one boundary patch](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Smooth-Anisotropic-Uniqueness-in-the-Calderon-Problem-from-One-Boundary-Patch-September-24-2026/paper.pdf) · [individual note](papers/paper-60b4138a58a77283.md)
- [Nonuniqueness for bounded measurable scalar conductivities in three dimensions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Nonuniqueness-for-Bounded-Measurable-Scalar-Conductivities-in-Three-Dimensions-September-23-2026/paper.pdf) · [individual note](papers/paper-9fd1f8b0878055c0.md)

### 366 · The planar Mumford–Shah regularity conjecture and local weak-L^{4} gradient bounds

In the planar optimal-image-segmentation problem, how smooth is the edge set away from controlled junctions and tips?

[Explanation pane](families/366/explanation.md) · [Mathematical source pane](families/366/mathematics.md)

- [Interior regularity of planar Mumford–Shah minimizers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Interior-regularity-of-planar-Mumford-Shah-minimizers-September-24-2026/Interior-regularity-of-planar-Mumford-Shah-minimizers-September-24-2026.pdf) · [individual note](papers/paper-47de73ec1cf82726.md)

### 367 · The critical dimension for the one-phase Bernoulli problem

In which dimension can the simplest one-phase free-boundary problem first develop singular interfaces?

[Explanation pane](families/367/explanation.md) · [Mathematical source pane](families/367/mathematics.md)

- [The critical dimension for one-phase Bernoulli minimizers](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-critical-dimension-for-one-phase-Bernoulli-minimizers-September-24-2026/The-critical-dimension-for-one-phase-Bernoulli-minimizers-September-24-2026.pdf) · [individual note](papers/paper-0a77d9b162cc2eb1.md)

### 368 · The three-dimensional Ball–Evans approximation problem

Can rough three-dimensional Sobolev homeomorphisms be approximated by smooth invertible maps in the required norm?

[Explanation pane](families/368/explanation.md) · [Mathematical source pane](families/368/mathematics.md)

- [Strong diffeomorphic approximation in three dimensions for 1≤p≤2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strong-diffeomorphic-approximation-in-three-dimensions-for-1-le-p-le-2-September-24-2026/main.pdf) · [individual note](papers/paper-e1c258ca4c38632c.md)
- [Strong diffeomorphic approximation in three dimensions for p>2](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strong-diffeomorphic-approximation-in-three-dimensions-for-p-gt-2-September-24-2026/main.pdf) · [individual note](papers/paper-3f8dbb810cb80ccf.md)

### 369 · The hot spots conjecture for simply connected planar domains

Does the slowest-decaying nonconstant heat mode attain its extreme values only on a simply connected domain's boundary?

[Explanation pane](families/369/explanation.md) · [Mathematical source pane](families/369/mathematics.md)

- [Strict hot spots and absence of interior critical points on smooth simply connected planar domains](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Strict-hot-spots-and-absence-of-interior-critical-points-on-smooth-simply-connected-planar-domains-September-24-2026/main.pdf) · [individual note](papers/paper-2d0afcdf3063eccb.md)

### 370 · The Lane–Emden and Hénon–Lane–Emden conjectures

For which exponent ranges do coupled nonlinear elliptic equations admit no positive entire solutions?

[Explanation pane](families/370/explanation.md) · [Mathematical source pane](families/370/mathematics.md)

- [The Subcritical Hénon–Lane–Emden Conjecture](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-Subcritical-Henon-Lane-Emden-Conjecture-September-24-2026/paper.pdf) · [individual note](papers/paper-a70360e1425e1e29.md)

### 371 · Stable blowup for the defocusing Schrödinger equation

Can a nonlinear Schrödinger wave blow up even with a defocusing nonlinearity, under the specified supercritical assumptions?

[Explanation pane](families/371/explanation.md) · [Mathematical source pane](families/371/mathematics.md)

- [Stable self-similar blowup for a supercritical defocusing Schrödinger equation on the torus](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Stable-Self-Similar-Blowup-for-a-Supercritical-Defocusing-Schrodinger-Equation-on-the-Torus-September-24-2026/paper.pdf) · [individual note](papers/paper-07470786ccbc9182.md)

### 372 · Global uniqueness in smooth isotropic elasticity

Can boundary measurements uniquely recover a smooth isotropic elastic medium?

[Explanation pane](families/372/explanation.md) · [Mathematical source pane](families/372/mathematics.md)

- [Global Uniqueness for the Smooth Isotropic Elasticity Inverse Problem](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Global-Uniqueness-for-the-Smooth-Isotropic-Elasticity-Inverse-Problem-September-24-2026/article.pdf) · [individual note](papers/paper-896ace9df9a3005f.md)

### 373 · Nonattainment of the three-marginal Coulomb Monge problem

Can the cheapest three-particle Coulomb transport fail to be realized by deterministic transport maps?

[Explanation pane](families/373/explanation.md) · [Mathematical source pane](families/373/mathematics.md)

- [A counterexample to the Monge ansatz for the three-marginal Coulomb cost](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-counterexample-to-the-Monge-ansatz-for-the-three-marginal-Coulomb-cost-September-25-2026/paper.pdf) · [individual note](papers/paper-ccc4175b074f0736.md)

### 374 · Sharp one-third stability of Brenier maps

How sensitively does an optimal quadratic-cost transport map depend on changes in its target distribution?

[Explanation pane](families/374/explanation.md) · [Mathematical source pane](families/374/mathematics.md)

- [Sharp One-Third Stability of Brenier Maps](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Sharp-One-Third-Stability-of-Brenier-Maps-September-25-2026/article.pdf) · [individual note](papers/paper-fe1a77271d276b5e.md)

### 375 · De Giorgi's conjecture in dimension eight

Must bounded monotone solutions of a scalar elliptic equation have flat level sets through dimension eight?

[Explanation pane](families/375/explanation.md) · [Mathematical source pane](families/375/mathematics.md)

- [A positive resolution of De Giorgi's conjecture in dimension eight](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/De-Giorgis-conjecture-in-dimension-eight-September-26-2026/article.pdf) · [individual note](papers/paper-9eb94d7ac586df2c.md)

### 376 · Universal computation in forced Navier–Stokes flows

Can smoothly forced viscous fluid motion encode a universal computer, with a fixed observation detecting whether a program halts?

[Explanation pane](families/376/explanation.md) · [Mathematical source pane](families/376/mathematics.md)

- [Finite Instructions and Solenoidal Shear Flows](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Finite-Instructions-and-Solenoidal-Shear-Flows-September-27-2026/manuscript.pdf) · [individual note](papers/paper-42d9ff3938134415.md)
- [A Fixed Particle Test for Computation in a Forced Viscous Flow](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/A-Fixed-Particle-Test-for-Computation-in-a-Forced-Viscous-Flow-September-27-2026/manuscript.pdf) · [individual note](papers/paper-22fbb3d0d867af2d.md)
- [Universal Computation with Eventually Stationary Navier–Stokes Forcing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Universal-Computation-with-Eventually-Stationary-Navier-Stokes-Forcing-September-27-2026/manuscript.pdf) · [individual note](papers/paper-f29d6c137ff197b3.md)
- [Geometric Programs for Solenoidal Forcing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Geometric-Programs-for-Solenoidal-Forcing-September-27-2026/manuscript.pdf) · [individual note](papers/paper-6fadd80320be0c3f.md)
- [Prefix Instructions and Incompressible Flows](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Prefix-Instructions-and-Incompressible-Flows-September-27-2026/manuscript.pdf) · [individual note](papers/paper-f85e3d65dea2fc13.md)
- [Computation under Rapidly Vanishing Navier–Stokes Forcing](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Computation-under-Rapidly-Vanishing-Navier-Stokes-Forcing-September-27-2026/manuscript.pdf) · [individual note](papers/paper-8fc2ca8e5d21eede.md)
- [Velocity-Field Detection of Computation in Forced Navier–Stokes Flows](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Velocity-Field-Detection-of-Computation-in-Forced-Navier-Stokes-Flows-September-27-2026/manuscript.pdf) · [individual note](papers/paper-f0dcdb7122501f2d.md)
- [Scalar Potentials and Slow Clocks for Forced Fluid Computation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Scalar-Potentials-and-Slow-Clocks-for-Forced-Fluid-Computation-September-27-2026/manuscript.pdf) · [individual note](papers/paper-c813344ac420837b.md)
- [Incompressible Box Transport and Finite Computation](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Incompressible-Box-Transport-and-Finite-Computation-October-6-2026/manuscript.pdf) · [individual note](papers/paper-4edde418b998a9ad.md)

### 377 · Interior $C^{1,\alpha}$ regularity for infinity-harmonic functions

Do functions minimizing their worst local slope have continuously varying gradients with a quantitative Hölder bound?

[Explanation pane](families/377/explanation.md) · [Mathematical source pane](families/377/mathematics.md)

- [Uniform Interior $C^{1,\alpha}$ Estimates for Infinity-Harmonic Functions](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Uniform-Interior-C1alpha-Estimates-for-Infinity-Harmonic-Functions-October-4-2026/interior-c1-infinity-harmonic.pdf) · [individual note](papers/paper-b23c1458fb03f19d.md)

## Withdrawn manuscripts · historical appendix

The manuscript notices date withdrawal to 6 October 2026; the repository history records it under 7 October. The faulty proof does not establish its claim; withdrawal does not itself show that the statement is false.

### The rational Hodge conjecture for products of K3 surfaces

**Withdrawn.** On a product of K3 surfaces, does every rational class with the right Hodge-theoretic type come from an algebraic cycle?

[Individual note](papers/paper-aceab999d1936bdd.md) · [Withdrawal notice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/README.md) · [Archived PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/The-rational-Hodge-conjecture-for-products-of-K3-surfaces-October-4-2026/hodge-conjecture-products-k3.pdf)

### Algebraicity of Kuga–Satake Correspondences for K3 Surfaces

**Withdrawn.** A K3 surface can be associated with an abelian variety through cohomology. Does that correspondence come from an actual algebraic cycle?

[Individual note](papers/paper-66f698e2546cb119.md) · [Withdrawal notice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Algebraicity-of-Kuga-Satake-Correspondences-for-K3-Surfaces-October-3-2026/README.md) · [Archived PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraicity-of-Kuga-Satake-Correspondences-for-K3-Surfaces-October-3-2026/manuscript.pdf)

### Algebraicity of Weil classes on split abelian eightfolds

**Withdrawn.** In a special eight-dimensional abelian variety, are the distinguished cohomology classes called Weil classes represented by actual algebraic subvarieties?

[Individual note](papers/paper-3a543f5fd0dc50a2.md) · [Withdrawal notice](https://github.com/openai/math/blob/fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb/preprints/Algebraicity-of-Weil-classes-on-split-abelian-eightfolds-September-18-2026/README.md) · [Archived PDF](https://github.com/openai/math/blob/adc7f1241b42e322a6451854ab7e4b4c146bf78a/preprints/Algebraicity-of-Weil-classes-on-split-abelian-eightfolds-September-18-2026/paper.pdf)

