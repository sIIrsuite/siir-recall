# Integration contract

Target: Sahil’s Knowledge Notebook (`appgprj_6abe76fa551c819182ba087528d1484a`).

## Content mapping

Read `notebook-notes.json.notes`. Add one collection named “OpenAI mathematical manuscript collection”; group its 372 notes by `subject`. Use `description` as the list-card summary and `order` as stable source ordering. Display `explanationMarkdown` and `mathematicsMarkdown` side by side on desktop, with a pane switch on narrow screens. Preserve the existing monochromatic notebook style, annotations, and other collections.

| Package field | Notebook purpose |
|---|---|
| `id` | Stable content ID; never replace with title-derived IDs |
| `title` | Note heading |
| `subject` | Official discipline category |
| `description` | Intuitive question for browsing |
| `explanationMarkdown` | Verbal explanation pane |
| `mathematicsMarkdown` | Mathematical source-summary pane |
| `manuscriptIds` | Links into `catalogue.json.manuscripts` |
| `sourceFamilyId` | Original OpenAI family number, retained as a string |

This is an intermediate schema, not a claim that the deployed notebook already accepts these fields. Inspect the notebook’s current source/export schema before writing an adapter. Match existing data shapes while preserving these separate content fields; do not overwrite existing notes or annotations.

## Manuscript browser

Use `catalogue.json.manuscripts` to show all 722 records. Default to the 719 `listed_in_current_catalogue` records; offer a separate “Withdrawn” filter for three records. Search titles, subjects, intuition, and source abstracts. A family description is shared across companion papers and must be labeled as such; manuscript-specific scope is supplied by the source abstract.

Use `publication_status` and `review_status` as distinct concepts. Do not change source verbs into editorial claims of proved correctness. A Lean family pointer is not proof coverage for every statement.

Resolve relative Markdown links against the package root. Source PDF URLs are pinned to the snapshot commit, and withdrawn PDFs to the historical commit. Source directory URLs are pinned to the current snapshot for notices and citation instructions.

## Import validation

Expect 372 notes, 372 families, 719 currently listed manuscripts, and 3 withdrawn manuscripts. Family numbers are not contiguous: preserve source gaps. All 719 current paper IDs belong to exactly one current family. Withdrawn historical records remain associated with family 032 without being inserted into its current manuscript count. Render normalized `$...$`/`$$...$$` math and links through the notebook’s existing Markdown pipeline.

When importing by stable ID, update shipped content fields only; retain read state and user annotations. Keep the complete source snapshot date and commit visible in collection metadata.
